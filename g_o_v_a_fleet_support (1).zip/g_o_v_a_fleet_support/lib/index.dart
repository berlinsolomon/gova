// Export pages
export '/onboarding/login/login_widget.dart' show LoginWidget;
export '/onboarding/welcome/welcome_widget.dart' show WelcomeWidget;
export '/onboarding/createaccount/createaccount_widget.dart'
    show CreateaccountWidget;
export '/onboarding/createprofile_step2/createprofile_step2_widget.dart'
    show CreateprofileStep2Widget;
export '/main_shared/dashboard/dashboard_widget.dart' show DashboardWidget;
export '/onboarding/createprofile_step1/createprofile_step1_widget.dart'
    show CreateprofileStep1Widget;
export '/onboarding/createprofile_step3/createprofile_step3_widget.dart'
    show CreateprofileStep3Widget;
export '/driverandtrucks/findservices/findservices_widget.dart'
    show FindservicesWidget;
export '/driver/inputrequestdetails/inputrequestdetails_widget.dart'
    show InputrequestdetailsWidget;
export '/main_shared/request_details/request_details_widget.dart'
    show RequestDetailsWidget;
export '/driver/incidenthistory_driver/incidenthistory_driver_widget.dart'
    show IncidenthistoryDriverWidget;
export '/main_shared/profile/profile_widget.dart' show ProfileWidget;
export '/fleetmanager/alldrivers/alldrivers_widget.dart' show AlldriversWidget;
export '/fleetmanager/alltrucks/alltrucks_widget.dart' show AlltrucksWidget;
export '/fleetmanager/incidents/incidents_widget.dart' show IncidentsWidget;
export '/fleetmanager/history/history_widget.dart' show HistoryWidget;
export '/serviceprovider/browse_jobs/browse_jobs_widget.dart'
    show BrowseJobsWidget;
export '/serviceprovider/current_jobs/current_jobs_widget.dart'
    show CurrentJobsWidget;
export '/serviceprovider/alltechnicians/alltechnicians_widget.dart'
    show AlltechniciansWidget;
export '/technician/technician_history/technician_history_widget.dart'
    show TechnicianHistoryWidget;
export '/main_shared/loader/loader_widget.dart' show LoaderWidget;
export '/main_shared/transfers_drivertech/transfers_drivertech_widget.dart'
    show TransfersDrivertechWidget;
export '/main_shared/notifications/notifications_widget.dart'
    show NotificationsWidget;
export '/main_shared/transfers_fleetprovider/transfers_fleetprovider_widget.dart'
    show TransfersFleetproviderWidget;

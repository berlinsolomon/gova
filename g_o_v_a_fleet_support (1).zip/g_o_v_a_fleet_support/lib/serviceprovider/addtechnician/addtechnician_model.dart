import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/flutter_flow/custom_functions.dart' as functions;
import '/flutter_flow/permissions_util.dart';
import '/flutter_flow/random_data_util.dart' as random_data;
import 'addtechnician_widget.dart' show AddtechnicianWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';

class AddtechnicianModel extends FlutterFlowModel<AddtechnicianWidget> {
  ///  Local state fields for this component.

  String addtype = 'Manual';

  List<ContactStruct> contacts = [];
  void addToContacts(ContactStruct item) => contacts.add(item);
  void removeFromContacts(ContactStruct item) => contacts.remove(item);
  void removeAtIndexFromContacts(int index) => contacts.removeAt(index);
  void insertAtIndexInContacts(int index, ContactStruct item) =>
      contacts.insert(index, item);
  void updateContactsAtIndex(int index, Function(ContactStruct) updateFn) =>
      contacts[index] = updateFn(contacts[index]);

  List<ContactStruct> search = [];
  void addToSearch(ContactStruct item) => search.add(item);
  void removeFromSearch(ContactStruct item) => search.remove(item);
  void removeAtIndexFromSearch(int index) => search.removeAt(index);
  void insertAtIndexInSearch(int index, ContactStruct item) =>
      search.insert(index, item);
  void updateSearchAtIndex(int index, Function(ContactStruct) updateFn) =>
      search[index] = updateFn(search[index]);

  int techsadded = 0;

  ///  State fields for stateful widgets in this component.

  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode1;
  TextEditingController? textController1;
  String? Function(BuildContext, String?)? textController1Validator;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<ServiceprovidersRow>? findcompanyA;
  // Stores action output result for [Backend Call - Insert Row] action in Button widget.
  ServiceproviderStaffRow? newstaffmemberA;
  // Stores action output result for [Backend Call - Insert Row] action in Button widget.
  ServiceproviderStaffRow? newstaffmember1A;
  // State field(s) for CheckboxListTile widget.
  Map<ContactStruct, bool> checkboxListTileValueMap1 = {};
  List<ContactStruct> get checkboxListTileCheckedItems1 =>
      checkboxListTileValueMap1.entries
          .where((e) => e.value)
          .map((e) => e.key)
          .toList();

  // State field(s) for CheckboxListTile widget.
  Map<ContactStruct, bool> checkboxListTileValueMap2 = {};
  List<ContactStruct> get checkboxListTileCheckedItems2 =>
      checkboxListTileValueMap2.entries
          .where((e) => e.value)
          .map((e) => e.key)
          .toList();

  bool isDataUploading_addstaffimage2 = false;
  FFUploadedFile uploadedLocalFile_addstaffimage2 =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  String uploadedFileUrl_addstaffimage2 = '';

  // State field(s) for firstname widget.
  FocusNode? firstnameFocusNode;
  TextEditingController? firstnameTextController;
  String? Function(BuildContext, String?)? firstnameTextControllerValidator;
  // State field(s) for lastname widget.
  FocusNode? lastnameFocusNode;
  TextEditingController? lastnameTextController;
  String? Function(BuildContext, String?)? lastnameTextControllerValidator;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode2;
  TextEditingController? textController4;
  String? Function(BuildContext, String?)? textController4Validator;
  // State field(s) for phone widget.
  FocusNode? phoneFocusNode;
  TextEditingController? phoneTextController;
  late MaskTextInputFormatter phoneMask;
  String? Function(BuildContext, String?)? phoneTextControllerValidator;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<ServiceprovidersRow>? findcompany;
  // Stores action output result for [Backend Call - Insert Row] action in Button widget.
  ServiceproviderStaffRow? newstaffmember;
  // Stores action output result for [Backend Call - Insert Row] action in Button widget.
  ServiceproviderStaffRow? newstaffmember1;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    textFieldFocusNode1?.dispose();
    textController1?.dispose();

    firstnameFocusNode?.dispose();
    firstnameTextController?.dispose();

    lastnameFocusNode?.dispose();
    lastnameTextController?.dispose();

    textFieldFocusNode2?.dispose();
    textController4?.dispose();

    phoneFocusNode?.dispose();
    phoneTextController?.dispose();
  }
}

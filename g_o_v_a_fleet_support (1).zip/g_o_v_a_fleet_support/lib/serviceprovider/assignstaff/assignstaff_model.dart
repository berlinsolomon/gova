import '/auth/firebase_auth/auth_util.dart';
import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/backend/push_notifications/push_notifications_util.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/serviceprovider/techcheck/techcheck_widget.dart';
import 'dart:ui';
import 'assignstaff_widget.dart' show AssignstaffWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class AssignstaffModel extends FlutterFlowModel<AssignstaffWidget> {
  ///  Local state fields for this component.

  ServiceproviderStaffRow? selected;

  ///  State fields for stateful widgets in this component.

  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode1;
  TextEditingController? textController1;
  String? Function(BuildContext, String?)? textController1Validator;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode2;
  TextEditingController? textController2;
  String? Function(BuildContext, String?)? textController2Validator;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<UsersRow>? findtechuser;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<UsersRow>? findfleetmanager;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  UsersRecord? findrequester;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  UsersRecord? findtechnician;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  List<UsersRecord>? findfmFb;
  // Models for techcheck dynamic component.
  late FlutterFlowDynamicModels<TechcheckModel> techcheckModels;

  @override
  void initState(BuildContext context) {
    techcheckModels = FlutterFlowDynamicModels(() => TechcheckModel());
  }

  @override
  void dispose() {
    textFieldFocusNode1?.dispose();
    textController1?.dispose();

    textFieldFocusNode2?.dispose();
    textController2?.dispose();

    techcheckModels.dispose();
  }
}

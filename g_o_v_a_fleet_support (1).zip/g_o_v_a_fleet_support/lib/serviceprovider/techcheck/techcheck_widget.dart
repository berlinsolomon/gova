import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'techcheck_model.dart';
export 'techcheck_model.dart';

class TechcheckWidget extends StatefulWidget {
  const TechcheckWidget({
    super.key,
    required this.select,
    bool? selected,
    required this.deselect,
  }) : this.selected = selected ?? false;

  final Future Function()? select;
  final bool selected;
  final Future Function()? deselect;

  @override
  State<TechcheckWidget> createState() => _TechcheckWidgetState();
}

class _TechcheckWidgetState extends State<TechcheckWidget> {
  late TechcheckModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => TechcheckModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: AlignmentDirectional(1.0, 0.0),
      child: Theme(
        data: ThemeData(
          checkboxTheme: CheckboxThemeData(
            visualDensity: VisualDensity.compact,
            materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(4.0),
            ),
          ),
          unselectedWidgetColor: FlutterFlowTheme.of(context).alternate,
        ),
        child: Checkbox(
          value: _model.checkboxValue ??= widget!.selected,
          onChanged: (newValue) async {
            safeSetState(() => _model.checkboxValue = newValue!);
            if (newValue!) {
              await widget.select?.call();
            } else {
              await widget.deselect?.call();
            }
          },
          side: (FlutterFlowTheme.of(context).alternate != null)
              ? BorderSide(
                  width: 2,
                  color: FlutterFlowTheme.of(context).alternate!,
                )
              : null,
          activeColor: FlutterFlowTheme.of(context).primary,
          checkColor: FlutterFlowTheme.of(context).info,
        ),
      ),
    );
  }
}

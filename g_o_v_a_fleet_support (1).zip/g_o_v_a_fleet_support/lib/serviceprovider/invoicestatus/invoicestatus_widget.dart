import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'invoicestatus_model.dart';
export 'invoicestatus_model.dart';

class InvoicestatusWidget extends StatefulWidget {
  const InvoicestatusWidget({
    super.key,
    required this.incident,
    required this.refresh,
  });

  final RequestsRow? incident;
  final Future Function(String invoicestatus)? refresh;

  @override
  State<InvoicestatusWidget> createState() => _InvoicestatusWidgetState();
}

class _InvoicestatusWidgetState extends State<InvoicestatusWidget> {
  late InvoicestatusModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => InvoicestatusModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FlutterFlowDropDown<String>(
      controller: _model.dropDownValueController ??=
          FormFieldController<String>(
        _model.dropDownValue ??= valueOrDefault<String>(
          widget!.incident?.invoicestatus,
          'Pending invoice',
        ),
      ),
      options: ['Pending invoice', 'Invoice sent'],
      onChanged: (val) async {
        safeSetState(() => _model.dropDownValue = val);
        await widget.refresh?.call(
          _model.dropDownValue!,
        );
      },
      width: double.infinity,
      height: 52.0,
      textStyle: FlutterFlowTheme.of(context).bodyMedium.override(
            font: GoogleFonts.lato(
              fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
              fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
            ),
            letterSpacing: 0.0,
            fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
            fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
          ),
      hintText: 'Select...',
      icon: Icon(
        Icons.keyboard_arrow_down_rounded,
        color: FlutterFlowTheme.of(context).secondaryText,
        size: 24.0,
      ),
      fillColor: widget!.incident?.invoicestatus == 'Pending invoice'
          ? FlutterFlowTheme.of(context).secondaryBackground
          : Color(0xFF93FFF4),
      elevation: 2.0,
      borderColor: widget!.incident?.invoicestatus == 'Pending invoice'
          ? FlutterFlowTheme.of(context).primaryBackground
          : FlutterFlowTheme.of(context).success,
      borderWidth: 2.0,
      borderRadius: 8.0,
      margin: EdgeInsetsDirectional.fromSTEB(12.0, 0.0, 12.0, 0.0),
      hidesUnderline: true,
      isOverButton: false,
      isSearchable: false,
      isMultiSelect: false,
    );
  }
}

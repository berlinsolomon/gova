// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

// use the searchterm to search the services rows by the name field. it doesn't have to be an exact spelling match and search is case insensitive
Future<List<ServicesRow>> searchservices(
  List<ServicesRow> allservices,
  String searchterm,
) async {
  // normalize and split the term
  final term = searchterm.trim().toLowerCase();
  if (term.isEmpty) {
    return allservices;
  }
  final tokens = term.split(RegExp(r'\s+')).where((t) => t.isNotEmpty);

  // filter down to rows whose name contains every token
  return allservices.where((service) {
    final name = service.name?.toLowerCase() ?? '';
    return tokens.every((token) => name.contains(token));
  }).toList();
}

import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:math';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/index.dart';
import 'findservices_widget.dart' show FindservicesWidget;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_blurhash/flutter_blurhash.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:octo_image/octo_image.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';

class FindservicesModel extends FlutterFlowModel<FindservicesWidget> {
  ///  Local state fields for this page.

  List<ServicesRow> searchresults = [];
  void addToSearchresults(ServicesRow item) => searchresults.add(item);
  void removeFromSearchresults(ServicesRow item) => searchresults.remove(item);
  void removeAtIndexFromSearchresults(int index) =>
      searchresults.removeAt(index);
  void insertAtIndexInSearchresults(int index, ServicesRow item) =>
      searchresults.insert(index, item);
  void updateSearchresultsAtIndex(int index, Function(ServicesRow) updateFn) =>
      searchresults[index] = updateFn(searchresults[index]);

  bool showsearching = false;

  ///  State fields for stateful widgets in this page.

  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? Function(BuildContext, String?)? textControllerValidator;
  // Stores action output result for [Backend Call - Query Rows] action in TextField widget.
  List<ServicesRow>? findservicesCopy;
  // Stores action output result for [Custom Action - searchservices] action in TextField widget.
  List<ServicesRow>? searchCopy;
  // Stores action output result for [Backend Call - Query Rows] action in IconButton widget.
  List<ServicesRow>? findservices;
  // Stores action output result for [Custom Action - searchservices] action in IconButton widget.
  List<ServicesRow>? search;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    textFieldFocusNode?.dispose();
    textController?.dispose();
  }
}

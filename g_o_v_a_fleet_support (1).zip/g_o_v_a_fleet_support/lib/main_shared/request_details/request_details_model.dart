import '/auth/firebase_auth/auth_util.dart';
import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/backend/push_notifications/push_notifications_util.dart';
import '/backend/supabase/supabase.dart';
import '/components/cancel_request/cancel_request_widget.dart';
import '/components/cardpayment/cardpayment_widget.dart';
import '/components/emptyimages/emptyimages_widget.dart';
import '/components/emptyserviceproviders/emptyserviceproviders_widget.dart';
import '/components/incident_updates/incident_updates_widget.dart';
import '/components/reviews/reviews_widget.dart';
import '/components/technicianconfirm/technicianconfirm_widget.dart';
import '/components/techniciandetails/techniciandetails_widget.dart';
import '/driver/editrequestdetails/editrequestdetails_widget.dart';
import '/driver/incident_jobcode/incident_jobcode_widget.dart';
import '/fleetmanager/added_details/added_details_widget.dart';
import '/fleetmanager/editdetails/editdetails_widget.dart';
import '/fleetmanager/editrequest_fleetmanager/editrequest_fleetmanager_widget.dart';
import '/fleetmanager/providerdetails/providerdetails_widget.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_expanded_image_view.dart';
import '/flutter_flow/flutter_flow_google_map.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import '/main_shared/incident_reviews/incident_reviews_widget.dart';
import '/serviceprovider/assignstaff/assignstaff_widget.dart';
import 'dart:math';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import 'dart:async';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'request_details_widget.dart' show RequestDetailsWidget;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:expandable/expandable.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_blurhash/flutter_blurhash.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:octo_image/octo_image.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';

class RequestDetailsModel extends FlutterFlowModel<RequestDetailsWidget> {
  ///  Local state fields for this page.

  CancellationRequestsRow? cancellation;

  ///  State fields for stateful widgets in this page.

  // Stores action output result for [Backend Call - Query Rows] action in request_details widget.
  List<RequestsRow>? findincident;
  // Stores action output result for [Backend Call - Query Rows] action in request_details widget.
  List<UsersRow>? finduser;
  // Stores action output result for [Backend Call - Query Rows] action in request_details widget.
  List<CancellationRequestsRow>? findcancrequestsbytrans;
  // Stores action output result for [Backend Call - Query Rows] action in request_details widget.
  List<CancellationRequestsRow>? findcancrequestsbyprov;
  Completer<List<RequestsRow>>? requestCompleter2;
  Completer<List<RequestsRow>>? requestCompleter1;
  // State field(s) for GoogleMap widget.
  LatLng? googleMapsCenter1;
  final googleMapsController1 = Completer<GoogleMapController>();
  bool isDataUploading_uploadDataBy01 = false;
  FFUploadedFile uploadedLocalFile_uploadDataBy01 =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  String uploadedFileUrl_uploadDataBy01 = '';

  // Stores action output result for [Backend Call - Query Rows] action in Row widget.
  List<UsersRow>? findallfleetmanagers;
  // Stores action output result for [Firestore Query - Query a collection] action in Row widget.
  List<UsersRecord>? findallfmSb;
  // State field(s) for PinCode widget.
  TextEditingController? pinCodeController;
  FocusNode? pinCodeFocusNode;
  String? Function(BuildContext, String?)? pinCodeControllerValidator;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<ServiceproviderStaffRow>? findstaff;
  // Stores action output result for [Backend Call - Query Rows] action in Container widget.
  List<ServiceprovidersRow>? findprovider;
  Completer<List<UsersRow>>? requestCompleter4;
  // State field(s) for Expandable widget.
  late ExpandableController expandableExpandableController1;

  // State field(s) for GoogleMap widget.
  LatLng? googleMapsCenter2;
  final googleMapsController2 = Completer<GoogleMapController>();
  // Stores action output result for [Firestore Query - Query a collection] action in Row widget.
  UsersRecord? findrequester;
  // Stores action output result for [Backend Call - Update Row(s)] action in Button widget.
  List<CancellationRequestsRow>? declinerequest;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  UsersRecord? findrequestor;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<UsersRow>? findprovideradmins;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  List<UsersRecord>? findadminsFb;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<UsersRow>? findchosentechnician;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  UsersRecord? findtechFb;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  UsersRecord? findthedriverFb;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<UsersRow>? findprovideradmins2;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  List<UsersRecord>? findadminsFb2;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  UsersRecord? findthedriverFb2;
  // Stores action output result for [Backend Call - Update Row(s)] action in Button widget.
  List<CancellationRequestsRow>? updaterequestTransporter;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<TransportersRow>? findfleetcompanyCopyCopy;
  // Stores action output result for [Backend Call - API (Charge)] action in Button widget.
  ApiCallResponse? chargecardA;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<ServiceprovidersRow>? findprovidersAbc;
  // Stores action output result for [Backend Call - API (Initiate)] action in Button widget.
  ApiCallResponse? initiatetransactionA;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<ServiceprovidersRow>? findprovidersDef;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<TransportersRow>? findfleetcompany;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<UsersRow>? findspadmins;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  List<UsersRecord>? findspadminsFb;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  UsersRecord? finddriverFb;
  // Stores action output result for [Backend Call - Query Rows] action in Container widget.
  List<TransportersRow>? findfleetcompanyCopy;
  // Stores action output result for [Backend Call - API (Charge)] action in Container widget.
  ApiCallResponse? chargecardAbc;
  // Stores action output result for [Backend Call - API (Initiate)] action in Container widget.
  ApiCallResponse? initiatetransactionAbc;
  // Stores action output result for [Backend Call - Query Rows] action in Container widget.
  List<ServiceprovidersRow>? findproviderCopya;
  // Stores action output result for [Backend Call - Query Rows] action in Column widget.
  List<ServiceprovidersRow>? findproviderCopyb;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<UsersRow>? findfleetmanagers;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  List<UsersRecord>? findfleetmanagersFb;
  Completer<List<RequestsRow>>? requestCompleter3;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<ServiceprovidersRow>? findmyspcompany;
  // State field(s) for Expandable widget.
  late ExpandableController expandableExpandableController2;

  // State field(s) for GoogleMap widget.
  LatLng? googleMapsCenter3;
  final googleMapsController3 = Completer<GoogleMapController>();
  // Stores action output result for [Firestore Query - Query a collection] action in Row widget.
  UsersRecord? findrequester1a;
  // Stores action output result for [Backend Call - Update Row(s)] action in Button widget.
  List<CancellationRequestsRow>? cancellofficialSp;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<UsersRow>? findfleetmanagers1;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  List<UsersRecord>? findfleetmanagersfb1;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  UsersRecord? finddriverFb1;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<UsersRow>? findtechnician;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  UsersRecord? findtech1;

  @override
  void initState(BuildContext context) {
    pinCodeController = TextEditingController();
  }

  @override
  void dispose() {
    pinCodeFocusNode?.dispose();
    pinCodeController?.dispose();

    expandableExpandableController1.dispose();
    expandableExpandableController2.dispose();
  }

  /// Additional helper methods.
  Future waitForRequestCompleted2({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter2?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }

  Future waitForRequestCompleted1({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter1?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }

  Future waitForRequestCompleted4({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter4?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }

  Future waitForRequestCompleted3({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter3?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }
}

import '/auth/firebase_auth/auth_util.dart';
import '/backend/schema/structs/index.dart';
import '/backend/supabase/supabase.dart';
import '/components/terms/terms_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_pdf_viewer.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'dart:async';
import 'profile_widget.dart' show ProfileWidget;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';

class ProfileModel extends FlutterFlowModel<ProfileWidget> {
  ///  Local state fields for this page.

  bool changes = false;

  ///  State fields for stateful widgets in this page.

  // State field(s) for TabBar widget.
  TabController? tabBarController1;
  int get tabBarCurrentIndex1 =>
      tabBarController1 != null ? tabBarController1!.index : 0;
  int get tabBarPreviousIndex1 =>
      tabBarController1 != null ? tabBarController1!.previousIndex : 0;

  bool isDataUploading_changepfp = false;
  FFUploadedFile uploadedLocalFile_changepfp =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  String uploadedFileUrl_changepfp = '';

  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode1;
  TextEditingController? textController1;
  String? Function(BuildContext, String?)? textController1Validator;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode2;
  TextEditingController? textController2;
  String? Function(BuildContext, String?)? textController2Validator;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode3;
  TextEditingController? textController3;
  String? Function(BuildContext, String?)? textController3Validator;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode4;
  TextEditingController? textController4;
  late MaskTextInputFormatter textFieldMask4;
  String? Function(BuildContext, String?)? textController4Validator;
  // State field(s) for driveremail widget.
  FocusNode? driveremailFocusNode;
  TextEditingController? driveremailTextController;
  String? Function(BuildContext, String?)? driveremailTextControllerValidator;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode5;
  TextEditingController? textController5;
  late MaskTextInputFormatter textFieldMask5;
  String? Function(BuildContext, String?)? textController5Validator;
  // State field(s) for TabBar widget.
  TabController? tabBarController2;
  int get tabBarCurrentIndex2 =>
      tabBarController2 != null ? tabBarController2!.index : 0;
  int get tabBarPreviousIndex2 =>
      tabBarController2 != null ? tabBarController2!.previousIndex : 0;

  bool isDataUploading_changepfp2Fm = false;
  FFUploadedFile uploadedLocalFile_changepfp2Fm =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  String uploadedFileUrl_changepfp2Fm = '';

  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode6;
  TextEditingController? textController6;
  String? Function(BuildContext, String?)? textController6Validator;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode7;
  TextEditingController? textController7;
  String? Function(BuildContext, String?)? textController7Validator;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode8;
  TextEditingController? textController8;
  String? Function(BuildContext, String?)? textController8Validator;
  // State field(s) for fmphone widget.
  FocusNode? fmphoneFocusNode;
  TextEditingController? fmphoneTextController;
  late MaskTextInputFormatter fmphoneMask;
  String? Function(BuildContext, String?)? fmphoneTextControllerValidator;
  // State field(s) for fmemail widget.
  FocusNode? fmemailFocusNode;
  TextEditingController? fmemailTextController;
  String? Function(BuildContext, String?)? fmemailTextControllerValidator;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode9;
  TextEditingController? textController10;
  late MaskTextInputFormatter textFieldMask9;
  String? Function(BuildContext, String?)? textController10Validator;
  // State field(s) for fleetcompany widget.
  FocusNode? fleetcompanyFocusNode;
  TextEditingController? fleetcompanyTextController;
  String? Function(BuildContext, String?)? fleetcompanyTextControllerValidator;
  // State field(s) for fm_companyreg widget.
  FocusNode? fmCompanyregFocusNode;
  TextEditingController? fmCompanyregTextController;
  late MaskTextInputFormatter fmCompanyregMask;
  String? Function(BuildContext, String?)? fmCompanyregTextControllerValidator;
  // State field(s) for fm_address widget.
  FocusNode? fmAddressFocusNode;
  TextEditingController? fmAddressTextController;
  String? Function(BuildContext, String?)? fmAddressTextControllerValidator;
  // State field(s) for fm_phone widget.
  FocusNode? fmPhoneFocusNode;
  TextEditingController? fmPhoneTextController;
  String? Function(BuildContext, String?)? fmPhoneTextControllerValidator;
  // State field(s) for fm_email widget.
  FocusNode? fmEmailFocusNode;
  TextEditingController? fmEmailTextController;
  String? Function(BuildContext, String?)? fmEmailTextControllerValidator;
  // State field(s) for fm_website widget.
  FocusNode? fmWebsiteFocusNode;
  TextEditingController? fmWebsiteTextController;
  String? Function(BuildContext, String?)? fmWebsiteTextControllerValidator;
  bool isDataUploading_uploadcompreg3 = false;
  FFUploadedFile uploadedLocalFile_uploadcompreg3 =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  String uploadedFileUrl_uploadcompreg3 = '';

  Completer<List<TransportersRow>>? requestCompleter;
  // State field(s) for TabBar widget.
  TabController? tabBarController3;
  int get tabBarCurrentIndex3 =>
      tabBarController3 != null ? tabBarController3!.index : 0;
  int get tabBarPreviousIndex3 =>
      tabBarController3 != null ? tabBarController3!.previousIndex : 0;

  bool isDataUploading_changepfp3 = false;
  FFUploadedFile uploadedLocalFile_changepfp3 =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  String uploadedFileUrl_changepfp3 = '';

  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode10;
  TextEditingController? textController17;
  String? Function(BuildContext, String?)? textController17Validator;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode11;
  TextEditingController? textController18;
  String? Function(BuildContext, String?)? textController18Validator;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode12;
  TextEditingController? textController19;
  String? Function(BuildContext, String?)? textController19Validator;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode13;
  TextEditingController? textController20;
  late MaskTextInputFormatter textFieldMask13;
  String? Function(BuildContext, String?)? textController20Validator;
  // State field(s) for email widget.
  FocusNode? emailFocusNode;
  TextEditingController? emailTextController;
  String? Function(BuildContext, String?)? emailTextControllerValidator;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode14;
  TextEditingController? textController22;
  String? Function(BuildContext, String?)? textController22Validator;
  // State field(s) for TabBar widget.
  TabController? tabBarController4;
  int get tabBarCurrentIndex4 =>
      tabBarController4 != null ? tabBarController4!.index : 0;
  int get tabBarPreviousIndex4 =>
      tabBarController4 != null ? tabBarController4!.previousIndex : 0;

  bool isDataUploading_changepfp8 = false;
  FFUploadedFile uploadedLocalFile_changepfp8 =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  String uploadedFileUrl_changepfp8 = '';

  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode15;
  TextEditingController? textController23;
  String? Function(BuildContext, String?)? textController23Validator;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode16;
  TextEditingController? textController24;
  String? Function(BuildContext, String?)? textController24Validator;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode17;
  TextEditingController? textController25;
  String? Function(BuildContext, String?)? textController25Validator;
  // State field(s) for techphone widget.
  FocusNode? techphoneFocusNode;
  TextEditingController? techphoneTextController;
  String? Function(BuildContext, String?)? techphoneTextControllerValidator;
  // State field(s) for techemail widget.
  FocusNode? techemailFocusNode;
  TextEditingController? techemailTextController;
  String? Function(BuildContext, String?)? techemailTextControllerValidator;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode18;
  TextEditingController? textController27;
  String? Function(BuildContext, String?)? textController27Validator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    tabBarController1?.dispose();
    textFieldFocusNode1?.dispose();
    textController1?.dispose();

    textFieldFocusNode2?.dispose();
    textController2?.dispose();

    textFieldFocusNode3?.dispose();
    textController3?.dispose();

    textFieldFocusNode4?.dispose();
    textController4?.dispose();

    driveremailFocusNode?.dispose();
    driveremailTextController?.dispose();

    textFieldFocusNode5?.dispose();
    textController5?.dispose();

    tabBarController2?.dispose();
    textFieldFocusNode6?.dispose();
    textController6?.dispose();

    textFieldFocusNode7?.dispose();
    textController7?.dispose();

    textFieldFocusNode8?.dispose();
    textController8?.dispose();

    fmphoneFocusNode?.dispose();
    fmphoneTextController?.dispose();

    fmemailFocusNode?.dispose();
    fmemailTextController?.dispose();

    textFieldFocusNode9?.dispose();
    textController10?.dispose();

    fleetcompanyFocusNode?.dispose();
    fleetcompanyTextController?.dispose();

    fmCompanyregFocusNode?.dispose();
    fmCompanyregTextController?.dispose();

    fmAddressFocusNode?.dispose();
    fmAddressTextController?.dispose();

    fmPhoneFocusNode?.dispose();
    fmPhoneTextController?.dispose();

    fmEmailFocusNode?.dispose();
    fmEmailTextController?.dispose();

    fmWebsiteFocusNode?.dispose();
    fmWebsiteTextController?.dispose();

    tabBarController3?.dispose();
    textFieldFocusNode10?.dispose();
    textController17?.dispose();

    textFieldFocusNode11?.dispose();
    textController18?.dispose();

    textFieldFocusNode12?.dispose();
    textController19?.dispose();

    textFieldFocusNode13?.dispose();
    textController20?.dispose();

    emailFocusNode?.dispose();
    emailTextController?.dispose();

    textFieldFocusNode14?.dispose();
    textController22?.dispose();

    tabBarController4?.dispose();
    textFieldFocusNode15?.dispose();
    textController23?.dispose();

    textFieldFocusNode16?.dispose();
    textController24?.dispose();

    textFieldFocusNode17?.dispose();
    textController25?.dispose();

    techphoneFocusNode?.dispose();
    techphoneTextController?.dispose();

    techemailFocusNode?.dispose();
    techemailTextController?.dispose();

    textFieldFocusNode18?.dispose();
    textController27?.dispose();
  }

  /// Additional helper methods.
  Future waitForRequestCompleted({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }
}

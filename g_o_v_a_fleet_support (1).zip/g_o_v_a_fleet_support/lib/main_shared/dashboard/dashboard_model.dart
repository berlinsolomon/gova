import '/auth/firebase_auth/auth_util.dart';
import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/backend/push_notifications/push_notifications_util.dart';
import '/backend/schema/structs/index.dart';
import '/backend/supabase/supabase.dart';
import '/components/completejob/completejob_widget.dart';
import '/components/emptyactiveincidents/emptyactiveincidents_widget.dart';
import '/components/emptyincidenthistory/emptyincidenthistory_widget.dart';
import '/fleetmanager/incidentalert/incidentalert_widget.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_choice_chips.dart';
import '/flutter_flow/flutter_flow_expanded_image_view.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/flutter_flow/instant_timer.dart';
import '/flutter_flow/upload_data.dart';
import '/serviceprovider/assignstaff/assignstaff_widget.dart';
import '/serviceprovider/sp_incidentalert/sp_incidentalert_widget.dart';
import '/technician/technician_incident/technician_incident_widget.dart';
import '/technician/welcomecode_technician/welcomecode_technician_widget.dart';
import 'dart:math';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/flutter_flow/custom_functions.dart' as functions;
import '/flutter_flow/permissions_util.dart';
import '/index.dart';
import 'dart:async';
import 'dashboard_widget.dart' show DashboardWidget;
import 'package:map_launcher/map_launcher.dart' as $ml;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_blurhash/flutter_blurhash.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:octo_image/octo_image.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';

class DashboardModel extends FlutterFlowModel<DashboardWidget> {
  ///  Local state fields for this page.

  String? address;

  String jobsview = 'In Progress';

  ///  State fields for stateful widgets in this page.

  // Stores action output result for [Custom Action - getAddressFromLatLng] action in dashboard widget.
  String? getaddress;
  // Stores action output result for [Backend Call - Query Rows] action in dashboard widget.
  List<UsersRow>? finduser;
  InstantTimer? instantTimer;
  Completer<List<RequestsRow>>? requestCompleter4;
  // Stores action output result for [Backend Call - Query Rows] action in dashboard widget.
  List<RequestsRow>? findincidents;
  InstantTimer? instantTimer2;
  Completer<List<RequestsRow>>? requestCompleter3;
  // Stores action output result for [Backend Call - Query Rows] action in dashboard widget.
  List<RequestsRow>? findmyincidents;
  InstantTimer? instantTimer3;
  Completer<List<RequestsRow>>? requestCompleter1;
  // Stores action output result for [Backend Call - Query Rows] action in dashboard widget.
  List<RequestsRow>? findmyincidents3;
  // Stores action output result for [Custom Action - getAddressFromLatLng] action in Container widget.
  String? currentaddress;
  // State field(s) for ChoiceChips widget.
  FormFieldController<List<String>>? choiceChipsValueController1;
  String? get choiceChipsValue1 =>
      choiceChipsValueController1?.value?.firstOrNull;
  set choiceChipsValue1(String? val) =>
      choiceChipsValueController1?.value = val != null ? [val] : [];
  // State field(s) for ChoiceChips widget.
  FormFieldController<List<String>>? choiceChipsValueController2;
  String? get choiceChipsValue2 =>
      choiceChipsValueController2?.value?.firstOrNull;
  set choiceChipsValue2(String? val) =>
      choiceChipsValueController2?.value = val != null ? [val] : [];
  Completer<List<RequestsRow>>? requestCompleter2;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<UsersRow>? findfleetmanage;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  UsersRecord? findrequestorFb;
  bool isDataUploading_vehicleimage = false;
  FFUploadedFile uploadedLocalFile_vehicleimage =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  String uploadedFileUrl_vehicleimage = '';

  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  UsersRecord? findrequestorFb2;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<UsersRow>? findfleetmanager;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  List<UsersRecord>? findfleetmanagerFb2;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<UsersRow>? findserviceprov;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  List<UsersRecord>? findserviceprovFb1;
  // Stores action output result for [Backend Call - API (Technician arrived)] action in Button widget.
  ApiCallResponse? alertfm;
  Completer<List<UsersRow>>? requestCompleter5;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    instantTimer?.cancel();
    instantTimer2?.cancel();
    instantTimer3?.cancel();
  }

  /// Additional helper methods.
  Future waitForRequestCompleted4({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter4?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }

  Future waitForRequestCompleted3({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter3?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }

  Future waitForRequestCompleted1({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter1?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }

  Future waitForRequestCompleted2({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter2?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }

  Future waitForRequestCompleted5({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter5?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }
}

import '/auth/firebase_auth/auth_util.dart';
import '/backend/supabase/supabase.dart';
import '/components/emptystaff/emptystaff_widget.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:math';
import 'dart:ui';
import 'dart:async';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';
import 'transfers_fleetprovider_model.dart';
export 'transfers_fleetprovider_model.dart';

class TransfersFleetproviderWidget extends StatefulWidget {
  const TransfersFleetproviderWidget({super.key});

  static String routeName = 'transfers_fleetprovider';
  static String routePath = '/transfersFleetprovider';

  @override
  State<TransfersFleetproviderWidget> createState() =>
      _TransfersFleetproviderWidgetState();
}

class _TransfersFleetproviderWidgetState
    extends State<TransfersFleetproviderWidget> with TickerProviderStateMixin {
  late TransfersFleetproviderModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => TransfersFleetproviderModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<UsersRow>>(
      future: FFAppState().user(
        uniqueQueryKey: currentUserUid,
        requestFn: () => UsersTable().querySingleRow(
          queryFn: (q) => q.eqOrNull(
            'uid',
            currentUserUid,
          ),
        ),
      ),
      builder: (context, snapshot) {
        // Customize what your widget looks like when it's loading.
        if (!snapshot.hasData) {
          return Scaffold(
            backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
            body: Center(
              child: SizedBox(
                width: 10.0,
                height: 10.0,
                child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(
                    Color(0x00EE8B60),
                  ),
                ),
              ),
            ),
          );
        }
        List<UsersRow> transfersFleetproviderUsersRowList = snapshot.data!;

        final transfersFleetproviderUsersRow =
            transfersFleetproviderUsersRowList.isNotEmpty
                ? transfersFleetproviderUsersRowList.first
                : null;

        return GestureDetector(
          onTap: () {
            FocusScope.of(context).unfocus();
            FocusManager.instance.primaryFocus?.unfocus();
          },
          child: Scaffold(
            key: scaffoldKey,
            backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
            appBar: AppBar(
              backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
              automaticallyImplyLeading: false,
              leading: FlutterFlowIconButton(
                borderColor: Colors.transparent,
                borderRadius: 30.0,
                borderWidth: 1.0,
                buttonSize: 60.0,
                icon: Icon(
                  Icons.arrow_back_rounded,
                  color: FlutterFlowTheme.of(context).primaryText,
                  size: 24.0,
                ),
                onPressed: () async {
                  context.pop();
                },
              ),
              title: Text(
                'Pending Transfers',
                style: FlutterFlowTheme.of(context).headlineMedium.override(
                      font: GoogleFonts.lato(
                        fontWeight: FlutterFlowTheme.of(context)
                            .headlineMedium
                            .fontWeight,
                        fontStyle: FlutterFlowTheme.of(context)
                            .headlineMedium
                            .fontStyle,
                      ),
                      color: FlutterFlowTheme.of(context).primaryText,
                      fontSize: 20.0,
                      letterSpacing: 0.0,
                      fontWeight: FlutterFlowTheme.of(context)
                          .headlineMedium
                          .fontWeight,
                      fontStyle:
                          FlutterFlowTheme.of(context).headlineMedium.fontStyle,
                    ),
              ),
              actions: [],
              centerTitle: true,
              elevation: 0.0,
            ),
            body: SafeArea(
              top: true,
              child: Stack(
                children: [
                  if (transfersFleetproviderUsersRow?.currentrole ==
                      'Fleet Manager')
                    Padding(
                      padding: EdgeInsets.all(16.0),
                      child: FutureBuilder<List<TransfersRow>>(
                        future: (_model.requestCompleter2 ??=
                                Completer<List<TransfersRow>>()
                                  ..complete(TransfersTable().queryRows(
                                    queryFn: (q) => q
                                        .eqOrNull(
                                          'status',
                                          'Pending',
                                        )
                                        .eqOrNull(
                                          'new_transporter',
                                          transfersFleetproviderUsersRow
                                              ?.transporterId,
                                        ),
                                  )))
                            .future,
                        builder: (context, snapshot) {
                          // Customize what your widget looks like when it's loading.
                          if (!snapshot.hasData) {
                            return Center(
                              child: SizedBox(
                                width: 10.0,
                                height: 10.0,
                                child: CircularProgressIndicator(
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                    Color(0x00EE8B60),
                                  ),
                                ),
                              ),
                            );
                          }
                          List<TransfersRow>
                              driverstransferListTransfersRowList =
                              snapshot.data!;

                          if (driverstransferListTransfersRowList.isEmpty) {
                            return EmptystaffWidget();
                          }

                          return ListView.builder(
                            padding: EdgeInsets.zero,
                            scrollDirection: Axis.vertical,
                            itemCount:
                                driverstransferListTransfersRowList.length,
                            itemBuilder: (context, driverstransferListIndex) {
                              final driverstransferListTransfersRow =
                                  driverstransferListTransfersRowList[
                                      driverstransferListIndex];
                              return Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    0.0, 0.0, 0.0, 1.0),
                                child: Container(
                                  width: 100.0,
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                    boxShadow: [
                                      BoxShadow(
                                        blurRadius: 0.0,
                                        color: FlutterFlowTheme.of(context)
                                            .alternate,
                                        offset: Offset(
                                          0.0,
                                          1.0,
                                        ),
                                      )
                                    ],
                                  ),
                                  child: Padding(
                                    padding: EdgeInsets.all(16.0),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Expanded(
                                          child: Padding(
                                            padding:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    12.0, 0.0, 0.0, 0.0),
                                            child: Column(
                                              mainAxisSize: MainAxisSize.max,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  valueOrDefault<String>(
                                                    driverstransferListTransfersRow
                                                        .name,
                                                    '-',
                                                  ),
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .bodyLarge
                                                      .override(
                                                        font: GoogleFonts.lato(
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .bodyLarge
                                                                  .fontStyle,
                                                        ),
                                                        letterSpacing: 0.0,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        fontStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .bodyLarge
                                                                .fontStyle,
                                                      ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        FlutterFlowIconButton(
                                          borderColor: Color(0xFF006A3E),
                                          borderRadius: 20.0,
                                          borderWidth: 2.0,
                                          buttonSize: 40.0,
                                          fillColor: Color(0x5416DB93),
                                          icon: Icon(
                                            Icons.done_all,
                                            color: Color(0xFF006A3E),
                                            size: 24.0,
                                          ),
                                          showLoadingIndicator: true,
                                          onPressed: () async {
                                            var confirmDialogResponse =
                                                await showDialog<bool>(
                                                      context: context,
                                                      builder:
                                                          (alertDialogContext) {
                                                        return WebViewAware(
                                                          child: AlertDialog(
                                                            title: Text(
                                                                'Confirm this transfer'),
                                                            content: Text(
                                                                'Do you want to verify ${driverstransferListTransfersRow.name}?'),
                                                            actions: [
                                                              TextButton(
                                                                onPressed: () =>
                                                                    Navigator.pop(
                                                                        alertDialogContext,
                                                                        false),
                                                                child: Text(
                                                                    'Cancel'),
                                                              ),
                                                              TextButton(
                                                                onPressed: () =>
                                                                    Navigator.pop(
                                                                        alertDialogContext,
                                                                        true),
                                                                child: Text(
                                                                    'Confirm'),
                                                              ),
                                                            ],
                                                          ),
                                                        );
                                                      },
                                                    ) ??
                                                    false;
                                            if (confirmDialogResponse) {
                                              _model.userDriver =
                                                  await UsersTable().update(
                                                data: {
                                                  'transfer_pending': false,
                                                  'transporter_id':
                                                      transfersFleetproviderUsersRow
                                                          ?.transporterId,
                                                  'transporter_name':
                                                      transfersFleetproviderUsersRow
                                                          ?.transporterName,
                                                },
                                                matchingRows: (rows) =>
                                                    rows.eqOrNull(
                                                  'uid',
                                                  driverstransferListTransfersRow
                                                      .uid,
                                                ),
                                                returnRows: true,
                                              );
                                              await TransporterStaffTable()
                                                  .update(
                                                data: {
                                                  'fleetcompany':
                                                      transfersFleetproviderUsersRow
                                                          ?.transporterId,
                                                },
                                                matchingRows: (rows) =>
                                                    rows.eqOrNull(
                                                  'id',
                                                  _model.userDriver?.firstOrNull
                                                      ?.transporterStaffid,
                                                ),
                                              );
                                              await TransfersTable().update(
                                                data: {
                                                  'status': 'Approved',
                                                },
                                                matchingRows: (rows) =>
                                                    rows.eqOrNull(
                                                  'id',
                                                  driverstransferListTransfersRow
                                                      .id,
                                                ),
                                              );
                                              await showDialog(
                                                context: context,
                                                builder: (alertDialogContext) {
                                                  return WebViewAware(
                                                    child: AlertDialog(
                                                      title: Text(
                                                          '${driverstransferListTransfersRow.name}has been transferred to your company.'),
                                                      actions: [
                                                        TextButton(
                                                          onPressed: () =>
                                                              Navigator.pop(
                                                                  alertDialogContext),
                                                          child: Text('OK'),
                                                        ),
                                                      ],
                                                    ),
                                                  );
                                                },
                                              );
                                              safeSetState(() => _model
                                                  .requestCompleter2 = null);
                                            }

                                            safeSetState(() {});
                                          },
                                        ),
                                        Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  12.0, 0.0, 0.0, 0.0),
                                          child: FlutterFlowIconButton(
                                            borderColor: Color(0xFFDD0D4A),
                                            borderRadius: 20.0,
                                            borderWidth: 2.0,
                                            buttonSize: 40.0,
                                            fillColor: Color(0xFFFFA0BB),
                                            icon: Icon(
                                              Icons.close_outlined,
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .primaryText,
                                              size: 24.0,
                                            ),
                                            onPressed: () async {
                                              var confirmDialogResponse =
                                                  await showDialog<bool>(
                                                        context: context,
                                                        builder:
                                                            (alertDialogContext) {
                                                          return WebViewAware(
                                                            child: AlertDialog(
                                                              title: Text(
                                                                  'Decline this transfer'),
                                                              content: Text(
                                                                  'Do you want to verify ${driverstransferListTransfersRow.name}?'),
                                                              actions: [
                                                                TextButton(
                                                                  onPressed: () =>
                                                                      Navigator.pop(
                                                                          alertDialogContext,
                                                                          false),
                                                                  child: Text(
                                                                      'Cancel'),
                                                                ),
                                                                TextButton(
                                                                  onPressed: () =>
                                                                      Navigator.pop(
                                                                          alertDialogContext,
                                                                          true),
                                                                  child: Text(
                                                                      'Confirm'),
                                                                ),
                                                              ],
                                                            ),
                                                          );
                                                        },
                                                      ) ??
                                                      false;
                                              if (confirmDialogResponse) {
                                                _model.userDriver2 =
                                                    await UsersTable().update(
                                                  data: {
                                                    'transfer_pending': false,
                                                  },
                                                  matchingRows: (rows) =>
                                                      rows.eqOrNull(
                                                    'uid',
                                                    driverstransferListTransfersRow
                                                        .uid,
                                                  ),
                                                  returnRows: true,
                                                );
                                                await TransfersTable().update(
                                                  data: {
                                                    'status': 'Declined',
                                                  },
                                                  matchingRows: (rows) =>
                                                      rows.eqOrNull(
                                                    'id',
                                                    driverstransferListTransfersRow
                                                        .id,
                                                  ),
                                                );
                                                await showDialog(
                                                  context: context,
                                                  builder:
                                                      (alertDialogContext) {
                                                    return WebViewAware(
                                                      child: AlertDialog(
                                                        title: Text(
                                                            'Transfer of ${driverstransferListTransfersRow.name} was declined.'),
                                                        actions: [
                                                          TextButton(
                                                            onPressed: () =>
                                                                Navigator.pop(
                                                                    alertDialogContext),
                                                            child: Text('OK'),
                                                          ),
                                                        ],
                                                      ),
                                                    );
                                                  },
                                                );
                                                safeSetState(() => _model
                                                    .requestCompleter2 = null);
                                              }

                                              safeSetState(() {});
                                            },
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              );
                            },
                          );
                        },
                      ),
                    ),
                  if (transfersFleetproviderUsersRow?.currentrole ==
                      'Service Provider')
                    Padding(
                      padding: EdgeInsets.all(16.0),
                      child: FutureBuilder<List<TransfersRow>>(
                        future: (_model.requestCompleter1 ??=
                                Completer<List<TransfersRow>>()
                                  ..complete(TransfersTable().queryRows(
                                    queryFn: (q) => q
                                        .eqOrNull(
                                          'status',
                                          'Pending',
                                        )
                                        .eqOrNull(
                                          'new_provider',
                                          transfersFleetproviderUsersRow
                                              ?.serviceProvider,
                                        ),
                                  )))
                            .future,
                        builder: (context, snapshot) {
                          // Customize what your widget looks like when it's loading.
                          if (!snapshot.hasData) {
                            return Center(
                              child: SizedBox(
                                width: 10.0,
                                height: 10.0,
                                child: CircularProgressIndicator(
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                    Color(0x00EE8B60),
                                  ),
                                ),
                              ),
                            );
                          }
                          List<TransfersRow>
                              technicianTransferlistTransfersRowList =
                              snapshot.data!;

                          if (technicianTransferlistTransfersRowList.isEmpty) {
                            return EmptystaffWidget();
                          }

                          return ListView.builder(
                            padding: EdgeInsets.zero,
                            scrollDirection: Axis.vertical,
                            itemCount:
                                technicianTransferlistTransfersRowList.length,
                            itemBuilder:
                                (context, technicianTransferlistIndex) {
                              final technicianTransferlistTransfersRow =
                                  technicianTransferlistTransfersRowList[
                                      technicianTransferlistIndex];
                              return Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    0.0, 0.0, 0.0, 1.0),
                                child: Container(
                                  width: 100.0,
                                  decoration: BoxDecoration(
                                    color: FlutterFlowTheme.of(context)
                                        .secondaryBackground,
                                    boxShadow: [
                                      BoxShadow(
                                        blurRadius: 0.0,
                                        color: FlutterFlowTheme.of(context)
                                            .alternate,
                                        offset: Offset(
                                          0.0,
                                          1.0,
                                        ),
                                      )
                                    ],
                                  ),
                                  child: Padding(
                                    padding: EdgeInsets.all(16.0),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Expanded(
                                          child: Padding(
                                            padding:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    12.0, 0.0, 0.0, 0.0),
                                            child: Column(
                                              mainAxisSize: MainAxisSize.max,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  valueOrDefault<String>(
                                                    technicianTransferlistTransfersRow
                                                        .name,
                                                    '-',
                                                  ),
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .bodyLarge
                                                      .override(
                                                        font: GoogleFonts.lato(
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .bodyLarge
                                                                  .fontStyle,
                                                        ),
                                                        letterSpacing: 0.0,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        fontStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .bodyLarge
                                                                .fontStyle,
                                                      ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        FlutterFlowIconButton(
                                          borderColor: Color(0xFF006A3E),
                                          borderRadius: 20.0,
                                          borderWidth: 2.0,
                                          buttonSize: 40.0,
                                          fillColor: Color(0x5416DB93),
                                          icon: Icon(
                                            Icons.done_all,
                                            color: Color(0xFF006A3E),
                                            size: 24.0,
                                          ),
                                          showLoadingIndicator: true,
                                          onPressed: () async {
                                            var confirmDialogResponse =
                                                await showDialog<bool>(
                                                      context: context,
                                                      builder:
                                                          (alertDialogContext) {
                                                        return WebViewAware(
                                                          child: AlertDialog(
                                                            title: Text(
                                                                'Confirm this transfer'),
                                                            content: Text(
                                                                'Do you want to verify ${technicianTransferlistTransfersRow.name}?'),
                                                            actions: [
                                                              TextButton(
                                                                onPressed: () =>
                                                                    Navigator.pop(
                                                                        alertDialogContext,
                                                                        false),
                                                                child: Text(
                                                                    'Cancel'),
                                                              ),
                                                              TextButton(
                                                                onPressed: () =>
                                                                    Navigator.pop(
                                                                        alertDialogContext,
                                                                        true),
                                                                child: Text(
                                                                    'Confirm'),
                                                              ),
                                                            ],
                                                          ),
                                                        );
                                                      },
                                                    ) ??
                                                    false;
                                            if (confirmDialogResponse) {
                                              _model.userTech =
                                                  await UsersTable().update(
                                                data: {
                                                  'transfer_pending': false,
                                                  'service_provider':
                                                      transfersFleetproviderUsersRow
                                                          ?.serviceProvider,
                                                },
                                                matchingRows: (rows) =>
                                                    rows.eqOrNull(
                                                  'uid',
                                                  technicianTransferlistTransfersRow
                                                      .uid,
                                                ),
                                                returnRows: true,
                                              );
                                              await ServiceproviderStaffTable()
                                                  .update(
                                                data: {
                                                  'service_provider':
                                                      transfersFleetproviderUsersRow
                                                          ?.serviceProvider,
                                                },
                                                matchingRows: (rows) =>
                                                    rows.eqOrNull(
                                                  'id',
                                                  _model.userTech?.firstOrNull
                                                      ?.servproviderStaffid,
                                                ),
                                              );
                                              await TransfersTable().update(
                                                data: {
                                                  'status': 'Approved',
                                                },
                                                matchingRows: (rows) =>
                                                    rows.eqOrNull(
                                                  'id',
                                                  technicianTransferlistTransfersRow
                                                      .id,
                                                ),
                                              );
                                              await showDialog(
                                                context: context,
                                                builder: (alertDialogContext) {
                                                  return WebViewAware(
                                                    child: AlertDialog(
                                                      title: Text(
                                                          '${technicianTransferlistTransfersRow.name}has been transferred to your company.'),
                                                      actions: [
                                                        TextButton(
                                                          onPressed: () =>
                                                              Navigator.pop(
                                                                  alertDialogContext),
                                                          child: Text('OK'),
                                                        ),
                                                      ],
                                                    ),
                                                  );
                                                },
                                              );
                                              safeSetState(() => _model
                                                  .requestCompleter1 = null);
                                            }

                                            safeSetState(() {});
                                          },
                                        ),
                                        Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  12.0, 0.0, 0.0, 0.0),
                                          child: FlutterFlowIconButton(
                                            borderColor: Color(0xFFDD0D4A),
                                            borderRadius: 20.0,
                                            borderWidth: 2.0,
                                            buttonSize: 40.0,
                                            fillColor: Color(0xFFFFA0BB),
                                            icon: Icon(
                                              Icons.close_outlined,
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .primaryText,
                                              size: 24.0,
                                            ),
                                            onPressed: () async {
                                              var confirmDialogResponse =
                                                  await showDialog<bool>(
                                                        context: context,
                                                        builder:
                                                            (alertDialogContext) {
                                                          return WebViewAware(
                                                            child: AlertDialog(
                                                              title: Text(
                                                                  'Decline this transfer'),
                                                              content: Text(
                                                                  'Do you want to verify ${technicianTransferlistTransfersRow.name}?'),
                                                              actions: [
                                                                TextButton(
                                                                  onPressed: () =>
                                                                      Navigator.pop(
                                                                          alertDialogContext,
                                                                          false),
                                                                  child: Text(
                                                                      'Cancel'),
                                                                ),
                                                                TextButton(
                                                                  onPressed: () =>
                                                                      Navigator.pop(
                                                                          alertDialogContext,
                                                                          true),
                                                                  child: Text(
                                                                      'Confirm'),
                                                                ),
                                                              ],
                                                            ),
                                                          );
                                                        },
                                                      ) ??
                                                      false;
                                              if (confirmDialogResponse) {
                                                _model.userTech2 =
                                                    await UsersTable().update(
                                                  data: {
                                                    'transfer_pending': false,
                                                  },
                                                  matchingRows: (rows) =>
                                                      rows.eqOrNull(
                                                    'uid',
                                                    technicianTransferlistTransfersRow
                                                        .uid,
                                                  ),
                                                  returnRows: true,
                                                );
                                                await TransfersTable().update(
                                                  data: {
                                                    'status': 'Declined',
                                                  },
                                                  matchingRows: (rows) =>
                                                      rows.eqOrNull(
                                                    'id',
                                                    technicianTransferlistTransfersRow
                                                        .id,
                                                  ),
                                                );
                                                await showDialog(
                                                  context: context,
                                                  builder:
                                                      (alertDialogContext) {
                                                    return WebViewAware(
                                                      child: AlertDialog(
                                                        title: Text(
                                                            'Transfer of ${technicianTransferlistTransfersRow.name} was declined.'),
                                                        actions: [
                                                          TextButton(
                                                            onPressed: () =>
                                                                Navigator.pop(
                                                                    alertDialogContext),
                                                            child: Text('OK'),
                                                          ),
                                                        ],
                                                      ),
                                                    );
                                                  },
                                                );
                                                safeSetState(() => _model
                                                    .requestCompleter1 = null);
                                              }

                                              safeSetState(() {});
                                            },
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              );
                            },
                          );
                        },
                      ),
                    ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

import 'package:flutter/material.dart';
import 'flutter_flow/request_manager.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/api_requests/api_manager.dart';
import 'backend/supabase/supabase.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    prefs = await SharedPreferences.getInstance();
    _safeInit(() {
      _currentrequest = prefs.getString('ff_currentrequest') ?? _currentrequest;
    });
    _safeInit(() {
      _role = prefs.getString('ff_role') ?? _role;
    });
    _safeInit(() {
      _transporterid = prefs.getInt('ff_transporterid') ?? _transporterid;
    });
    _safeInit(() {
      _seenwelcome = prefs.getBool('ff_seenwelcome') ?? _seenwelcome;
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late SharedPreferences prefs;

  String _currentrequest = '';
  String get currentrequest => _currentrequest;
  set currentrequest(String value) {
    _currentrequest = value;
    prefs.setString('ff_currentrequest', value);
  }

  String _page = 'Dashboard';
  String get page => _page;
  set page(String value) {
    _page = value;
  }

  String _role = '';
  String get role => _role;
  set role(String value) {
    _role = value;
    prefs.setString('ff_role', value);
  }

  int _transporterid = 0;
  int get transporterid => _transporterid;
  set transporterid(int value) {
    _transporterid = value;
    prefs.setInt('ff_transporterid', value);
  }

  int _serviceproviderid = 0;
  int get serviceproviderid => _serviceproviderid;
  set serviceproviderid(int value) {
    _serviceproviderid = value;
  }

  bool _seenwelcome = false;
  bool get seenwelcome => _seenwelcome;
  set seenwelcome(bool value) {
    _seenwelcome = value;
    prefs.setBool('ff_seenwelcome', value);
  }

  List<ContactStruct> _contacts = [];
  List<ContactStruct> get contacts => _contacts;
  set contacts(List<ContactStruct> value) {
    _contacts = value;
  }

  void addToContacts(ContactStruct value) {
    contacts.add(value);
  }

  void removeFromContacts(ContactStruct value) {
    contacts.remove(value);
  }

  void removeAtIndexFromContacts(int index) {
    contacts.removeAt(index);
  }

  void updateContactsAtIndex(
    int index,
    ContactStruct Function(ContactStruct) updateFn,
  ) {
    contacts[index] = updateFn(_contacts[index]);
  }

  void insertAtIndexInContacts(int index, ContactStruct value) {
    contacts.insert(index, value);
  }

  final _userManager = FutureRequestManager<List<UsersRow>>();
  Future<List<UsersRow>> user({
    String? uniqueQueryKey,
    bool? overrideCache,
    required Future<List<UsersRow>> Function() requestFn,
  }) =>
      _userManager.performRequest(
        uniqueQueryKey: uniqueQueryKey,
        overrideCache: overrideCache,
        requestFn: requestFn,
      );
  void clearUserCache() => _userManager.clear();
  void clearUserCacheKey(String? uniqueKey) =>
      _userManager.clearRequest(uniqueKey);

  final _servicesManager = FutureRequestManager<List<ServicesRow>>();
  Future<List<ServicesRow>> services({
    String? uniqueQueryKey,
    bool? overrideCache,
    required Future<List<ServicesRow>> Function() requestFn,
  }) =>
      _servicesManager.performRequest(
        uniqueQueryKey: uniqueQueryKey,
        overrideCache: overrideCache,
        requestFn: requestFn,
      );
  void clearServicesCache() => _servicesManager.clear();
  void clearServicesCacheKey(String? uniqueKey) =>
      _servicesManager.clearRequest(uniqueKey);

  final _techniciansManager =
      FutureRequestManager<List<ServiceproviderStaffRow>>();
  Future<List<ServiceproviderStaffRow>> technicians({
    String? uniqueQueryKey,
    bool? overrideCache,
    required Future<List<ServiceproviderStaffRow>> Function() requestFn,
  }) =>
      _techniciansManager.performRequest(
        uniqueQueryKey: uniqueQueryKey,
        overrideCache: overrideCache,
        requestFn: requestFn,
      );
  void clearTechniciansCache() => _techniciansManager.clear();
  void clearTechniciansCacheKey(String? uniqueKey) =>
      _techniciansManager.clearRequest(uniqueKey);

  final _serviceproviderManager =
      FutureRequestManager<List<ServiceprovidersRow>>();
  Future<List<ServiceprovidersRow>> serviceprovider({
    String? uniqueQueryKey,
    bool? overrideCache,
    required Future<List<ServiceprovidersRow>> Function() requestFn,
  }) =>
      _serviceproviderManager.performRequest(
        uniqueQueryKey: uniqueQueryKey,
        overrideCache: overrideCache,
        requestFn: requestFn,
      );
  void clearServiceproviderCache() => _serviceproviderManager.clear();
  void clearServiceproviderCacheKey(String? uniqueKey) =>
      _serviceproviderManager.clearRequest(uniqueKey);
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}

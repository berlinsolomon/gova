import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/push_notifications/push_notifications_util.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import 'cancel_request_widget.dart' show CancelRequestWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';

class CancelRequestModel extends FlutterFlowModel<CancelRequestWidget> {
  ///  State fields for stateful widgets in this component.

  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? Function(BuildContext, String?)? textControllerValidator;
  // Stores action output result for [Backend Call - Insert Row] action in Button widget.
  CancellationRequestsRow? newrequestDriver;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<UsersRow>? findfleetmanagersDriver;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  List<UsersRecord>? findfleetmanagersfbDriver;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<CancellationRequestsRow>? checkifcancellationalready;
  // Stores action output result for [Backend Call - Update Row(s)] action in Button widget.
  List<CancellationRequestsRow>? updaterequestProvider;
  // Stores action output result for [Backend Call - Insert Row] action in Button widget.
  CancellationRequestsRow? newrequestProvider;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<UsersRow>? findfleetmanagers;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  List<UsersRecord>? findfleetmanagersfb;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  UsersRecord? finddriverFb;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<UsersRow>? findtechnician;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  UsersRecord? findtech;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<CancellationRequestsRow>? checkifcancellationalreadyFm;
  // Stores action output result for [Backend Call - Update Row(s)] action in Button widget.
  List<CancellationRequestsRow>? updaterequestTransporter;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<UsersRow>? findprovideradmins;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  List<UsersRecord>? findadminsFb;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<UsersRow>? findchosentechnician;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  UsersRecord? findtechFb;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<UsersRow>? findprovideradmins2;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  List<UsersRecord>? findadminsFb2;
  // Stores action output result for [Backend Call - Insert Row] action in Button widget.
  CancellationRequestsRow? newrequestFleetmanager;
  // Stores action output result for [Backend Call - Insert Row] action in Button widget.
  CancellationRequestsRow? newrequestTechnician;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<UsersRow>? findprovideradminsTech;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  List<UsersRecord>? findadminsFbtech;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    textFieldFocusNode?.dispose();
    textController?.dispose();
  }
}

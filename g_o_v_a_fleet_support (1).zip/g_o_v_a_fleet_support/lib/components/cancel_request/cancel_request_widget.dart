import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/push_notifications/push_notifications_util.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';
import 'cancel_request_model.dart';
export 'cancel_request_model.dart';

class CancelRequestWidget extends StatefulWidget {
  const CancelRequestWidget({
    super.key,
    required this.incident,
    required this.refresh,
    required this.user,
  });

  final RequestsRow? incident;
  final Future Function(CancellationRequestsRow request)? refresh;
  final UsersRow? user;

  @override
  State<CancelRequestWidget> createState() => _CancelRequestWidgetState();
}

class _CancelRequestWidgetState extends State<CancelRequestWidget> {
  late CancelRequestModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CancelRequestModel());

    _model.textController ??= TextEditingController();
    _model.textFieldFocusNode ??= FocusNode();

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: AlignmentDirectional(0.0, 0.0),
      child: Padding(
        padding: EdgeInsets.all(24.0),
        child: Container(
          width: double.infinity,
          decoration: BoxDecoration(
            color: FlutterFlowTheme.of(context).secondaryBackground,
            borderRadius: BorderRadius.circular(16.0),
          ),
          child: Padding(
            padding: EdgeInsets.all(16.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 12.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Cancel Request',
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              font: GoogleFonts.lato(
                                fontWeight: FontWeight.w600,
                                fontStyle: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .fontStyle,
                              ),
                              fontSize: 16.0,
                              letterSpacing: 0.0,
                              fontWeight: FontWeight.w600,
                              fontStyle: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .fontStyle,
                            ),
                      ),
                      FlutterFlowIconButton(
                        borderRadius: 8.0,
                        buttonSize: 40.0,
                        icon: Icon(
                          Icons.close_sharp,
                          color: Color(0xFFDD0D4A),
                          size: 24.0,
                        ),
                        onPressed: () async {
                          Navigator.pop(context);
                        },
                      ),
                    ],
                  ),
                ),
                Text(
                  'Please enter the reason why you want to cancel this incident request',
                  textAlign: TextAlign.start,
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        font: GoogleFonts.lato(
                          fontWeight: FlutterFlowTheme.of(context)
                              .bodyMedium
                              .fontWeight,
                          fontStyle:
                              FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                        ),
                        letterSpacing: 0.0,
                        fontWeight:
                            FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                        fontStyle:
                            FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                      ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 20.0, 0.0, 20.0),
                  child: Container(
                    width: double.infinity,
                    child: TextFormField(
                      controller: _model.textController,
                      focusNode: _model.textFieldFocusNode,
                      autofocus: false,
                      textInputAction: TextInputAction.done,
                      obscureText: false,
                      decoration: InputDecoration(
                        isDense: true,
                        labelStyle:
                            FlutterFlowTheme.of(context).labelMedium.override(
                                  font: GoogleFonts.lato(
                                    fontWeight: FlutterFlowTheme.of(context)
                                        .labelMedium
                                        .fontWeight,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .labelMedium
                                        .fontStyle,
                                  ),
                                  letterSpacing: 0.0,
                                  fontWeight: FlutterFlowTheme.of(context)
                                      .labelMedium
                                      .fontWeight,
                                  fontStyle: FlutterFlowTheme.of(context)
                                      .labelMedium
                                      .fontStyle,
                                ),
                        hintText:
                            'Please provide more information as to why you want to cancel this incident request',
                        hintStyle:
                            FlutterFlowTheme.of(context).labelMedium.override(
                                  font: GoogleFonts.lato(
                                    fontWeight: FlutterFlowTheme.of(context)
                                        .labelMedium
                                        .fontWeight,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .labelMedium
                                        .fontStyle,
                                  ),
                                  letterSpacing: 0.0,
                                  fontWeight: FlutterFlowTheme.of(context)
                                      .labelMedium
                                      .fontWeight,
                                  fontStyle: FlutterFlowTheme.of(context)
                                      .labelMedium
                                      .fontStyle,
                                ),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: FlutterFlowTheme.of(context).alternate,
                            width: 2.0,
                          ),
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: Color(0xFF3800FF),
                            width: 2.0,
                          ),
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        errorBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: FlutterFlowTheme.of(context).error,
                            width: 2.0,
                          ),
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        focusedErrorBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: FlutterFlowTheme.of(context).error,
                            width: 2.0,
                          ),
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        filled: true,
                        fillColor:
                            FlutterFlowTheme.of(context).secondaryBackground,
                        contentPadding: EdgeInsetsDirectional.fromSTEB(
                            16.0, 20.0, 16.0, 20.0),
                      ),
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            font: GoogleFonts.lato(
                              fontWeight: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .fontWeight,
                              fontStyle: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .fontStyle,
                            ),
                            letterSpacing: 0.0,
                            fontWeight: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .fontWeight,
                            fontStyle: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .fontStyle,
                          ),
                      maxLines: 12,
                      minLines: 6,
                      cursorColor: FlutterFlowTheme.of(context).primaryText,
                      validator:
                          _model.textControllerValidator.asValidator(context),
                    ),
                  ),
                ),
                FFButtonWidget(
                  onPressed: () async {
                    var _shouldSetState = false;
                    if (widget!.user?.currentrole == 'Driver') {
                      if (_model.textController.text != null &&
                          _model.textController.text != '') {
                        _model.newrequestDriver =
                            await CancellationRequestsTable().insert({
                          'incident': widget!.incident?.id,
                          'initiator_name':
                              '${widget!.user?.firstName} ${widget!.user?.lastName}',
                          'initiator_uid': widget!.user?.uid,
                          'initiator_id': widget!.user?.id,
                          'initiator_role': 'Driver',
                          'status': 'Pending',
                          'cancellation_reason': _model.textController.text,
                          'transporter_id': widget!.user?.transporterId,
                        });
                        _shouldSetState = true;
                        _model.findfleetmanagersDriver =
                            await UsersTable().queryRows(
                          queryFn: (q) => q
                              .eqOrNull(
                                'transporter_id',
                                widget!.incident?.fleetcompanyId,
                              )
                              .eqOrNull(
                                'currentrole',
                                'Fleet Manager',
                              ),
                        );
                        _shouldSetState = true;
                        _model.findfleetmanagersfbDriver =
                            await queryUsersRecordOnce(
                          queryBuilder: (usersRecord) => usersRecord.whereIn(
                              'uid',
                              _model.findfleetmanagersDriver
                                  ?.map((e) => e.uid)
                                  .withoutNulls
                                  .toList()),
                        );
                        _shouldSetState = true;
                        triggerPushNotification(
                          notificationTitle: 'New Cancellation Request',
                          notificationText:
                              'Your driver (${widget!.incident?.requesterName}) has requested to cancel their incident request. Reason: ${_model.textController.text}',
                          notificationSound: 'default',
                          userRefs: _model.findfleetmanagersfbDriver!
                              .map((e) => e.reference)
                              .toList(),
                          initialPageName: 'request_details',
                          parameterData: {
                            'requestid': widget!.incident?.id,
                            'role': 'Fleet Manager',
                            'completed': false,
                          },
                        );
                        await widget.refresh?.call(
                          _model.newrequestDriver!,
                        );
                      } else {
                        await showDialog(
                          context: context,
                          builder: (alertDialogContext) {
                            return WebViewAware(
                              child: AlertDialog(
                                title:
                                    Text('Please add a reason for cancelling'),
                                actions: [
                                  TextButton(
                                    onPressed: () =>
                                        Navigator.pop(alertDialogContext),
                                    child: Text('Ok'),
                                  ),
                                ],
                              ),
                            );
                          },
                        );
                        if (_shouldSetState) safeSetState(() {});
                        return;
                      }
                    } else if (widget!.user?.currentrole ==
                        'Service Provider') {
                      _model.checkifcancellationalready =
                          await CancellationRequestsTable().queryRows(
                        queryFn: (q) => q
                            .eqOrNull(
                              'incident',
                              widget!.incident?.id,
                            )
                            .eqOrNull(
                              'service_provider',
                              widget!.user?.serviceProvider,
                            ),
                      );
                      _shouldSetState = true;
                      await RequestsTable().update(
                        data: {
                          'chosenprovider': null,
                          'chosen_providers': null,
                          'ignored_by': functions.addintegertolist(
                              widget!.user!.serviceProvider!,
                              widget!.incident!.ignoredBy.toList()),
                          'technician': null,
                          'technician_image': null,
                          'technician_phone': null,
                          'technician_userid': null,
                          'tech_vehicleimage': null,
                          'technicial_vehicle': null,
                          'technician_staffid': null,
                          'technician_numberplate': null,
                        },
                        matchingRows: (rows) => rows.eqOrNull(
                          'id',
                          widget!.incident?.id,
                        ),
                      );
                      if (_model.checkifcancellationalready != null &&
                          (_model.checkifcancellationalready)!.isNotEmpty) {
                        await CancellationRequestsTable().update(
                          data: {
                            'status': 'Successful',
                          },
                          matchingRows: (rows) => rows.eqOrNull(
                            'id',
                            _model.checkifcancellationalready?.firstOrNull?.id,
                          ),
                        );
                        _shouldSetState = true;
                        await widget.refresh?.call(
                          _model.updaterequestProvider!.firstOrNull!,
                        );
                      } else {
                        if (_model.textController.text != null &&
                            _model.textController.text != '') {
                          _model.newrequestProvider =
                              await CancellationRequestsTable().insert({
                            'incident': widget!.incident?.id,
                            'initiator_name':
                                '${widget!.user?.firstName} ${widget!.user?.lastName}',
                            'initiator_uid': widget!.user?.uid,
                            'initiator_id': widget!.user?.id,
                            'initiator_role': 'Service Provider',
                            'status': 'Successful',
                            'cancellation_reason': _model.textController.text,
                            'service_provider': widget!.user?.serviceProvider,
                          });
                          _shouldSetState = true;
                        } else {
                          await showDialog(
                            context: context,
                            builder: (alertDialogContext) {
                              return WebViewAware(
                                child: AlertDialog(
                                  title: Text(
                                      'Please add a reason for cancelling'),
                                  actions: [
                                    TextButton(
                                      onPressed: () =>
                                          Navigator.pop(alertDialogContext),
                                      child: Text('Ok'),
                                    ),
                                  ],
                                ),
                              );
                            },
                          );
                          if (_shouldSetState) safeSetState(() {});
                          return;
                        }
                      }

                      await Future.wait([
                        Future(() async {
                          _model.findfleetmanagers =
                              await UsersTable().queryRows(
                            queryFn: (q) => q
                                .eqOrNull(
                                  'transporter_id',
                                  widget!.incident?.fleetcompanyId,
                                )
                                .eqOrNull(
                                  'currentrole',
                                  'Fleet Manager',
                                ),
                          );
                          _shouldSetState = true;
                          _model.findfleetmanagersfb =
                              await queryUsersRecordOnce(
                            queryBuilder: (usersRecord) => usersRecord.whereIn(
                                'uid',
                                _model.findfleetmanagers
                                    ?.map((e) => e.uid)
                                    .withoutNulls
                                    .toList()),
                          );
                          _shouldSetState = true;
                          triggerPushNotification(
                            notificationTitle: 'Service Provider Withdrawn',
                            notificationText:
                                'The selected service provider (${widget!.incident?.chosenProviders}) has withdrawn from the incident and will no longer be serving the request. Reason: ${_model.textController.text}',
                            notificationSound: 'default',
                            userRefs: _model.findfleetmanagersfb!
                                .map((e) => e.reference)
                                .toList(),
                            initialPageName: 'request_details',
                            parameterData: {
                              'requestid': widget!.incident?.id,
                              'role': 'Fleet Manager',
                              'completed': false,
                            },
                          );
                        }),
                        Future(() async {
                          _model.finddriverFb = await queryUsersRecordOnce(
                            queryBuilder: (usersRecord) => usersRecord.where(
                              'uid',
                              isEqualTo: widget!.incident?.requesterUid,
                            ),
                            singleRecord: true,
                          ).then((s) => s.firstOrNull);
                          _shouldSetState = true;
                          triggerPushNotification(
                            notificationTitle: 'Service Provider Withdrawn',
                            notificationText:
                                'The selected service provider (${widget!.incident?.chosenProviders}) has withdrawn from the incident and will no longer be serving the request. Reason: ${_model.textController.text}',
                            notificationSound: 'default',
                            userRefs: [_model.finddriverFb!.reference],
                            initialPageName: 'incidenthistory_driver',
                            parameterData: {},
                          );
                        }),
                        Future(() async {
                          if (widget!.incident?.technician != null &&
                              widget!.incident?.technician != '') {
                            _model.findtechnician =
                                await UsersTable().queryRows(
                              queryFn: (q) => q.eqOrNull(
                                'id',
                                widget!.incident?.technicianUserid,
                              ),
                            );
                            _shouldSetState = true;
                            _model.findtech = await queryUsersRecordOnce(
                              queryBuilder: (usersRecord) => usersRecord.where(
                                'uid',
                                isEqualTo:
                                    _model.findtechnician?.firstOrNull?.uid,
                              ),
                              singleRecord: true,
                            ).then((s) => s.firstOrNull);
                            _shouldSetState = true;
                            triggerPushNotification(
                              notificationTitle: 'Withdrawn from incident.',
                              notificationText:
                                  'Your admin has withdrawn from this incident',
                              notificationSound: 'default',
                              userRefs: [_model.findtech!.reference],
                              initialPageName: 'request_details',
                              parameterData: {
                                'requestid': widget!.incident?.id,
                                'role': 'Technician/Staff',
                                'completed': false,
                              },
                            );
                          }
                        }),
                      ]);
                    } else if (widget!.user?.currentrole == 'Fleet Manager') {
                      _model.checkifcancellationalreadyFm =
                          await CancellationRequestsTable().queryRows(
                        queryFn: (q) => q
                            .eqOrNull(
                              'incident',
                              widget!.incident?.id,
                            )
                            .eqOrNull(
                              'transporter_id',
                              widget!.user?.transporterId,
                            ),
                      );
                      _shouldSetState = true;
                      if (_model.checkifcancellationalreadyFm != null &&
                          (_model.checkifcancellationalreadyFm)!.isNotEmpty) {
                        await CancellationRequestsTable().update(
                          data: {
                            'status': 'Successful',
                          },
                          matchingRows: (rows) => rows.eqOrNull(
                            'id',
                            _model
                                .checkifcancellationalreadyFm?.firstOrNull?.id,
                          ),
                        );
                        _shouldSetState = true;
                        await widget.refresh?.call(
                          _model.updaterequestTransporter!.firstOrNull!,
                        );
                      } else {
                        if (_model.textController.text != null &&
                            _model.textController.text != '') {
                          if (widget!.incident?.chosenprovider != null) {
                            if (widget!.incident?.technician != null &&
                                widget!.incident?.technician != '') {
                              await showDialog(
                                context: context,
                                builder: (alertDialogContext) {
                                  return WebViewAware(
                                    child: AlertDialog(
                                      title: Text(
                                          'The technician is already assigned an en-route'),
                                      content: Text(
                                          'You will be charged a penalty fee for cancelling this request.'),
                                      actions: [
                                        TextButton(
                                          onPressed: () =>
                                              Navigator.pop(alertDialogContext),
                                          child: Text('Ok'),
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              );
                              await Future.wait([
                                Future(() async {
                                  _model.findprovideradmins =
                                      await UsersTable().queryRows(
                                    queryFn: (q) => q
                                        .eqOrNull(
                                          'service_provider',
                                          widget!.incident?.chosenprovider,
                                        )
                                        .eqOrNull(
                                          'currentrole',
                                          'Service Provider',
                                        ),
                                  );
                                  _shouldSetState = true;
                                  _model.findadminsFb =
                                      await queryUsersRecordOnce(
                                    queryBuilder: (usersRecord) =>
                                        usersRecord.whereIn(
                                            'uid',
                                            _model.findprovideradmins
                                                ?.map((e) => e.uid)
                                                .withoutNulls
                                                .toList()),
                                  );
                                  _shouldSetState = true;
                                  triggerPushNotification(
                                    notificationTitle:
                                        'Incident Request Cancelled',
                                    notificationText:
                                        'The transporter has cancelled the incident request. Reason: ${_model.textController.text}',
                                    notificationSound: 'default',
                                    userRefs: _model.findadminsFb!
                                        .map((e) => e.reference)
                                        .toList(),
                                    initialPageName: 'notifications',
                                    parameterData: {},
                                  );
                                }),
                                Future(() async {
                                  _model.findchosentechnician =
                                      await UsersTable().queryRows(
                                    queryFn: (q) => q.eqOrNull(
                                      'id',
                                      widget!.incident?.technicianUserid,
                                    ),
                                  );
                                  _shouldSetState = true;
                                  _model.findtechFb =
                                      await queryUsersRecordOnce(
                                    queryBuilder: (usersRecord) =>
                                        usersRecord.where(
                                      'uid',
                                      isEqualTo: _model.findchosentechnician
                                          ?.firstOrNull?.uid,
                                    ),
                                    singleRecord: true,
                                  ).then((s) => s.firstOrNull);
                                  _shouldSetState = true;
                                  triggerPushNotification(
                                    notificationTitle:
                                        'Incident Request Cancelled',
                                    notificationText:
                                        'The transporter has cancelled the incident request. Reason: ${_model.textController.text}',
                                    notificationSound: 'default',
                                    userRefs: [_model.findtechFb!.reference],
                                    initialPageName: 'notifications',
                                    parameterData: {},
                                  );
                                }),
                              ]);
                            } else {
                              _model.findprovideradmins2 =
                                  await UsersTable().queryRows(
                                queryFn: (q) => q
                                    .eqOrNull(
                                      'service_provider',
                                      widget!.incident?.chosenprovider,
                                    )
                                    .eqOrNull(
                                      'currentrole',
                                      'Service Provider',
                                    ),
                              );
                              _shouldSetState = true;
                              _model.findadminsFb2 = await queryUsersRecordOnce(
                                queryBuilder: (usersRecord) =>
                                    usersRecord.whereIn(
                                        'uid',
                                        _model.findprovideradmins2
                                            ?.map((e) => e.uid)
                                            .withoutNulls
                                            .toList()),
                              );
                              _shouldSetState = true;
                              triggerPushNotification(
                                notificationTitle: 'Incident Request Cancelled',
                                notificationText:
                                    'The transporter has cancelled the incident request. Reason: ${_model.textController.text}',
                                notificationSound: 'default',
                                userRefs: _model.findadminsFb2!
                                    .map((e) => e.reference)
                                    .toList(),
                                initialPageName: 'notifications',
                                parameterData: {},
                              );
                            }
                          }
                          await RequestsTable().update(
                            data: {
                              'cancelled':
                                  supaSerialize<DateTime>(getCurrentTimestamp),
                              'cancellation_reason': _model.textController.text,
                              'status': 'Completed',
                            },
                            matchingRows: (rows) => rows.eqOrNull(
                              'id',
                              widget!.incident?.id,
                            ),
                          );
                          _model.newrequestFleetmanager =
                              await CancellationRequestsTable().insert({
                            'incident': widget!.incident?.id,
                            'initiator_name':
                                '${widget!.user?.firstName} ${widget!.user?.lastName}',
                            'initiator_uid': widget!.user?.uid,
                            'initiator_id': widget!.user?.id,
                            'initiator_role': 'Fleet Manager',
                            'status': 'Successful',
                            'cancellation_reason': _model.textController.text,
                            'transporter_id': widget!.user?.transporterId,
                          });
                          _shouldSetState = true;
                          await widget.refresh?.call(
                            _model.newrequestFleetmanager!,
                          );
                        } else {
                          await showDialog(
                            context: context,
                            builder: (alertDialogContext) {
                              return WebViewAware(
                                child: AlertDialog(
                                  title: Text(
                                      'Please add a reason for cancelling'),
                                  actions: [
                                    TextButton(
                                      onPressed: () =>
                                          Navigator.pop(alertDialogContext),
                                      child: Text('Ok'),
                                    ),
                                  ],
                                ),
                              );
                            },
                          );
                          if (_shouldSetState) safeSetState(() {});
                          return;
                        }
                      }
                    } else if (widget!.user?.currentrole ==
                        'Technician/Staff') {
                      if (_model.textController.text != null &&
                          _model.textController.text != '') {
                        _model.newrequestTechnician =
                            await CancellationRequestsTable().insert({
                          'incident': widget!.incident?.id,
                          'initiator_name':
                              '${widget!.user?.firstName} ${widget!.user?.lastName}',
                          'initiator_uid': widget!.user?.uid,
                          'initiator_id': widget!.user?.id,
                          'initiator_role': 'Technician/Staff',
                          'status': 'Pending',
                          'cancellation_reason': _model.textController.text,
                          'transporter_id': widget!.user?.transporterId,
                        });
                        _shouldSetState = true;
                        _model.findprovideradminsTech =
                            await UsersTable().queryRows(
                          queryFn: (q) => q
                              .eqOrNull(
                                'service_provider',
                                widget!.incident?.chosenprovider,
                              )
                              .eqOrNull(
                                'currentrole',
                                'Service Provider',
                              ),
                        );
                        _shouldSetState = true;
                        _model.findadminsFbtech = await queryUsersRecordOnce(
                          queryBuilder: (usersRecord) => usersRecord.whereIn(
                              'uid',
                              _model.findprovideradminsTech
                                  ?.map((e) => e.uid)
                                  .withoutNulls
                                  .toList()),
                        );
                        _shouldSetState = true;
                        triggerPushNotification(
                          notificationTitle: 'New Cancellation Request',
                          notificationText:
                              'Your technician (${widget!.incident?.technician}) has requested to cancel an incident they were assigned to. Reason: ${_model.textController.text}',
                          notificationSound: 'default',
                          userRefs: _model.findadminsFbtech!
                              .map((e) => e.reference)
                              .toList(),
                          initialPageName: 'request_details',
                          parameterData: {
                            'requestid': widget!.incident?.id,
                            'role': 'Service Provider',
                            'completed': false,
                          },
                        );
                        await widget.refresh?.call(
                          _model.newrequestTechnician!,
                        );
                      } else {
                        await showDialog(
                          context: context,
                          builder: (alertDialogContext) {
                            return WebViewAware(
                              child: AlertDialog(
                                title:
                                    Text('Please add a reason for cancelling'),
                                actions: [
                                  TextButton(
                                    onPressed: () =>
                                        Navigator.pop(alertDialogContext),
                                    child: Text('Ok'),
                                  ),
                                ],
                              ),
                            );
                          },
                        );
                        if (_shouldSetState) safeSetState(() {});
                        return;
                      }
                    } else {
                      if (_shouldSetState) safeSetState(() {});
                      return;
                    }

                    await RequestCommentsTable().insert({
                      'poster_name':
                          '${widget!.user?.firstName} ${widget!.user?.lastName}',
                      'poster_uid': currentUserUid,
                      'incident': widget!.incident?.id,
                      'comment':
                          'User has requested to cancel the request. Reason: ${_model.textController.text}',
                      'created_at':
                          supaSerialize<DateTime>(getCurrentTimestamp),
                      'poster_role': widget!.user?.currentrole,
                    });
                    Navigator.pop(context);
                    if (_shouldSetState) safeSetState(() {});
                  },
                  text: 'Confirm & Cancel',
                  options: FFButtonOptions(
                    width: double.infinity,
                    height: 52.0,
                    padding:
                        EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                    iconPadding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                    color: FlutterFlowTheme.of(context).primary,
                    textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                          font: GoogleFonts.lato(
                            fontWeight: FlutterFlowTheme.of(context)
                                .titleSmall
                                .fontWeight,
                            fontStyle: FlutterFlowTheme.of(context)
                                .titleSmall
                                .fontStyle,
                          ),
                          color: Colors.white,
                          fontSize: 14.0,
                          letterSpacing: 0.0,
                          fontWeight: FlutterFlowTheme.of(context)
                              .titleSmall
                              .fontWeight,
                          fontStyle:
                              FlutterFlowTheme.of(context).titleSmall.fontStyle,
                        ),
                    elevation: 0.0,
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

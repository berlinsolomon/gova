import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'services_widget.dart' show ServicesWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ServicesModel extends FlutterFlowModel<ServicesWidget> {
  ///  Local state fields for this component.

  List<String> selected = [];
  void addToSelected(String item) => selected.add(item);
  void removeFromSelected(String item) => selected.remove(item);
  void removeAtIndexFromSelected(int index) => selected.removeAt(index);
  void insertAtIndexInSelected(int index, String item) =>
      selected.insert(index, item);
  void updateSelectedAtIndex(int index, Function(String) updateFn) =>
      selected[index] = updateFn(selected[index]);

  ///  State fields for stateful widgets in this component.

  // State field(s) for CheckboxListTile widget.
  Map<ServicesRow, bool> checkboxListTileValueMap = {};
  List<ServicesRow> get checkboxListTileCheckedItems =>
      checkboxListTileValueMap.entries
          .where((e) => e.value)
          .map((e) => e.key)
          .toList();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}

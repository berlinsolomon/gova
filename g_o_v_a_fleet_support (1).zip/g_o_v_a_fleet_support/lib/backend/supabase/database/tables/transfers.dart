import '../database.dart';

class TransfersTable extends SupabaseTable<TransfersRow> {
  @override
  String get tableName => 'transfers';

  @override
  TransfersRow createRow(Map<String, dynamic> data) => TransfersRow(data);
}

class TransfersRow extends SupabaseDataRow {
  TransfersRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => TransfersTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  int? get oldTransporter => getField<int>('old_transporter');
  set oldTransporter(int? value) => setField<int>('old_transporter', value);

  int? get newTransporter => getField<int>('new_transporter');
  set newTransporter(int? value) => setField<int>('new_transporter', value);

  String? get status => getField<String>('status');
  set status(String? value) => setField<String>('status', value);

  int? get oldProvider => getField<int>('old_provider');
  set oldProvider(int? value) => setField<int>('old_provider', value);

  int? get newProvider => getField<int>('new_provider');
  set newProvider(int? value) => setField<int>('new_provider', value);

  String? get uid => getField<String>('uid');
  set uid(String? value) => setField<String>('uid', value);

  int? get userId => getField<int>('user_id');
  set userId(int? value) => setField<int>('user_id', value);

  String? get name => getField<String>('name');
  set name(String? value) => setField<String>('name', value);
}

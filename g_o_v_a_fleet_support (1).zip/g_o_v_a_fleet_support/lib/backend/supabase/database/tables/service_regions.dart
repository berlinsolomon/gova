import '../database.dart';

class ServiceRegionsTable extends SupabaseTable<ServiceRegionsRow> {
  @override
  String get tableName => 'service_regions';

  @override
  ServiceRegionsRow createRow(Map<String, dynamic> data) =>
      ServiceRegionsRow(data);
}

class ServiceRegionsRow extends SupabaseDataRow {
  ServiceRegionsRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => ServiceRegionsTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get region => getField<String>('region');
  set region(String? value) => setField<String>('region', value);

  String? get coordinates => getField<String>('coordinates');
  set coordinates(String? value) => setField<String>('coordinates', value);

  int? get radius => getField<int>('radius');
  set radius(int? value) => setField<int>('radius', value);
}

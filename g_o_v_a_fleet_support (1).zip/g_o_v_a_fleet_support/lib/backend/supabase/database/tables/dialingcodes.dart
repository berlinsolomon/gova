import '../database.dart';

class DialingcodesTable extends SupabaseTable<DialingcodesRow> {
  @override
  String get tableName => 'dialingcodes';

  @override
  DialingcodesRow createRow(Map<String, dynamic> data) => DialingcodesRow(data);
}

class DialingcodesRow extends SupabaseDataRow {
  DialingcodesRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => DialingcodesTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get country => getField<String>('country');
  set country(String? value) => setField<String>('country', value);

  String? get code => getField<String>('code');
  set code(String? value) => setField<String>('code', value);
}

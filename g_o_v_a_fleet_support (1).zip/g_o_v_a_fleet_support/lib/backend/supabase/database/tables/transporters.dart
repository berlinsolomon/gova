import '../database.dart';

class TransportersTable extends SupabaseTable<TransportersRow> {
  @override
  String get tableName => 'transporters';

  @override
  TransportersRow createRow(Map<String, dynamic> data) => TransportersRow(data);
}

class TransportersRow extends SupabaseDataRow {
  TransportersRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => TransportersTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get name => getField<String>('name');
  set name(String? value) => setField<String>('name', value);

  String? get companyReg => getField<String>('company_reg');
  set companyReg(String? value) => setField<String>('company_reg', value);

  List<String> get regDocument => getListField<String>('reg_document');
  set regDocument(List<String>? value) =>
      setListField<String>('reg_document', value);

  String? get vatNumber => getField<String>('vat_number');
  set vatNumber(String? value) => setField<String>('vat_number', value);

  String? get insProof => getField<String>('ins_proof');
  set insProof(String? value) => setField<String>('ins_proof', value);

  int? get fleetSize => getField<int>('fleet_size');
  set fleetSize(int? value) => setField<int>('fleet_size', value);

  String? get address => getField<String>('address');
  set address(String? value) => setField<String>('address', value);

  String? get coordinates => getField<String>('coordinates');
  set coordinates(String? value) => setField<String>('coordinates', value);

  String? get website => getField<String>('website');
  set website(String? value) => setField<String>('website', value);

  String? get createdby => getField<String>('createdby');
  set createdby(String? value) => setField<String>('createdby', value);

  String? get email => getField<String>('email');
  set email(String? value) => setField<String>('email', value);

  String? get phone => getField<String>('phone');
  set phone(String? value) => setField<String>('phone', value);

  String? get govaCode => getField<String>('gova_code');
  set govaCode(String? value) => setField<String>('gova_code', value);

  String? get logo => getField<String>('logo');
  set logo(String? value) => setField<String>('logo', value);

  List<int> get favoriteProviders => getListField<int>('favorite_providers');
  set favoriteProviders(List<int>? value) =>
      setListField<int>('favorite_providers', value);

  String? get cardAuth => getField<String>('card_auth');
  set cardAuth(String? value) => setField<String>('card_auth', value);

  bool? get savecard => getField<bool>('savecard');
  set savecard(bool? value) => setField<bool>('savecard', value);

  List<String> get vatReg => getListField<String>('vat_reg');
  set vatReg(List<String>? value) => setListField<String>('vat_reg', value);
}

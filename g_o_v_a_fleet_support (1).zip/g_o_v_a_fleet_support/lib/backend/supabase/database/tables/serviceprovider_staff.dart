import '../database.dart';

class ServiceproviderStaffTable extends SupabaseTable<ServiceproviderStaffRow> {
  @override
  String get tableName => 'serviceprovider_staff';

  @override
  ServiceproviderStaffRow createRow(Map<String, dynamic> data) =>
      ServiceproviderStaffRow(data);
}

class ServiceproviderStaffRow extends SupabaseDataRow {
  ServiceproviderStaffRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => ServiceproviderStaffTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get firstName => getField<String>('first_name');
  set firstName(String? value) => setField<String>('first_name', value);

  String? get lastName => getField<String>('last_name');
  set lastName(String? value) => setField<String>('last_name', value);

  int? get serviceProvider => getField<int>('service_provider');
  set serviceProvider(int? value) => setField<int>('service_provider', value);

  String? get staffCode => getField<String>('staff_code');
  set staffCode(String? value) => setField<String>('staff_code', value);

  String? get phone => getField<String>('phone');
  set phone(String? value) => setField<String>('phone', value);

  String? get image => getField<String>('image');
  set image(String? value) => setField<String>('image', value);

  String? get nationalId => getField<String>('national_id');
  set nationalId(String? value) => setField<String>('national_id', value);

  String? get status => getField<String>('status');
  set status(String? value) => setField<String>('status', value);
}

import '../database.dart';

class FleetTable extends SupabaseTable<FleetRow> {
  @override
  String get tableName => 'fleet';

  @override
  FleetRow createRow(Map<String, dynamic> data) => FleetRow(data);
}

class FleetRow extends SupabaseDataRow {
  FleetRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => FleetTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  int? get company => getField<int>('company');
  set company(int? value) => setField<int>('company', value);

  String? get make => getField<String>('make');
  set make(String? value) => setField<String>('make', value);

  String? get model => getField<String>('model');
  set model(String? value) => setField<String>('model', value);

  String? get year => getField<String>('year');
  set year(String? value) => setField<String>('year', value);

  String? get numberPlate => getField<String>('number_plate');
  set numberPlate(String? value) => setField<String>('number_plate', value);

  String? get vinNumber => getField<String>('vin_number');
  set vinNumber(String? value) => setField<String>('vin_number', value);

  String? get status => getField<String>('status');
  set status(String? value) => setField<String>('status', value);

  int? get currentDriver => getField<int>('current_driver');
  set currentDriver(int? value) => setField<int>('current_driver', value);

  List<String> get image => getListField<String>('image');
  set image(List<String>? value) => setListField<String>('image', value);

  String? get suspension => getField<String>('suspension');
  set suspension(String? value) => setField<String>('suspension', value);
}

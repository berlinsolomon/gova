import '../database.dart';

class ProviderSwapTable extends SupabaseTable<ProviderSwapRow> {
  @override
  String get tableName => 'provider_swap';

  @override
  ProviderSwapRow createRow(Map<String, dynamic> data) => ProviderSwapRow(data);
}

class ProviderSwapRow extends SupabaseDataRow {
  ProviderSwapRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => ProviderSwapTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);
}

import '../database.dart';

class CalloutTable extends SupabaseTable<CalloutRow> {
  @override
  String get tableName => 'callout';

  @override
  CalloutRow createRow(Map<String, dynamic> data) => CalloutRow(data);
}

class CalloutRow extends SupabaseDataRow {
  CalloutRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => CalloutTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  int? get incidentId => getField<int>('incident_id');
  set incidentId(int? value) => setField<int>('incident_id', value);

  int? get serviceProvider => getField<int>('service_provider');
  set serviceProvider(int? value) => setField<int>('service_provider', value);

  int? get technicianUserid => getField<int>('technician_userid');
  set technicianUserid(int? value) => setField<int>('technician_userid', value);

  int? get transporter => getField<int>('transporter');
  set transporter(int? value) => setField<int>('transporter', value);

  int? get driverUserid => getField<int>('driver_userid');
  set driverUserid(int? value) => setField<int>('driver_userid', value);
}

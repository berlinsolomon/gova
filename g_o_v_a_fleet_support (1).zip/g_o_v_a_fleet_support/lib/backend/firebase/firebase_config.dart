import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyDi2_cQMVs6l0sXQ_hESVWjk8VoIXiQt_Q",
            authDomain: "g-o-v-a-fleet-solutions-r4r8o1.firebaseapp.com",
            projectId: "g-o-v-a-fleet-solutions-r4r8o1",
            storageBucket: "g-o-v-a-fleet-solutions-r4r8o1.firebasestorage.app",
            messagingSenderId: "796806356634",
            appId: "1:796806356634:web:5b9a47af295cb376a90923"));
  } else {
    await Firebase.initializeApp();
  }
}

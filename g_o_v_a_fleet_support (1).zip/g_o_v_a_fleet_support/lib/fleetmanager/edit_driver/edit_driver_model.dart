import '/backend/supabase/supabase.dart';
import '/components/emptylicense/emptylicense_widget.dart';
import '/flutter_flow/flutter_flow_expanded_image_view.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import 'edit_driver_widget.dart' show EditDriverWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_blurhash/flutter_blurhash.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:octo_image/octo_image.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';

class EditDriverModel extends FlutterFlowModel<EditDriverWidget> {
  ///  Local state fields for this component.

  List<String> license = [];
  void addToLicense(String item) => license.add(item);
  void removeFromLicense(String item) => license.remove(item);
  void removeAtIndexFromLicense(int index) => license.removeAt(index);
  void insertAtIndexInLicense(int index, String item) =>
      license.insert(index, item);
  void updateLicenseAtIndex(int index, Function(String) updateFn) =>
      license[index] = updateFn(license[index]);

  String? profile;

  ///  State fields for stateful widgets in this component.

  bool isDataUploading_uploadData9qr = false;
  FFUploadedFile uploadedLocalFile_uploadData9qr =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  String uploadedFileUrl_uploadData9qr = '';

  // State field(s) for firstname widget.
  FocusNode? firstnameFocusNode;
  TextEditingController? firstnameTextController;
  String? Function(BuildContext, String?)? firstnameTextControllerValidator;
  // State field(s) for lastname widget.
  FocusNode? lastnameFocusNode;
  TextEditingController? lastnameTextController;
  String? Function(BuildContext, String?)? lastnameTextControllerValidator;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController3;
  String? Function(BuildContext, String?)? textController3Validator;
  // State field(s) for phone widget.
  FocusNode? phoneFocusNode;
  TextEditingController? phoneTextController;
  late MaskTextInputFormatter phoneMask;
  String? Function(BuildContext, String?)? phoneTextControllerValidator;
  // State field(s) for email widget.
  FocusNode? emailFocusNode;
  TextEditingController? emailTextController;
  String? Function(BuildContext, String?)? emailTextControllerValidator;
  bool isDataUploading_uploadlicenseMore = false;
  FFUploadedFile uploadedLocalFile_uploadlicenseMore =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  String uploadedFileUrl_uploadlicenseMore = '';

  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<TransportersRow>? findcompany;
  // Stores action output result for [Backend Call - Update Row(s)] action in Button widget.
  List<TransporterStaffRow>? updatedriver;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    firstnameFocusNode?.dispose();
    firstnameTextController?.dispose();

    lastnameFocusNode?.dispose();
    lastnameTextController?.dispose();

    textFieldFocusNode?.dispose();
    textController3?.dispose();

    phoneFocusNode?.dispose();
    phoneTextController?.dispose();

    emailFocusNode?.dispose();
    emailTextController?.dispose();
  }
}

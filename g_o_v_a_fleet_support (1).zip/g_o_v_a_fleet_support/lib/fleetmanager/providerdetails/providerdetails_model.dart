import '/backend/supabase/supabase.dart';
import '/components/emptyreviews/emptyreviews_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import 'providerdetails_widget.dart' show ProviderdetailsWidget;
import 'package:flutter/material.dart';
import 'package:flutter_blurhash/flutter_blurhash.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:octo_image/octo_image.dart';
import 'package:provider/provider.dart';

class ProviderdetailsModel extends FlutterFlowModel<ProviderdetailsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}

import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/flutter_flow/custom_functions.dart' as functions;
import '/flutter_flow/permissions_util.dart';
import '/flutter_flow/random_data_util.dart' as random_data;
import 'add_driver_widget.dart' show AddDriverWidget;
import 'package:flutter/material.dart';
import 'package:flutter_blurhash/flutter_blurhash.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:octo_image/octo_image.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';

class AddDriverModel extends FlutterFlowModel<AddDriverWidget> {
  ///  Local state fields for this component.

  List<String> license = [];
  void addToLicense(String item) => license.add(item);
  void removeFromLicense(String item) => license.remove(item);
  void removeAtIndexFromLicense(int index) => license.removeAt(index);
  void insertAtIndexInLicense(int index, String item) =>
      license.insert(index, item);
  void updateLicenseAtIndex(int index, Function(String) updateFn) =>
      license[index] = updateFn(license[index]);

  String? profile;

  String addtype = 'Manual';

  List<ContactStruct> contacts = [];
  void addToContacts(ContactStruct item) => contacts.add(item);
  void removeFromContacts(ContactStruct item) => contacts.remove(item);
  void removeAtIndexFromContacts(int index) => contacts.removeAt(index);
  void insertAtIndexInContacts(int index, ContactStruct item) =>
      contacts.insert(index, item);
  void updateContactsAtIndex(int index, Function(ContactStruct) updateFn) =>
      contacts[index] = updateFn(contacts[index]);

  int? driversadded = 0;

  List<ContactStruct> searchresults = [];
  void addToSearchresults(ContactStruct item) => searchresults.add(item);
  void removeFromSearchresults(ContactStruct item) =>
      searchresults.remove(item);
  void removeAtIndexFromSearchresults(int index) =>
      searchresults.removeAt(index);
  void insertAtIndexInSearchresults(int index, ContactStruct item) =>
      searchresults.insert(index, item);
  void updateSearchresultsAtIndex(
          int index, Function(ContactStruct) updateFn) =>
      searchresults[index] = updateFn(searchresults[index]);

  ///  State fields for stateful widgets in this component.

  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController1;
  String? Function(BuildContext, String?)? textController1Validator;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<TransportersRow>? findcompany1;
  // Stores action output result for [Backend Call - Insert Row] action in Button widget.
  TransporterStaffRow? newdriverContactlist1;
  // Stores action output result for [Backend Call - Insert Row] action in Button widget.
  TransporterStaffRow? newdriver1;
  // State field(s) for CheckboxListTile widget.
  Map<ContactStruct, bool> checkboxListTileValueMap1 = {};
  List<ContactStruct> get checkboxListTileCheckedItems1 =>
      checkboxListTileValueMap1.entries
          .where((e) => e.value)
          .map((e) => e.key)
          .toList();

  // State field(s) for CheckboxListTile widget.
  Map<ContactStruct, bool> checkboxListTileValueMap2 = {};
  List<ContactStruct> get checkboxListTileCheckedItems2 =>
      checkboxListTileValueMap2.entries
          .where((e) => e.value)
          .map((e) => e.key)
          .toList();

  bool isDataUploading_changedriverpic = false;
  FFUploadedFile uploadedLocalFile_changedriverpic =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  String uploadedFileUrl_changedriverpic = '';

  // State field(s) for firstname widget.
  FocusNode? firstnameFocusNode;
  TextEditingController? firstnameTextController;
  String? Function(BuildContext, String?)? firstnameTextControllerValidator;
  // State field(s) for lastname widget.
  FocusNode? lastnameFocusNode;
  TextEditingController? lastnameTextController;
  String? Function(BuildContext, String?)? lastnameTextControllerValidator;
  // State field(s) for phone widget.
  FocusNode? phoneFocusNode;
  TextEditingController? phoneTextController;
  late MaskTextInputFormatter phoneMask;
  String? Function(BuildContext, String?)? phoneTextControllerValidator;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<TransportersRow>? findcompany;
  // Stores action output result for [Backend Call - Insert Row] action in Button widget.
  TransporterStaffRow? newdriverContactlist;
  // Stores action output result for [Backend Call - Insert Row] action in Button widget.
  TransporterStaffRow? newdriver;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    textFieldFocusNode?.dispose();
    textController1?.dispose();

    firstnameFocusNode?.dispose();
    firstnameTextController?.dispose();

    lastnameFocusNode?.dispose();
    lastnameTextController?.dispose();

    phoneFocusNode?.dispose();
    phoneTextController?.dispose();
  }
}

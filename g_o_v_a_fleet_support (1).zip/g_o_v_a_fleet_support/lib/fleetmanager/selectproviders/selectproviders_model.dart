import '/backend/supabase/supabase.dart';
import '/components/emptyserviceproviders/emptyserviceproviders_widget.dart';
import '/fleetmanager/providerdetails/providerdetails_widget.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_choice_chips.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:math';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import 'dart:async';
import 'selectproviders_widget.dart' show SelectprovidersWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_blurhash/flutter_blurhash.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:octo_image/octo_image.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';

class SelectprovidersModel extends FlutterFlowModel<SelectprovidersWidget> {
  ///  Local state fields for this component.

  List<ServiceprovidersRow> search = [];
  void addToSearch(ServiceprovidersRow item) => search.add(item);
  void removeFromSearch(ServiceprovidersRow item) => search.remove(item);
  void removeAtIndexFromSearch(int index) => search.removeAt(index);
  void insertAtIndexInSearch(int index, ServiceprovidersRow item) =>
      search.insert(index, item);
  void updateSearchAtIndex(int index, Function(ServiceprovidersRow) updateFn) =>
      search[index] = updateFn(search[index]);

  List<int> selectedids = [];
  void addToSelectedids(int item) => selectedids.add(item);
  void removeFromSelectedids(int item) => selectedids.remove(item);
  void removeAtIndexFromSelectedids(int index) => selectedids.removeAt(index);
  void insertAtIndexInSelectedids(int index, int item) =>
      selectedids.insert(index, item);
  void updateSelectedidsAtIndex(int index, Function(int) updateFn) =>
      selectedids[index] = updateFn(selectedids[index]);

  ///  State fields for stateful widgets in this component.

  // State field(s) for ChoiceChips widget.
  FormFieldController<List<String>>? choiceChipsValueController;
  String? get choiceChipsValue =>
      choiceChipsValueController?.value?.firstOrNull;
  set choiceChipsValue(String? val) =>
      choiceChipsValueController?.value = val != null ? [val] : [];
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? Function(BuildContext, String?)? textControllerValidator;
  // Stores action output result for [Backend Call - Query Rows] action in IconButton widget.
  List<ServiceprovidersRow>? findproviders;
  Completer<List<ServiceprovidersRow>>? requestCompleter3;
  // State field(s) for Checkbox widget.
  Map<ServiceprovidersRow, bool> checkboxValueMap1 = {};
  List<ServiceprovidersRow> get checkboxCheckedItems1 =>
      checkboxValueMap1.entries
          .where((e) => e.value)
          .map((e) => e.key)
          .toList();

  Completer<List<ServiceprovidersRow>>? requestCompleter2;
  // State field(s) for Checkbox widget.
  Map<ServiceprovidersRow, bool> checkboxValueMap2 = {};
  List<ServiceprovidersRow> get checkboxCheckedItems2 =>
      checkboxValueMap2.entries
          .where((e) => e.value)
          .map((e) => e.key)
          .toList();

  Completer<List<ServiceprovidersRow>>? requestCompleter1;
  // State field(s) for Checkbox widget.
  Map<ServiceprovidersRow, bool> checkboxValueMap3 = {};
  List<ServiceprovidersRow> get checkboxCheckedItems3 =>
      checkboxValueMap3.entries
          .where((e) => e.value)
          .map((e) => e.key)
          .toList();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    textFieldFocusNode?.dispose();
    textController?.dispose();
  }

  /// Additional helper methods.
  Future waitForRequestCompleted3({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter3?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }

  Future waitForRequestCompleted2({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter2?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }

  Future waitForRequestCompleted1({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter1?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }
}

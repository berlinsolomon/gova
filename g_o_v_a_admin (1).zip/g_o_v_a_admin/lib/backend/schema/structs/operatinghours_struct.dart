// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class OperatinghoursStruct extends FFFirebaseStruct {
  OperatinghoursStruct({
    String? day,
    String? timerange,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _day = day,
        _timerange = timerange,
        super(firestoreUtilData);

  // "day" field.
  String? _day;
  String get day => _day ?? '';
  set day(String? val) => _day = val;

  bool hasDay() => _day != null;

  // "timerange" field.
  String? _timerange;
  String get timerange => _timerange ?? '';
  set timerange(String? val) => _timerange = val;

  bool hasTimerange() => _timerange != null;

  static OperatinghoursStruct fromMap(Map<String, dynamic> data) =>
      OperatinghoursStruct(
        day: data['day'] as String?,
        timerange: data['timerange'] as String?,
      );

  static OperatinghoursStruct? maybeFromMap(dynamic data) => data is Map
      ? OperatinghoursStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'day': _day,
        'timerange': _timerange,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'day': serializeParam(
          _day,
          ParamType.String,
        ),
        'timerange': serializeParam(
          _timerange,
          ParamType.String,
        ),
      }.withoutNulls;

  static OperatinghoursStruct fromSerializableMap(Map<String, dynamic> data) =>
      OperatinghoursStruct(
        day: deserializeParam(
          data['day'],
          ParamType.String,
          false,
        ),
        timerange: deserializeParam(
          data['timerange'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'OperatinghoursStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is OperatinghoursStruct &&
        day == other.day &&
        timerange == other.timerange;
  }

  @override
  int get hashCode => const ListEquality().hash([day, timerange]);
}

OperatinghoursStruct createOperatinghoursStruct({
  String? day,
  String? timerange,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    OperatinghoursStruct(
      day: day,
      timerange: timerange,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

OperatinghoursStruct? updateOperatinghoursStruct(
  OperatinghoursStruct? operatinghours, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    operatinghours
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addOperatinghoursStructData(
  Map<String, dynamic> firestoreData,
  OperatinghoursStruct? operatinghours,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (operatinghours == null) {
    return;
  }
  if (operatinghours.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && operatinghours.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final operatinghoursData =
      getOperatinghoursFirestoreData(operatinghours, forFieldValue);
  final nestedData =
      operatinghoursData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = operatinghours.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getOperatinghoursFirestoreData(
  OperatinghoursStruct? operatinghours, [
  bool forFieldValue = false,
]) {
  if (operatinghours == null) {
    return {};
  }
  final firestoreData = mapToFirestore(operatinghours.toMap());

  // Add any Firestore field values
  operatinghours.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getOperatinghoursListFirestoreData(
  List<OperatinghoursStruct>? operatinghourss,
) =>
    operatinghourss
        ?.map((e) => getOperatinghoursFirestoreData(e, true))
        .toList() ??
    [];

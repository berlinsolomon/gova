// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class EmergencycontactsStruct extends FFFirebaseStruct {
  EmergencycontactsStruct({
    String? name,
    String? number,
    String? email,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _name = name,
        _number = number,
        _email = email,
        super(firestoreUtilData);

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  set name(String? val) => _name = val;

  bool hasName() => _name != null;

  // "number" field.
  String? _number;
  String get number => _number ?? '';
  set number(String? val) => _number = val;

  bool hasNumber() => _number != null;

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  set email(String? val) => _email = val;

  bool hasEmail() => _email != null;

  static EmergencycontactsStruct fromMap(Map<String, dynamic> data) =>
      EmergencycontactsStruct(
        name: data['name'] as String?,
        number: data['number'] as String?,
        email: data['email'] as String?,
      );

  static EmergencycontactsStruct? maybeFromMap(dynamic data) => data is Map
      ? EmergencycontactsStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'name': _name,
        'number': _number,
        'email': _email,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'name': serializeParam(
          _name,
          ParamType.String,
        ),
        'number': serializeParam(
          _number,
          ParamType.String,
        ),
        'email': serializeParam(
          _email,
          ParamType.String,
        ),
      }.withoutNulls;

  static EmergencycontactsStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      EmergencycontactsStruct(
        name: deserializeParam(
          data['name'],
          ParamType.String,
          false,
        ),
        number: deserializeParam(
          data['number'],
          ParamType.String,
          false,
        ),
        email: deserializeParam(
          data['email'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'EmergencycontactsStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is EmergencycontactsStruct &&
        name == other.name &&
        number == other.number &&
        email == other.email;
  }

  @override
  int get hashCode => const ListEquality().hash([name, number, email]);
}

EmergencycontactsStruct createEmergencycontactsStruct({
  String? name,
  String? number,
  String? email,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    EmergencycontactsStruct(
      name: name,
      number: number,
      email: email,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

EmergencycontactsStruct? updateEmergencycontactsStruct(
  EmergencycontactsStruct? emergencycontacts, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    emergencycontacts
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addEmergencycontactsStructData(
  Map<String, dynamic> firestoreData,
  EmergencycontactsStruct? emergencycontacts,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (emergencycontacts == null) {
    return;
  }
  if (emergencycontacts.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && emergencycontacts.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final emergencycontactsData =
      getEmergencycontactsFirestoreData(emergencycontacts, forFieldValue);
  final nestedData =
      emergencycontactsData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = emergencycontacts.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getEmergencycontactsFirestoreData(
  EmergencycontactsStruct? emergencycontacts, [
  bool forFieldValue = false,
]) {
  if (emergencycontacts == null) {
    return {};
  }
  final firestoreData = mapToFirestore(emergencycontacts.toMap());

  // Add any Firestore field values
  emergencycontacts.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getEmergencycontactsListFirestoreData(
  List<EmergencycontactsStruct>? emergencycontactss,
) =>
    emergencycontactss
        ?.map((e) => getEmergencycontactsFirestoreData(e, true))
        .toList() ??
    [];

import '../database.dart';

class ReviewsServiceprovidersTable
    extends SupabaseTable<ReviewsServiceprovidersRow> {
  @override
  String get tableName => 'reviews_serviceproviders';

  @override
  ReviewsServiceprovidersRow createRow(Map<String, dynamic> data) =>
      ReviewsServiceprovidersRow(data);
}

class ReviewsServiceprovidersRow extends SupabaseDataRow {
  ReviewsServiceprovidersRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => ReviewsServiceprovidersTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  int? get job => getField<int>('job');
  set job(int? value) => setField<int>('job', value);

  int? get rating => getField<int>('rating');
  set rating(int? value) => setField<int>('rating', value);

  String? get review => getField<String>('review');
  set review(String? value) => setField<String>('review', value);

  String? get userUid => getField<String>('user_uid');
  set userUid(String? value) => setField<String>('user_uid', value);

  String? get userName => getField<String>('user_name');
  set userName(String? value) => setField<String>('user_name', value);

  int? get fleetcompanyId => getField<int>('fleetcompany_id');
  set fleetcompanyId(int? value) => setField<int>('fleetcompany_id', value);

  String? get fleetcompanyName => getField<String>('fleetcompany_name');
  set fleetcompanyName(String? value) =>
      setField<String>('fleetcompany_name', value);

  String? get reply => getField<String>('reply');
  set reply(String? value) => setField<String>('reply', value);

  String? get replierUid => getField<String>('replier_uid');
  set replierUid(String? value) => setField<String>('replier_uid', value);

  String? get replierName => getField<String>('replier_name');
  set replierName(String? value) => setField<String>('replier_name', value);

  int? get serviceProvider => getField<int>('service_provider');
  set serviceProvider(int? value) => setField<int>('service_provider', value);

  String? get reviewerRole => getField<String>('reviewer_role');
  set reviewerRole(String? value) => setField<String>('reviewer_role', value);

  String? get jobdetails => getField<String>('jobdetails');
  set jobdetails(String? value) => setField<String>('jobdetails', value);
}

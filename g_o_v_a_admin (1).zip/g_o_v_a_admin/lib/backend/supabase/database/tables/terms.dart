import '../database.dart';

class TermsTable extends SupabaseTable<TermsRow> {
  @override
  String get tableName => 'terms';

  @override
  TermsRow createRow(Map<String, dynamic> data) => TermsRow(data);
}

class TermsRow extends SupabaseDataRow {
  TermsRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => TermsTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get role => getField<String>('role');
  set role(String? value) => setField<String>('role', value);

  String? get terms => getField<String>('terms');
  set terms(String? value) => setField<String>('terms', value);
}

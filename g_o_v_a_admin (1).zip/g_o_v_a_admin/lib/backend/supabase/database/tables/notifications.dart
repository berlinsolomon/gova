import '../database.dart';

class NotificationsTable extends SupabaseTable<NotificationsRow> {
  @override
  String get tableName => 'notifications';

  @override
  NotificationsRow createRow(Map<String, dynamic> data) =>
      NotificationsRow(data);
}

class NotificationsRow extends SupabaseDataRow {
  NotificationsRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => NotificationsTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get title => getField<String>('title');
  set title(String? value) => setField<String>('title', value);

  String? get message => getField<String>('message');
  set message(String? value) => setField<String>('message', value);

  String? get sentBy => getField<String>('sent_by');
  set sentBy(String? value) => setField<String>('sent_by', value);

  List<String> get sentTo => getListField<String>('sent_to');
  set sentTo(List<String>? value) => setListField<String>('sent_to', value);

  List<String> get readBy => getListField<String>('read_by');
  set readBy(List<String>? value) => setListField<String>('read_by', value);

  String? get category => getField<String>('category');
  set category(String? value) => setField<String>('category', value);

  String? get file => getField<String>('file');
  set file(String? value) => setField<String>('file', value);
}

import '../database.dart';

class UsersTable extends SupabaseTable<UsersRow> {
  @override
  String get tableName => 'users';

  @override
  UsersRow createRow(Map<String, dynamic> data) => UsersRow(data);
}

class UsersRow extends SupabaseDataRow {
  UsersRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => UsersTable();

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get firstName => getField<String>('first_name');
  set firstName(String? value) => setField<String>('first_name', value);

  String? get lastName => getField<String>('last_name');
  set lastName(String? value) => setField<String>('last_name', value);

  String? get uid => getField<String>('uid');
  set uid(String? value) => setField<String>('uid', value);

  String? get currentrole => getField<String>('currentrole');
  set currentrole(String? value) => setField<String>('currentrole', value);

  String? get email => getField<String>('email');
  set email(String? value) => setField<String>('email', value);

  String? get workemail => getField<String>('workemail');
  set workemail(String? value) => setField<String>('workemail', value);

  String? get profilepic => getField<String>('profilepic');
  set profilepic(String? value) => setField<String>('profilepic', value);

  bool? get verified => getField<bool>('verified');
  set verified(bool? value) => setField<bool>('verified', value);

  String? get usercode => getField<String>('usercode');
  set usercode(String? value) => setField<String>('usercode', value);

  String? get phone => getField<String>('phone');
  set phone(String? value) => setField<String>('phone', value);

  List<String> get languages => getListField<String>('languages');
  set languages(List<String>? value) =>
      setListField<String>('languages', value);

  List<String> get license => getListField<String>('license');
  set license(List<String>? value) => setListField<String>('license', value);

  String? get transporterName => getField<String>('transporter_name');
  set transporterName(String? value) =>
      setField<String>('transporter_name', value);

  int? get transporterId => getField<int>('transporter_id');
  set transporterId(int? value) => setField<int>('transporter_id', value);

  int? get serviceProvider => getField<int>('service_provider');
  set serviceProvider(int? value) => setField<int>('service_provider', value);

  List<String> get permissions => getListField<String>('permissions');
  set permissions(List<String>? value) =>
      setListField<String>('permissions', value);

  int? get servproviderStaffid => getField<int>('servprovider_staffid');
  set servproviderStaffid(int? value) =>
      setField<int>('servprovider_staffid', value);

  bool? get activated => getField<bool>('activated');
  set activated(bool? value) => setField<bool>('activated', value);

  String? get nationalIdnumber => getField<String>('national_idnumber');
  set nationalIdnumber(String? value) =>
      setField<String>('national_idnumber', value);

  int? get transporterStaffid => getField<int>('transporter_staffid');
  set transporterStaffid(int? value) =>
      setField<int>('transporter_staffid', value);

  String? get phonetwo => getField<String>('phonetwo');
  set phonetwo(String? value) => setField<String>('phonetwo', value);

  String? get serviceproviderStaffcode =>
      getField<String>('serviceprovider_staffcode');
  set serviceproviderStaffcode(String? value) =>
      setField<String>('serviceprovider_staffcode', value);

  bool? get transferPending => getField<bool>('transfer_pending');
  set transferPending(bool? value) => setField<bool>('transfer_pending', value);

  bool? get onemanband => getField<bool>('onemanband');
  set onemanband(bool? value) => setField<bool>('onemanband', value);

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);
}

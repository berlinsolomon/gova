import '../database.dart';

class RequestsSecondaryTable extends SupabaseTable<RequestsSecondaryRow> {
  @override
  String get tableName => 'requests_secondary';

  @override
  RequestsSecondaryRow createRow(Map<String, dynamic> data) =>
      RequestsSecondaryRow(data);
}

class RequestsSecondaryRow extends SupabaseDataRow {
  RequestsSecondaryRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => RequestsSecondaryTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get requesterName => getField<String>('requester_name');
  set requesterName(String? value) => setField<String>('requester_name', value);

  int? get requesterId => getField<int>('requester_id');
  set requesterId(int? value) => setField<int>('requester_id', value);

  int? get driverId => getField<int>('driver_id');
  set driverId(int? value) => setField<int>('driver_id', value);

  String? get requesterLocation => getField<String>('requester_location');
  set requesterLocation(String? value) =>
      setField<String>('requester_location', value);

  String? get serviceRequested => getField<String>('service_requested');
  set serviceRequested(String? value) =>
      setField<String>('service_requested', value);

  String? get status => getField<String>('status');
  set status(String? value) => setField<String>('status', value);

  String? get fleetcompanyName => getField<String>('fleetcompany_name');
  set fleetcompanyName(String? value) =>
      setField<String>('fleetcompany_name', value);

  int? get fleetcompanyId => getField<int>('fleetcompany_id');
  set fleetcompanyId(int? value) => setField<int>('fleetcompany_id', value);

  String? get chosenProviders => getField<String>('chosen_providers');
  set chosenProviders(String? value) =>
      setField<String>('chosen_providers', value);

  DateTime? get matchTime => getField<DateTime>('match_time');
  set matchTime(DateTime? value) => setField<DateTime>('match_time', value);

  DateTime? get arrivalTime => getField<DateTime>('arrival_time');
  set arrivalTime(DateTime? value) => setField<DateTime>('arrival_time', value);

  double? get costnofeeInclvat => getField<double>('costnofee_inclvat');
  set costnofeeInclvat(double? value) =>
      setField<double>('costnofee_inclvat', value);

  double? get govaFees => getField<double>('gova_fees');
  set govaFees(double? value) => setField<double>('gova_fees', value);

  String? get technician => getField<String>('technician');
  set technician(String? value) => setField<String>('technician', value);

  String? get requestDetails => getField<String>('request_details');
  set requestDetails(String? value) =>
      setField<String>('request_details', value);

  List<String> get images => getListField<String>('images');
  set images(List<String>? value) => setListField<String>('images', value);

  String? get requesterUid => getField<String>('requester_uid');
  set requesterUid(String? value) => setField<String>('requester_uid', value);

  String? get code => getField<String>('code');
  set code(String? value) => setField<String>('code', value);

  DateTime? get cancelled => getField<DateTime>('cancelled');
  set cancelled(DateTime? value) => setField<DateTime>('cancelled', value);

  String? get cancellationReason => getField<String>('cancellation_reason');
  set cancellationReason(String? value) =>
      setField<String>('cancellation_reason', value);

  String? get requesterPhone => getField<String>('requester_phone');
  set requesterPhone(String? value) =>
      setField<String>('requester_phone', value);

  bool? get imagesrequested => getField<bool>('imagesrequested');
  set imagesrequested(bool? value) => setField<bool>('imagesrequested', value);

  List<int> get providersTendered => getListField<int>('providers_tendered');
  set providersTendered(List<int>? value) =>
      setListField<int>('providers_tendered', value);

  List<int> get ignoredBy => getListField<int>('ignored_by');
  set ignoredBy(List<int>? value) => setListField<int>('ignored_by', value);

  int? get vehicle => getField<int>('vehicle');
  set vehicle(int? value) => setField<int>('vehicle', value);

  String? get technicialVehicle => getField<String>('technicial_vehicle');
  set technicialVehicle(String? value) =>
      setField<String>('technicial_vehicle', value);

  String? get technicianNumberplate =>
      getField<String>('technician_numberplate');
  set technicianNumberplate(String? value) =>
      setField<String>('technician_numberplate', value);

  DateTime? get arrivalConfirmation =>
      getField<DateTime>('arrival_confirmation');
  set arrivalConfirmation(DateTime? value) =>
      setField<DateTime>('arrival_confirmation', value);

  List<int> get reviewedBy => getListField<int>('reviewed_by');
  set reviewedBy(List<int>? value) => setListField<int>('reviewed_by', value);

  String? get vehicleVin => getField<String>('vehicle_vin');
  set vehicleVin(String? value) => setField<String>('vehicle_vin', value);

  String? get address => getField<String>('address');
  set address(String? value) => setField<String>('address', value);

  bool? get notificationSent => getField<bool>('notification_sent');
  set notificationSent(bool? value) =>
      setField<bool>('notification_sent', value);

  List<int> get viewedBy => getListField<int>('viewed_by');
  set viewedBy(List<int>? value) => setListField<int>('viewed_by', value);

  List<int> get providerSentto => getListField<int>('provider_sentto');
  set providerSentto(List<int>? value) =>
      setListField<int>('provider_sentto', value);

  String? get suspension => getField<String>('suspension');
  set suspension(String? value) => setField<String>('suspension', value);

  String? get serviceImage => getField<String>('service_image');
  set serviceImage(String? value) => setField<String>('service_image', value);

  String? get technicianImage => getField<String>('technician_image');
  set technicianImage(String? value) =>
      setField<String>('technician_image', value);

  String? get providerNumber => getField<String>('provider_number');
  set providerNumber(String? value) =>
      setField<String>('provider_number', value);

  int? get chosenprovider => getField<int>('chosenprovider');
  set chosenprovider(int? value) => setField<int>('chosenprovider', value);

  int? get technicianStaffid => getField<int>('technician_staffid');
  set technicianStaffid(int? value) =>
      setField<int>('technician_staffid', value);

  int? get technicianUserid => getField<int>('technician_userid');
  set technicianUserid(int? value) => setField<int>('technician_userid', value);

  String? get technicianPhone => getField<String>('technician_phone');
  set technicianPhone(String? value) =>
      setField<String>('technician_phone', value);

  String? get selectedproviderImage =>
      getField<String>('selectedprovider_image');
  set selectedproviderImage(String? value) =>
      setField<String>('selectedprovider_image', value);

  String? get type => getField<String>('type');
  set type(String? value) => setField<String>('type', value);

  int? get serviceId => getField<int>('service_id');
  set serviceId(int? value) => setField<int>('service_id', value);

  bool? get emergency => getField<bool>('emergency');
  set emergency(bool? value) => setField<bool>('emergency', value);

  int? get driverRating => getField<int>('driver_rating');
  set driverRating(int? value) => setField<int>('driver_rating', value);

  String? get driverReview => getField<String>('driver_review');
  set driverReview(String? value) => setField<String>('driver_review', value);

  int? get technicianRating => getField<int>('technician_rating');
  set technicianRating(int? value) => setField<int>('technician_rating', value);

  String? get technicianReview => getField<String>('technician_review');
  set technicianReview(String? value) =>
      setField<String>('technician_review', value);

  int? get serviceproviderRating => getField<int>('serviceprovider_rating');
  set serviceproviderRating(int? value) =>
      setField<int>('serviceprovider_rating', value);

  String? get serviceproviderReview =>
      getField<String>('serviceprovider_review');
  set serviceproviderReview(String? value) =>
      setField<String>('serviceprovider_review', value);

  int? get transporterRating => getField<int>('transporter_rating');
  set transporterRating(int? value) =>
      setField<int>('transporter_rating', value);

  String? get transporterReview => getField<String>('transporter_review');
  set transporterReview(String? value) =>
      setField<String>('transporter_review', value);

  String? get invoicestatus => getField<String>('invoicestatus');
  set invoicestatus(String? value) => setField<String>('invoicestatus', value);

  String? get techVehicleimage => getField<String>('tech_vehicleimage');
  set techVehicleimage(String? value) =>
      setField<String>('tech_vehicleimage', value);

  DateTime? get onmyway => getField<DateTime>('onmyway');
  set onmyway(DateTime? value) => setField<DateTime>('onmyway', value);

  DateTime? get arrivedTech => getField<DateTime>('arrived_tech');
  set arrivedTech(DateTime? value) => setField<DateTime>('arrived_tech', value);

  bool? get paid => getField<bool>('paid');
  set paid(bool? value) => setField<bool>('paid', value);

  int? get calloutCount => getField<int>('callout_count');
  set calloutCount(int? value) => setField<int>('callout_count', value);

  bool? get bidsopen => getField<bool>('bidsopen');
  set bidsopen(bool? value) => setField<bool>('bidsopen', value);

  int? get primaryRequestid => getField<int>('primary_requestid');
  set primaryRequestid(int? value) => setField<int>('primary_requestid', value);
}

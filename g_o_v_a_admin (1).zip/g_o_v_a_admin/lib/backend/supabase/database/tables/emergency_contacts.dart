import '../database.dart';

class EmergencyContactsTable extends SupabaseTable<EmergencyContactsRow> {
  @override
  String get tableName => 'emergency_contacts';

  @override
  EmergencyContactsRow createRow(Map<String, dynamic> data) =>
      EmergencyContactsRow(data);
}

class EmergencyContactsRow extends SupabaseDataRow {
  EmergencyContactsRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => EmergencyContactsTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get name => getField<String>('name');
  set name(String? value) => setField<String>('name', value);

  String? get number => getField<String>('number');
  set number(String? value) => setField<String>('number', value);

  String? get email => getField<String>('email');
  set email(String? value) => setField<String>('email', value);

  int? get linkedUser => getField<int>('linked_user');
  set linkedUser(int? value) => setField<int>('linked_user', value);
}

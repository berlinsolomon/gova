import '../database.dart';

class ServiceprovidersTable extends SupabaseTable<ServiceprovidersRow> {
  @override
  String get tableName => 'serviceproviders';

  @override
  ServiceprovidersRow createRow(Map<String, dynamic> data) =>
      ServiceprovidersRow(data);
}

class ServiceprovidersRow extends SupabaseDataRow {
  ServiceprovidersRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => ServiceprovidersTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get companyName => getField<String>('company_name');
  set companyName(String? value) => setField<String>('company_name', value);

  List<String> get truckCategories => getListField<String>('truck_categories');
  set truckCategories(List<String>? value) =>
      setListField<String>('truck_categories', value);

  String? get description => getField<String>('description');
  set description(String? value) => setField<String>('description', value);

  String? get registration => getField<String>('registration');
  set registration(String? value) => setField<String>('registration', value);

  String? get phone => getField<String>('phone');
  set phone(String? value) => setField<String>('phone', value);

  String? get email => getField<String>('email');
  set email(String? value) => setField<String>('email', value);

  List<String> get trailerCategories =>
      getListField<String>('trailer_categories');
  set trailerCategories(List<String>? value) =>
      setListField<String>('trailer_categories', value);

  String? get emergencyNumber => getField<String>('emergency_number');
  set emergencyNumber(String? value) =>
      setField<String>('emergency_number', value);

  String? get vat => getField<String>('vat');
  set vat(String? value) => setField<String>('vat', value);

  String? get govaCode => getField<String>('gova_code');
  set govaCode(String? value) => setField<String>('gova_code', value);

  String? get coordinates => getField<String>('coordinates');
  set coordinates(String? value) => setField<String>('coordinates', value);

  String? get logo => getField<String>('logo');
  set logo(String? value) => setField<String>('logo', value);

  String? get address => getField<String>('address');
  set address(String? value) => setField<String>('address', value);

  String? get emergencyProcedure => getField<String>('emergency_procedure');
  set emergencyProcedure(String? value) =>
      setField<String>('emergency_procedure', value);

  List<String> get proofIns => getListField<String>('proof_ins');
  set proofIns(List<String>? value) => setListField<String>('proof_ins', value);

  List<String> get regdocs => getListField<String>('regdocs');
  set regdocs(List<String>? value) => setListField<String>('regdocs', value);

  List<String> get vatdocs => getListField<String>('vatdocs');
  set vatdocs(List<String>? value) => setListField<String>('vatdocs', value);
}

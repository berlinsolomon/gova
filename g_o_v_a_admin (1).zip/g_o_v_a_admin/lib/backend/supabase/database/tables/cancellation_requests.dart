import '../database.dart';

class CancellationRequestsTable extends SupabaseTable<CancellationRequestsRow> {
  @override
  String get tableName => 'cancellation_requests';

  @override
  CancellationRequestsRow createRow(Map<String, dynamic> data) =>
      CancellationRequestsRow(data);
}

class CancellationRequestsRow extends SupabaseDataRow {
  CancellationRequestsRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => CancellationRequestsTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  int? get incident => getField<int>('incident');
  set incident(int? value) => setField<int>('incident', value);

  String? get initiatorName => getField<String>('initiator_name');
  set initiatorName(String? value) => setField<String>('initiator_name', value);

  String? get initiatorUid => getField<String>('initiator_uid');
  set initiatorUid(String? value) => setField<String>('initiator_uid', value);

  int? get initiatorId => getField<int>('initiator_id');
  set initiatorId(int? value) => setField<int>('initiator_id', value);

  String? get initiatorRole => getField<String>('initiator_role');
  set initiatorRole(String? value) => setField<String>('initiator_role', value);

  String? get status => getField<String>('status');
  set status(String? value) => setField<String>('status', value);

  String? get cancellationReason => getField<String>('cancellation_reason');
  set cancellationReason(String? value) =>
      setField<String>('cancellation_reason', value);

  int? get transporterId => getField<int>('transporter_id');
  set transporterId(int? value) => setField<int>('transporter_id', value);

  int? get serviceProvider => getField<int>('service_provider');
  set serviceProvider(int? value) => setField<int>('service_provider', value);
}

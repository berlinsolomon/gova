import '../database.dart';

class TransporterStaffTable extends SupabaseTable<TransporterStaffRow> {
  @override
  String get tableName => 'transporter_staff';

  @override
  TransporterStaffRow createRow(Map<String, dynamic> data) =>
      TransporterStaffRow(data);
}

class TransporterStaffRow extends SupabaseDataRow {
  TransporterStaffRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => TransporterStaffTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get firstName => getField<String>('first_name');
  set firstName(String? value) => setField<String>('first_name', value);

  String? get lastName => getField<String>('last_name');
  set lastName(String? value) => setField<String>('last_name', value);

  int? get fleetcompany => getField<int>('fleetcompany');
  set fleetcompany(int? value) => setField<int>('fleetcompany', value);

  String? get staffCode => getField<String>('staff_code');
  set staffCode(String? value) => setField<String>('staff_code', value);

  List<String> get license => getListField<String>('license');
  set license(List<String>? value) => setListField<String>('license', value);

  String? get nationalId => getField<String>('national_id');
  set nationalId(String? value) => setField<String>('national_id', value);

  String? get fullname => getField<String>('fullname');
  set fullname(String? value) => setField<String>('fullname', value);

  String? get phone => getField<String>('phone');
  set phone(String? value) => setField<String>('phone', value);

  String? get email => getField<String>('email');
  set email(String? value) => setField<String>('email', value);

  String? get image => getField<String>('image');
  set image(String? value) => setField<String>('image', value);

  String? get status => getField<String>('status');
  set status(String? value) => setField<String>('status', value);
}

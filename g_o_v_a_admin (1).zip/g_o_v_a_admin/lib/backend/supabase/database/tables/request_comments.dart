import '../database.dart';

class RequestCommentsTable extends SupabaseTable<RequestCommentsRow> {
  @override
  String get tableName => 'request_comments';

  @override
  RequestCommentsRow createRow(Map<String, dynamic> data) =>
      RequestCommentsRow(data);
}

class RequestCommentsRow extends SupabaseDataRow {
  RequestCommentsRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => RequestCommentsTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get posterName => getField<String>('poster_name');
  set posterName(String? value) => setField<String>('poster_name', value);

  String? get posterRole => getField<String>('poster_role');
  set posterRole(String? value) => setField<String>('poster_role', value);

  String? get posterUid => getField<String>('poster_uid');
  set posterUid(String? value) => setField<String>('poster_uid', value);

  String? get comment => getField<String>('comment');
  set comment(String? value) => setField<String>('comment', value);

  int? get incident => getField<int>('incident');
  set incident(int? value) => setField<int>('incident', value);
}

import '../database.dart';

class ReviewsFleetcompaniesTable
    extends SupabaseTable<ReviewsFleetcompaniesRow> {
  @override
  String get tableName => 'reviews_fleetcompanies';

  @override
  ReviewsFleetcompaniesRow createRow(Map<String, dynamic> data) =>
      ReviewsFleetcompaniesRow(data);
}

class ReviewsFleetcompaniesRow extends SupabaseDataRow {
  ReviewsFleetcompaniesRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => ReviewsFleetcompaniesTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  int? get job => getField<int>('job');
  set job(int? value) => setField<int>('job', value);

  int? get rating => getField<int>('rating');
  set rating(int? value) => setField<int>('rating', value);

  String? get review => getField<String>('review');
  set review(String? value) => setField<String>('review', value);

  String? get userUid => getField<String>('user_uid');
  set userUid(String? value) => setField<String>('user_uid', value);

  String? get userName => getField<String>('user_name');
  set userName(String? value) => setField<String>('user_name', value);

  int? get serviceproviderId => getField<int>('serviceprovider_id');
  set serviceproviderId(int? value) =>
      setField<int>('serviceprovider_id', value);

  String? get serviceproviderName => getField<String>('serviceprovider_name');
  set serviceproviderName(String? value) =>
      setField<String>('serviceprovider_name', value);

  String? get reply => getField<String>('reply');
  set reply(String? value) => setField<String>('reply', value);

  String? get replierUid => getField<String>('replier_uid');
  set replierUid(String? value) => setField<String>('replier_uid', value);

  String? get replierName => getField<String>('replier_name');
  set replierName(String? value) => setField<String>('replier_name', value);

  int? get fleetcompany => getField<int>('fleetcompany');
  set fleetcompany(int? value) => setField<int>('fleetcompany', value);

  String? get jobdetails => getField<String>('jobdetails');
  set jobdetails(String? value) => setField<String>('jobdetails', value);
}

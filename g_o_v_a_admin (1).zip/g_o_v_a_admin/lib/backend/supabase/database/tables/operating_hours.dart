import '../database.dart';

class OperatingHoursTable extends SupabaseTable<OperatingHoursRow> {
  @override
  String get tableName => 'operating_hours';

  @override
  OperatingHoursRow createRow(Map<String, dynamic> data) =>
      OperatingHoursRow(data);
}

class OperatingHoursRow extends SupabaseDataRow {
  OperatingHoursRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => OperatingHoursTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get day => getField<String>('day');
  set day(String? value) => setField<String>('day', value);

  String? get startTime => getField<String>('start_time');
  set startTime(String? value) => setField<String>('start_time', value);

  String? get endTime => getField<String>('end_time');
  set endTime(String? value) => setField<String>('end_time', value);

  String? get serviceproviderName => getField<String>('serviceprovider_name');
  set serviceproviderName(String? value) =>
      setField<String>('serviceprovider_name', value);

  int? get serviceproviderId => getField<int>('serviceprovider_id');
  set serviceproviderId(int? value) =>
      setField<int>('serviceprovider_id', value);
}

import 'dart:convert';
import 'dart:typed_data';
import '../schema/structs/index.dart';

import 'package:flutter/foundation.dart';

import '/flutter_flow/flutter_flow_util.dart';
import 'api_manager.dart';

export 'api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

class InitiateCall {
  static Future<ApiCallResponse> call({
    int? amount,
    String? ref = '',
    String? userEmail = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'Initiate',
      apiUrl: 'https://hook.eu1.make.com/fnzr74xzoa9es3hzfy6tjm9wsjgcr7iv',
      callType: ApiCallType.GET,
      headers: {},
      params: {
        'amount': amount,
        'user_email': userEmail,
        'ref': ref,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  static String? url(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.link''',
      ));
  static String? accesscode(dynamic response) =>
      castToType<String>(getJsonField(
        response,
        r'''$.access_code''',
      ));
  static String? ref(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.reference''',
      ));
}

class VerifyCall {
  static Future<ApiCallResponse> call({
    String? transactionRef = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'Verify',
      apiUrl: 'https://hook.eu1.make.com/hswfwe6gmidhbkl7mvq821yca9tqghji',
      callType: ApiCallType.GET,
      headers: {},
      params: {
        'transaction_ref': transactionRef,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  static String? status(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.status''',
      ));
  static String? authcode(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.auth''',
      ));
}

class ChargeCall {
  static Future<ApiCallResponse> call({
    int? amount,
    String? email = '',
    String? authorizationCode = '',
    String? ref = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'Charge',
      apiUrl: 'https://hook.eu1.make.com/qn5ncw16enrw7my8duz1inpg719kkrjg',
      callType: ApiCallType.GET,
      headers: {},
      params: {
        'amount': amount,
        'email': email,
        'authorization_code': authorizationCode,
        'ref': ref,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  static String? status(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.status''',
      ));
  static String? pmtref(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.pmtref''',
      ));
}

class NewDriverCall {
  static Future<ApiCallResponse> call({
    String? phone = '',
    String? code = '',
    String? company = '',
    String? type = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'New Driver',
      apiUrl: 'https://hook.eu1.make.com/xwm2inmc246r2tkay1oddnhcgcz41h5v',
      callType: ApiCallType.GET,
      headers: {},
      params: {
        'phone': phone,
        'code': code,
        'company': company,
        'type': type,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class NotifyGOVAAdminsCall {
  static Future<ApiCallResponse> call({
    String? companyName = '',
    String? phone = '',
    String? email = '',
    String? registrationDocs = '',
    String? type = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'Notify GOVA admins',
      apiUrl: 'https://hook.eu1.make.com/wi3smkhxieutdnw24x5sdy5ycmco2dce',
      callType: ApiCallType.GET,
      headers: {},
      params: {
        'company_name': companyName,
        'phone': phone,
        'email': email,
        'registration_docs': registrationDocs,
        'type': type,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class NotifyDriverCall {
  static Future<ApiCallResponse> call({
    String? driverphone = '',
    String? message = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'Notify Driver',
      apiUrl: 'https://hook.eu1.make.com/6k7rwfn11qkmxh34ah80irvr3sgzumlq',
      callType: ApiCallType.GET,
      headers: {},
      params: {
        'driverphone': driverphone,
        'message': message,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class IncidentSentToProvidersCall {
  static Future<ApiCallResponse> call({
    String? driverPhone = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'Incident sent to providers',
      apiUrl: 'https://hook.eu1.make.com/27bdx8cjb6jaag9i15f5s5mg7e6s8ve5',
      callType: ApiCallType.GET,
      headers: {},
      params: {
        'driver_phone': driverPhone,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class NewBidFromServiceProviderCall {
  static Future<ApiCallResponse> call({
    String? fmPhone = '',
    String? serviceProvider = '',
    String? services = '',
    String? incident = '',
    String? driverName = '',
    String? address = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'New bid from service provider',
      apiUrl: 'https://hook.eu1.make.com/r31gpb2jftj76ddydtdwwwtb7dscx7l3',
      callType: ApiCallType.GET,
      headers: {},
      params: {
        'fm_phone': fmPhone,
        'service_provider': serviceProvider,
        'services': services,
        'incident': incident,
        'driver_name': driverName,
        'address': address,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ServiceProviderSelectedCall {
  static Future<ApiCallResponse> call({
    String? spPhone = '',
    String? driverPhone = '',
    String? spName = '',
    String? driverName = '',
    String? services = '',
    String? transporter = '',
    String? address = '',
    String? vin = '',
    String? incidentNumber = '',
    String? transporterPhone = '',
    String? details = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'Service provider selected',
      apiUrl: 'https://hook.eu1.make.com/wscxps1mjb9wswt33lsscor9np766khd',
      callType: ApiCallType.GET,
      headers: {},
      params: {
        'sp_phone': spPhone,
        'driver_phone': driverPhone,
        'sp_name': spName,
        'driver_name': driverName,
        'services': services,
        'transporter': transporter,
        'address': address,
        'vin': vin,
        'incident_number': incidentNumber,
        'transporter_phone': transporterPhone,
        'details': details,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class TechnicianAssignedCall {
  static Future<ApiCallResponse> call({
    String? techNumber = '',
    String? techName = '',
    String? serviceProvider = '',
    String? driverName = '',
    String? driverNumber = '',
    String? transporter = '',
    String? transporterPhone = '',
    String? incident = '',
    String? location = '',
    String? vehicle = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'Technician Assigned',
      apiUrl: 'https://hook.eu1.make.com/apo2m3kbjqo8i5vi0h4t9k205s3qbyf5',
      callType: ApiCallType.GET,
      headers: {},
      params: {
        'tech_number': techNumber,
        'tech_name': techName,
        'service_provider': serviceProvider,
        'driver_name': driverName,
        'driver_number': driverNumber,
        'transporter': transporter,
        'transporter_phone': transporterPhone,
        'incident': incident,
        'location': location,
        'vehicle': vehicle,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ApiPagingParams {
  int nextPageNumber = 0;
  int numItems = 0;
  dynamic lastResponse;

  ApiPagingParams({
    required this.nextPageNumber,
    required this.numItems,
    required this.lastResponse,
  });

  @override
  String toString() =>
      'PagingParams(nextPageNumber: $nextPageNumber, numItems: $numItems, lastResponse: $lastResponse,)';
}

String _toEncodable(dynamic item) {
  if (item is DocumentReference) {
    return item.path;
  }
  return item;
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("List serialization failed. Returning empty list.");
    }
    return '[]';
  }
}

String _serializeJson(dynamic jsonVar, [bool isList = false]) {
  jsonVar ??= (isList ? [] : {});
  try {
    return json.encode(jsonVar, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("Json serialization failed. Returning empty json.");
    }
    return isList ? '[]' : '{}';
  }
}

import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/push_notifications/push_notifications_util.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';
import 'provider_cancel_model.dart';
export 'provider_cancel_model.dart';

class ProviderCancelWidget extends StatefulWidget {
  const ProviderCancelWidget({
    super.key,
    required this.incident,
    required this.refresh,
    required this.user,
  });

  final RequestsRow? incident;
  final Future Function()? refresh;
  final UsersRow? user;

  @override
  State<ProviderCancelWidget> createState() => _ProviderCancelWidgetState();
}

class _ProviderCancelWidgetState extends State<ProviderCancelWidget> {
  late ProviderCancelModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ProviderCancelModel());

    _model.textController ??= TextEditingController();
    _model.textFieldFocusNode ??= FocusNode();

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: AlignmentDirectional(0.0, 0.0),
      child: Padding(
        padding: EdgeInsets.all(24.0),
        child: Container(
          width: double.infinity,
          constraints: BoxConstraints(
            maxWidth: 520.0,
          ),
          decoration: BoxDecoration(
            color: FlutterFlowTheme.of(context).secondaryBackground,
            borderRadius: BorderRadius.circular(16.0),
          ),
          child: Padding(
            padding: EdgeInsets.all(16.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 12.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Cancel Request',
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              font: GoogleFonts.lato(
                                fontWeight: FontWeight.w600,
                                fontStyle: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .fontStyle,
                              ),
                              fontSize: 16.0,
                              letterSpacing: 0.0,
                              fontWeight: FontWeight.w600,
                              fontStyle: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .fontStyle,
                            ),
                      ),
                      FlutterFlowIconButton(
                        borderRadius: 8.0,
                        buttonSize: 40.0,
                        icon: Icon(
                          Icons.close_sharp,
                          color: Color(0xFFDD0D4A),
                          size: 24.0,
                        ),
                        onPressed: () async {
                          Navigator.pop(context);
                        },
                      ),
                    ],
                  ),
                ),
                Text(
                  'Please enter the reason why you want to cancel this incident request',
                  textAlign: TextAlign.start,
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        font: GoogleFonts.lato(
                          fontWeight: FlutterFlowTheme.of(context)
                              .bodyMedium
                              .fontWeight,
                          fontStyle:
                              FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                        ),
                        letterSpacing: 0.0,
                        fontWeight:
                            FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                        fontStyle:
                            FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                      ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 20.0, 0.0, 20.0),
                  child: Container(
                    width: double.infinity,
                    child: TextFormField(
                      controller: _model.textController,
                      focusNode: _model.textFieldFocusNode,
                      autofocus: false,
                      textInputAction: TextInputAction.done,
                      obscureText: false,
                      decoration: InputDecoration(
                        isDense: true,
                        labelStyle:
                            FlutterFlowTheme.of(context).labelMedium.override(
                                  font: GoogleFonts.lato(
                                    fontWeight: FlutterFlowTheme.of(context)
                                        .labelMedium
                                        .fontWeight,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .labelMedium
                                        .fontStyle,
                                  ),
                                  letterSpacing: 0.0,
                                  fontWeight: FlutterFlowTheme.of(context)
                                      .labelMedium
                                      .fontWeight,
                                  fontStyle: FlutterFlowTheme.of(context)
                                      .labelMedium
                                      .fontStyle,
                                ),
                        hintText:
                            'Please provide more information as to why you want to cancel this incident request',
                        hintStyle:
                            FlutterFlowTheme.of(context).labelMedium.override(
                                  font: GoogleFonts.lato(
                                    fontWeight: FlutterFlowTheme.of(context)
                                        .labelMedium
                                        .fontWeight,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .labelMedium
                                        .fontStyle,
                                  ),
                                  letterSpacing: 0.0,
                                  fontWeight: FlutterFlowTheme.of(context)
                                      .labelMedium
                                      .fontWeight,
                                  fontStyle: FlutterFlowTheme.of(context)
                                      .labelMedium
                                      .fontStyle,
                                ),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: FlutterFlowTheme.of(context).alternate,
                            width: 2.0,
                          ),
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: Color(0xFF3800FF),
                            width: 2.0,
                          ),
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        errorBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: FlutterFlowTheme.of(context).error,
                            width: 2.0,
                          ),
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        focusedErrorBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: FlutterFlowTheme.of(context).error,
                            width: 2.0,
                          ),
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        filled: true,
                        fillColor:
                            FlutterFlowTheme.of(context).secondaryBackground,
                        contentPadding: EdgeInsetsDirectional.fromSTEB(
                            16.0, 20.0, 16.0, 20.0),
                      ),
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            font: GoogleFonts.lato(
                              fontWeight: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .fontWeight,
                              fontStyle: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .fontStyle,
                            ),
                            letterSpacing: 0.0,
                            fontWeight: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .fontWeight,
                            fontStyle: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .fontStyle,
                          ),
                      maxLines: 12,
                      minLines: 6,
                      cursorColor: FlutterFlowTheme.of(context).primaryText,
                      validator:
                          _model.textControllerValidator.asValidator(context),
                    ),
                  ),
                ),
                FFButtonWidget(
                  onPressed: () async {
                    var _shouldSetState = false;
                    _model.checkifcancellationalready =
                        await CancellationRequestsTable().queryRows(
                      queryFn: (q) => q
                          .eqOrNull(
                            'incident',
                            widget!.incident?.id,
                          )
                          .eqOrNull(
                            'service_provider',
                            widget!.user?.serviceProvider,
                          ),
                    );
                    _shouldSetState = true;
                    await RequestsTable().update(
                      data: {
                        'chosenprovider': null,
                        'chosen_providers': null,
                        'ignored_by': functions.addintegertolist(
                            widget!.user!.serviceProvider!,
                            widget!.incident!.ignoredBy.toList()),
                        'technician': null,
                        'technician_image': null,
                        'technician_phone': null,
                        'technician_userid': null,
                        'tech_vehicleimage': null,
                        'technicial_vehicle': null,
                        'technician_staffid': null,
                        'technician_numberplate': null,
                      },
                      matchingRows: (rows) => rows.eqOrNull(
                        'id',
                        widget!.incident?.id,
                      ),
                    );
                    await RequestCommentsTable().insert({
                      'poster_name':
                          '${widget!.user?.firstName} ${widget!.user?.lastName}',
                      'poster_uid': currentUserUid,
                      'incident': widget!.incident?.id,
                      'comment':
                          'User has withdrawn from the incident. Reason: ${_model.textController.text}',
                      'created_at':
                          supaSerialize<DateTime>(getCurrentTimestamp),
                      'poster_role': widget!.user?.currentrole,
                    });
                    if (_model.checkifcancellationalready != null &&
                        (_model.checkifcancellationalready)!.isNotEmpty) {
                      await CancellationRequestsTable().update(
                        data: {
                          'status': 'Successful',
                        },
                        matchingRows: (rows) => rows.eqOrNull(
                          'id',
                          _model.checkifcancellationalready?.firstOrNull?.id,
                        ),
                      );
                      _shouldSetState = true;
                    } else {
                      if (_model.textController.text != null &&
                          _model.textController.text != '') {
                        _model.newrequestProvider =
                            await CancellationRequestsTable().insert({
                          'incident': widget!.incident?.id,
                          'initiator_name':
                              '${widget!.user?.firstName} ${widget!.user?.lastName}',
                          'initiator_uid': widget!.user?.uid,
                          'initiator_id': widget!.user?.id,
                          'initiator_role': 'Service Provider',
                          'status': 'Successful',
                          'cancellation_reason': _model.textController.text,
                          'service_provider': widget!.user?.serviceProvider,
                        });
                        _shouldSetState = true;
                      } else {
                        await showDialog(
                          context: context,
                          builder: (alertDialogContext) {
                            return WebViewAware(
                              child: AlertDialog(
                                title:
                                    Text('Please add a reason for cancelling'),
                                actions: [
                                  TextButton(
                                    onPressed: () =>
                                        Navigator.pop(alertDialogContext),
                                    child: Text('Ok'),
                                  ),
                                ],
                              ),
                            );
                          },
                        );
                        if (_shouldSetState) safeSetState(() {});
                        return;
                      }
                    }

                    await Future.wait([
                      Future(() async {
                        _model.findfleetmanagers = await UsersTable().queryRows(
                          queryFn: (q) => q
                              .eqOrNull(
                                'transporter_id',
                                widget!.incident?.fleetcompanyId,
                              )
                              .eqOrNull(
                                'currentrole',
                                'Fleet Manager',
                              ),
                        );
                        _shouldSetState = true;
                        _model.findfleetmanagersfb = await queryUsersRecordOnce(
                          queryBuilder: (usersRecord) => usersRecord.whereIn(
                              'uid',
                              _model.findfleetmanagers
                                  ?.map((e) => e.uid)
                                  .withoutNulls
                                  .toList()),
                        );
                        _shouldSetState = true;
                        triggerPushNotification(
                          notificationTitle: 'Service Provider Withdrawn',
                          notificationText:
                              'The selected service provider (${widget!.incident?.chosenProviders}) has withdrawn from the incident and will no longer be serving the request. Reason: ${_model.textController.text}',
                          notificationSound: 'default',
                          userRefs: _model.findfleetmanagersfb!
                              .map((e) => e.reference)
                              .toList(),
                          initialPageName: 'request_details',
                          parameterData: {
                            'role': 'Fleet Manager',
                            'requestid': widget!.incident?.id,
                            'completed': false,
                          },
                        );
                      }),
                      Future(() async {
                        _model.finddriverFb = await queryUsersRecordOnce(
                          queryBuilder: (usersRecord) => usersRecord.where(
                            'uid',
                            isEqualTo: widget!.incident?.requesterUid,
                          ),
                          singleRecord: true,
                        ).then((s) => s.firstOrNull);
                        _shouldSetState = true;
                        triggerPushNotification(
                          notificationTitle: 'Service Provider Withdrawn',
                          notificationText:
                              'The selected service provider (${widget!.incident?.chosenProviders}) has withdrawn from the incident and will no longer be serving the request. Reason: ${_model.textController.text}',
                          notificationSound: 'default',
                          userRefs: [_model.finddriverFb!.reference],
                          initialPageName: 'request_details',
                          parameterData: {
                            'role': 'Driver',
                            'requestid': widget!.incident?.id,
                            'completed': false,
                          },
                        );
                      }),
                      Future(() async {
                        if (widget!.incident?.technician != null &&
                            widget!.incident?.technician != '') {
                          _model.findtechnician = await UsersTable().queryRows(
                            queryFn: (q) => q.eqOrNull(
                              'id',
                              widget!.incident?.technicianUserid,
                            ),
                          );
                          _shouldSetState = true;
                          _model.findtech = await queryUsersRecordOnce(
                            queryBuilder: (usersRecord) => usersRecord.where(
                              'uid',
                              isEqualTo:
                                  _model.findtechnician?.firstOrNull?.uid,
                            ),
                            singleRecord: true,
                          ).then((s) => s.firstOrNull);
                          _shouldSetState = true;
                          triggerPushNotification(
                            notificationTitle: 'Withdrawn from incident.',
                            notificationText:
                                'Your admin has withdrawn from this incident',
                            notificationSound: 'default',
                            userRefs: [_model.findtech!.reference],
                            initialPageName: 'dashboard',
                            parameterData: {},
                          );
                        }
                      }),
                    ]);
                    await widget.refresh?.call();
                    await showDialog(
                      context: context,
                      builder: (alertDialogContext) {
                        return WebViewAware(
                          child: AlertDialog(
                            title: Text('Cancellation complete'),
                            content: Text('The transporter will be notified.'),
                            actions: [
                              TextButton(
                                onPressed: () =>
                                    Navigator.pop(alertDialogContext),
                                child: Text('Ok'),
                              ),
                            ],
                          ),
                        );
                      },
                    );
                    Navigator.pop(context);
                    if (_shouldSetState) safeSetState(() {});
                  },
                  text: 'Confirm & Cancel',
                  options: FFButtonOptions(
                    width: double.infinity,
                    height: 52.0,
                    padding:
                        EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                    iconPadding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                    color: FlutterFlowTheme.of(context).primary,
                    textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                          font: GoogleFonts.lato(
                            fontWeight: FlutterFlowTheme.of(context)
                                .titleSmall
                                .fontWeight,
                            fontStyle: FlutterFlowTheme.of(context)
                                .titleSmall
                                .fontStyle,
                          ),
                          color: Colors.white,
                          fontSize: 14.0,
                          letterSpacing: 0.0,
                          fontWeight: FlutterFlowTheme.of(context)
                              .titleSmall
                              .fontWeight,
                          fontStyle:
                              FlutterFlowTheme.of(context).titleSmall.fontStyle,
                        ),
                    elevation: 2.0,
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

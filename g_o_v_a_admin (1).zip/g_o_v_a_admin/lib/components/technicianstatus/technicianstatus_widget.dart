import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'technicianstatus_model.dart';
export 'technicianstatus_model.dart';

class TechnicianstatusWidget extends StatefulWidget {
  const TechnicianstatusWidget({
    super.key,
    required this.technician,
    required this.refresh,
  });

  final ServiceproviderStaffRow? technician;
  final Future Function(String status)? refresh;

  @override
  State<TechnicianstatusWidget> createState() => _TechnicianstatusWidgetState();
}

class _TechnicianstatusWidgetState extends State<TechnicianstatusWidget> {
  late TechnicianstatusModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => TechnicianstatusModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FlutterFlowDropDown<String>(
      controller: _model.dropDownValueController ??=
          FormFieldController<String>(
        _model.dropDownValue ??= widget!.technician?.status,
      ),
      options: ['Active', 'Inactive'],
      onChanged: (val) async {
        safeSetState(() => _model.dropDownValue = val);
        await widget.refresh?.call(
          _model.dropDownValue!,
        );
      },
      height: 44.0,
      textStyle: FlutterFlowTheme.of(context).bodyMedium.override(
            font: GoogleFonts.lato(
              fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
              fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
            ),
            letterSpacing: 0.0,
            fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
            fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
          ),
      hintText: 'Select...',
      icon: Icon(
        Icons.keyboard_arrow_down_rounded,
        color: FlutterFlowTheme.of(context).secondaryText,
        size: 24.0,
      ),
      fillColor: widget!.technician?.status == 'Active'
          ? FlutterFlowTheme.of(context).accent2
          : Color(0x44FF5963),
      elevation: 2.0,
      borderColor: widget!.technician?.status == 'Active'
          ? FlutterFlowTheme.of(context).success
          : FlutterFlowTheme.of(context).error,
      borderWidth: 1.0,
      borderRadius: 8.0,
      margin: EdgeInsetsDirectional.fromSTEB(12.0, 0.0, 12.0, 0.0),
      hidesUnderline: true,
      isOverButton: false,
      isSearchable: false,
      isMultiSelect: false,
    );
  }
}

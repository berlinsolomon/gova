import '/auth/firebase_auth/auth_util.dart';
import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/backend/push_notifications/push_notifications_util.dart';
import '/backend/supabase/supabase.dart';
import '/components/vendor_profile/vendor_profile_widget.dart';
import '/fleetmanager/add_details/add_details_widget.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_web_view.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/instant_timer.dart';
import 'dart:math';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_blurhash/flutter_blurhash.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:octo_image/octo_image.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';
import 'incidentbidders_model.dart';
export 'incidentbidders_model.dart';

class IncidentbiddersWidget extends StatefulWidget {
  const IncidentbiddersWidget({
    super.key,
    required this.incident,
    required this.refresh,
  });

  final RequestsRow? incident;
  final Future Function()? refresh;

  @override
  State<IncidentbiddersWidget> createState() => _IncidentbiddersWidgetState();
}

class _IncidentbiddersWidgetState extends State<IncidentbiddersWidget>
    with TickerProviderStateMixin {
  late IncidentbiddersModel _model;

  final animationsMap = <String, AnimationInfo>{};

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => IncidentbiddersModel());

    // On component load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      _model.instantTimer = InstantTimer.periodic(
        duration: Duration(milliseconds: 5000),
        callback: (timer) async {
          safeSetState(() => _model.requestCompleter2 = null);
        },
        startImmediately: true,
      );
    });

    animationsMap.addAll({
      'containerOnActionTriggerAnimation1': AnimationInfo(
        trigger: AnimationTrigger.onActionTrigger,
        applyInitialState: true,
        effectsBuilder: () => [
          FadeEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 400.0.ms,
            begin: 0.0,
            end: 1.0,
          ),
        ],
      ),
      'containerOnActionTriggerAnimation2': AnimationInfo(
        trigger: AnimationTrigger.onActionTrigger,
        applyInitialState: true,
        effectsBuilder: () => [
          FadeEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 400.0.ms,
            begin: 0.0,
            end: 1.0,
          ),
        ],
      ),
    });
    setupAnimations(
      animationsMap.values.where((anim) =>
          anim.trigger == AnimationTrigger.onActionTrigger ||
          !anim.applyInitialState),
      this,
    );

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: AlignmentDirectional(0.0, 0.0),
      child: Padding(
        padding: EdgeInsets.all(24.0),
        child: FutureBuilder<List<ServiceprovidersRow>>(
          future: ServiceprovidersTable().queryRows(
            queryFn: (q) => q.or(
                "truck_categories.cs.{${widget!.incident?.serviceRequested}}, trailer_categories.cs.{${widget!.incident?.serviceRequested}}"),
          ),
          builder: (context, snapshot) {
            // Customize what your widget looks like when it's loading.
            if (!snapshot.hasData) {
              return Center(
                child: SizedBox(
                  width: 50.0,
                  height: 50.0,
                  child: CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation<Color>(
                      FlutterFlowTheme.of(context).primary,
                    ),
                  ),
                ),
              );
            }
            List<ServiceprovidersRow> containerServiceprovidersRowList =
                snapshot.data!;

            return Container(
              width: double.infinity,
              constraints: BoxConstraints(
                maxWidth: 1180.0,
                maxHeight: 840.0,
              ),
              decoration: BoxDecoration(
                color: FlutterFlowTheme.of(context).secondaryBackground,
                borderRadius: BorderRadius.circular(16.0),
              ),
              child: FutureBuilder<List<RequestsRow>>(
                future:
                    (_model.requestCompleter2 ??= Completer<List<RequestsRow>>()
                          ..complete(RequestsTable().querySingleRow(
                            queryFn: (q) => q.eqOrNull(
                              'id',
                              widget!.incident?.id,
                            ),
                          )))
                        .future,
                builder: (context, snapshot) {
                  // Customize what your widget looks like when it's loading.
                  if (!snapshot.hasData) {
                    return Center(
                      child: SizedBox(
                        width: 50.0,
                        height: 50.0,
                        child: CircularProgressIndicator(
                          valueColor: AlwaysStoppedAnimation<Color>(
                            FlutterFlowTheme.of(context).primary,
                          ),
                        ),
                      ),
                    );
                  }
                  List<RequestsRow> stackRequestsRowList = snapshot.data!;

                  final stackRequestsRow = stackRequestsRowList.isNotEmpty
                      ? stackRequestsRowList.first
                      : null;

                  return Stack(
                    children: [
                      Padding(
                        padding: EdgeInsets.all(24.0),
                        child: Column(
                          mainAxisSize: MainAxisSize.max,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  'Bids',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        font: GoogleFonts.lato(
                                          fontWeight: FontWeight.bold,
                                          fontStyle:
                                              FlutterFlowTheme.of(context)
                                                  .bodyMedium
                                                  .fontStyle,
                                        ),
                                        fontSize: 20.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.bold,
                                        fontStyle: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .fontStyle,
                                      ),
                                ),
                                FlutterFlowIconButton(
                                  borderRadius: 8.0,
                                  buttonSize: 52.0,
                                  icon: Icon(
                                    Icons.close_sharp,
                                    color: Color(0xFFDD0D4A),
                                    size: 24.0,
                                  ),
                                  onPressed: () async {
                                    Navigator.pop(context);
                                  },
                                ),
                              ],
                            ),
                            if ((stackRequestsRow?.providersTendered != null &&
                                    (stackRequestsRow?.providersTendered)!
                                        .isNotEmpty) ==
                                true)
                              Text(
                                'Below is a list of all the service providers bidding on this incident',
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      font: GoogleFonts.lato(
                                        fontWeight: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .fontWeight,
                                        fontStyle: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .fontStyle,
                                      ),
                                      letterSpacing: 0.0,
                                      fontWeight: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .fontWeight,
                                      fontStyle: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .fontStyle,
                                    ),
                              ),
                            if ((stackRequestsRow?.providersTendered != null &&
                                    (stackRequestsRow?.providersTendered)!
                                        .isNotEmpty) ==
                                false)
                              RichText(
                                textScaler: MediaQuery.of(context).textScaler,
                                text: TextSpan(
                                  children: [
                                    TextSpan(
                                      text:
                                          'Below is a list of nearby service providers that offer ',
                                      style: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .override(
                                            font: GoogleFonts.lato(
                                              fontWeight:
                                                  FlutterFlowTheme.of(context)
                                                      .bodyMedium
                                                      .fontWeight,
                                              fontStyle:
                                                  FlutterFlowTheme.of(context)
                                                      .bodyMedium
                                                      .fontStyle,
                                            ),
                                            letterSpacing: 0.0,
                                            fontWeight:
                                                FlutterFlowTheme.of(context)
                                                    .bodyMedium
                                                    .fontWeight,
                                            fontStyle:
                                                FlutterFlowTheme.of(context)
                                                    .bodyMedium
                                                    .fontStyle,
                                          ),
                                    ),
                                    TextSpan(
                                      text: widget!.incident!.serviceRequested!,
                                      style: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .override(
                                            font: GoogleFonts.lato(
                                              fontWeight: FontWeight.bold,
                                              fontStyle:
                                                  FlutterFlowTheme.of(context)
                                                      .bodyMedium
                                                      .fontStyle,
                                            ),
                                            color: Color(0xFF4B39EF),
                                            letterSpacing: 0.0,
                                            fontWeight: FontWeight.bold,
                                            fontStyle:
                                                FlutterFlowTheme.of(context)
                                                    .bodyMedium
                                                    .fontStyle,
                                          ),
                                    ),
                                    TextSpan(
                                      text: ' services',
                                      style: TextStyle(),
                                    )
                                  ],
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        font: GoogleFonts.lato(
                                          fontWeight:
                                              FlutterFlowTheme.of(context)
                                                  .bodyMedium
                                                  .fontWeight,
                                          fontStyle:
                                              FlutterFlowTheme.of(context)
                                                  .bodyMedium
                                                  .fontStyle,
                                        ),
                                        letterSpacing: 0.0,
                                        fontWeight: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .fontWeight,
                                        fontStyle: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .fontStyle,
                                      ),
                                ),
                              ),
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 16.0, 0.0, 0.0),
                              child: Stack(
                                children: [
                                  if (stackRequestsRow?.paid == false)
                                    Padding(
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          0.0, 0.0, 0.0, 8.0),
                                      child: FFButtonWidget(
                                        onPressed: () async {
                                          if ((stackRequestsRow?.vehicleVin !=
                                                      null &&
                                                  stackRequestsRow
                                                          ?.vehicleVin !=
                                                      '') &&
                                              (stackRequestsRow?.vehicleVin !=
                                                  'N/A')) {
                                            _model.findfleetcompany =
                                                await TransportersTable()
                                                    .queryRows(
                                              queryFn: (q) => q.eqOrNull(
                                                'id',
                                                stackRequestsRow
                                                    ?.fleetcompanyId,
                                              ),
                                            );
                                            _model.initiatetransaction =
                                                await InitiateCall.call(
                                              amount: 15000,
                                              ref:
                                                  'GOVA${dateTimeFormat("ddMMyHHmmss", getCurrentTimestamp)}',
                                              userEmail: _model.findfleetcompany
                                                  ?.firstOrNull?.email,
                                            );

                                            if ((_model.initiatetransaction
                                                    ?.succeeded ??
                                                true)) {
                                              _model.cardpmt = true;
                                              _model.link = InitiateCall.url(
                                                (_model.initiatetransaction
                                                        ?.jsonBody ??
                                                    ''),
                                              );
                                              _model.accesscode =
                                                  InitiateCall.accesscode(
                                                (_model.initiatetransaction
                                                        ?.jsonBody ??
                                                    ''),
                                              );
                                              _model.ref = InitiateCall.ref(
                                                (_model.initiatetransaction
                                                        ?.jsonBody ??
                                                    ''),
                                              );
                                              safeSetState(() {});
                                              await Future.wait([
                                                Future(() async {
                                                  if (animationsMap[
                                                          'containerOnActionTriggerAnimation1'] !=
                                                      null) {
                                                    await animationsMap[
                                                            'containerOnActionTriggerAnimation1']!
                                                        .controller
                                                        .forward(from: 0.0);
                                                  }
                                                }),
                                                Future(() async {
                                                  if (animationsMap[
                                                          'containerOnActionTriggerAnimation2'] !=
                                                      null) {
                                                    await animationsMap[
                                                            'containerOnActionTriggerAnimation2']!
                                                        .controller
                                                        .forward(from: 0.0);
                                                  }
                                                }),
                                              ]);
                                            } else {
                                              await showDialog(
                                                context: context,
                                                builder: (alertDialogContext) {
                                                  return WebViewAware(
                                                    child: AlertDialog(
                                                      title: Text(
                                                          'Payment failed.'),
                                                      content: Text(
                                                          'Please try again or contact GOVA support.'),
                                                      actions: [
                                                        TextButton(
                                                          onPressed: () =>
                                                              Navigator.pop(
                                                                  alertDialogContext),
                                                          child: Text('Ok'),
                                                        ),
                                                      ],
                                                    ),
                                                  );
                                                },
                                              );
                                            }
                                          } else {
                                            await showModalBottomSheet(
                                              isScrollControlled: true,
                                              backgroundColor:
                                                  Colors.transparent,
                                              enableDrag: false,
                                              context: context,
                                              builder: (context) {
                                                return WebViewAware(
                                                  child: Padding(
                                                    padding:
                                                        MediaQuery.viewInsetsOf(
                                                            context),
                                                    child: AddDetailsWidget(
                                                      incident:
                                                          stackRequestsRow?.id,
                                                      refresh: () async {
                                                        safeSetState(() => _model
                                                                .requestCompleter =
                                                            null);
                                                      },
                                                    ),
                                                  ),
                                                );
                                              },
                                            ).then(
                                                (value) => safeSetState(() {}));
                                          }

                                          safeSetState(() {});
                                        },
                                        text:
                                            'Send to nearby service providers',
                                        icon: Icon(
                                          Icons.send_sharp,
                                          size: 20.0,
                                        ),
                                        options: FFButtonOptions(
                                          width: double.infinity,
                                          height: 52.0,
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  16.0, 0.0, 16.0, 0.0),
                                          iconPadding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  0.0, 0.0, 0.0, 0.0),
                                          color: FlutterFlowTheme.of(context)
                                              .primary,
                                          textStyle: FlutterFlowTheme.of(
                                                  context)
                                              .titleSmall
                                              .override(
                                                font: GoogleFonts.lato(
                                                  fontWeight:
                                                      FlutterFlowTheme.of(
                                                              context)
                                                          .titleSmall
                                                          .fontWeight,
                                                  fontStyle:
                                                      FlutterFlowTheme.of(
                                                              context)
                                                          .titleSmall
                                                          .fontStyle,
                                                ),
                                                color: Colors.white,
                                                fontSize: 14.0,
                                                letterSpacing: 0.0,
                                                fontWeight:
                                                    FlutterFlowTheme.of(context)
                                                        .titleSmall
                                                        .fontWeight,
                                                fontStyle:
                                                    FlutterFlowTheme.of(context)
                                                        .titleSmall
                                                        .fontStyle,
                                              ),
                                          elevation: 2.0,
                                          borderRadius:
                                              BorderRadius.circular(8.0),
                                        ),
                                      ),
                                    ),
                                  if (((stackRequestsRow?.providersTendered !=
                                                  null &&
                                              (stackRequestsRow
                                                      ?.providersTendered)!
                                                  .isNotEmpty) ==
                                          false) &&
                                      (stackRequestsRow!
                                          .providerSentto.isNotEmpty))
                                    Align(
                                      alignment:
                                          AlignmentDirectional(-1.0, 0.0),
                                      child: Text(
                                        'This incident has been sent out to the nearby service providers.',
                                        style: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .override(
                                              font: GoogleFonts.lato(
                                                fontWeight: FontWeight.w600,
                                                fontStyle:
                                                    FlutterFlowTheme.of(context)
                                                        .bodyMedium
                                                        .fontStyle,
                                              ),
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .secondary,
                                              fontSize: 16.0,
                                              letterSpacing: 0.0,
                                              fontWeight: FontWeight.w600,
                                              fontStyle:
                                                  FlutterFlowTheme.of(context)
                                                      .bodyMedium
                                                      .fontStyle,
                                            ),
                                      ),
                                    ),
                                ],
                              ),
                            ),
                            if (stackRequestsRow?.paid == false)
                              Text(
                                'Click the button above to view and send this incident to nearby service providers. You will be charged a fee of R150.00 ',
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      font: GoogleFonts.lato(
                                        fontWeight: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .fontWeight,
                                        fontStyle: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .fontStyle,
                                      ),
                                      color: Color(0xFF737E83),
                                      letterSpacing: 0.0,
                                      fontWeight: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .fontWeight,
                                      fontStyle: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .fontStyle,
                                    ),
                              ),
                            if ((widget!.incident?.providersTendered != null &&
                                    (widget!.incident?.providersTendered)!
                                        .isNotEmpty) ==
                                true)
                              Expanded(
                                child: Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 24.0, 0.0, 0.0),
                                  child:
                                      FutureBuilder<List<ServiceprovidersRow>>(
                                    future: ServiceprovidersTable().queryRows(
                                      queryFn: (q) => q.inFilterOrNull(
                                        'id',
                                        widget!.incident?.providersTendered,
                                      ),
                                    ),
                                    builder: (context, snapshot) {
                                      // Customize what your widget looks like when it's loading.
                                      if (!snapshot.hasData) {
                                        return Center(
                                          child: SizedBox(
                                            width: 50.0,
                                            height: 50.0,
                                            child: CircularProgressIndicator(
                                              valueColor:
                                                  AlwaysStoppedAnimation<Color>(
                                                FlutterFlowTheme.of(context)
                                                    .primary,
                                              ),
                                            ),
                                          ),
                                        );
                                      }
                                      List<ServiceprovidersRow>
                                          gridViewServiceprovidersRowList =
                                          snapshot.data!;

                                      return GridView.builder(
                                        padding: EdgeInsets.zero,
                                        gridDelegate:
                                            SliverGridDelegateWithFixedCrossAxisCount(
                                          crossAxisCount: 5,
                                          crossAxisSpacing: 24.0,
                                          mainAxisSpacing: 24.0,
                                          childAspectRatio: 1.0,
                                        ),
                                        scrollDirection: Axis.vertical,
                                        itemCount:
                                            gridViewServiceprovidersRowList
                                                .length,
                                        itemBuilder: (context, gridViewIndex) {
                                          final gridViewServiceprovidersRow =
                                              gridViewServiceprovidersRowList[
                                                  gridViewIndex];
                                          return Column(
                                            mainAxisSize: MainAxisSize.max,
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            children: [
                                              Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        0.0, 12.0, 0.0, 0.0),
                                                child: ClipRRect(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          8.0),
                                                  child: OctoImage(
                                                    placeholderBuilder: (_) =>
                                                        SizedBox.expand(
                                                      child: Image(
                                                        image: BlurHashImage(
                                                            'LBS~q=-;?^-;?Hj[S3fQ?^j[DOay'),
                                                        fit: BoxFit.cover,
                                                      ),
                                                    ),
                                                    image: NetworkImage(
                                                      getCORSProxyUrl(
                                                        gridViewServiceprovidersRow
                                                            .logo!,
                                                      ),
                                                    ),
                                                    width: 44.0,
                                                    height: 44.0,
                                                    fit: BoxFit.cover,
                                                  ),
                                                ),
                                              ),
                                              Text(
                                                valueOrDefault<String>(
                                                  widget!.incident!.paid!
                                                      ? valueOrDefault<String>(
                                                          gridViewServiceprovidersRow
                                                              .companyName,
                                                          '-',
                                                        )
                                                      : '**********',
                                                  'N/A',
                                                ),
                                                textAlign: TextAlign.center,
                                                style: FlutterFlowTheme.of(
                                                        context)
                                                    .headlineSmall
                                                    .override(
                                                      font: GoogleFonts.lato(
                                                        fontWeight:
                                                            FontWeight.w600,
                                                        fontStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .headlineSmall
                                                                .fontStyle,
                                                      ),
                                                      color: Color(0xFF14181B),
                                                      fontSize: 14.0,
                                                      letterSpacing: 0.0,
                                                      fontWeight:
                                                          FontWeight.w600,
                                                      fontStyle:
                                                          FlutterFlowTheme.of(
                                                                  context)
                                                              .headlineSmall
                                                              .fontStyle,
                                                    ),
                                              ),
                                              Text(
                                                'Phone: ${valueOrDefault<String>(
                                                  widget!.incident!.paid!
                                                      ? valueOrDefault<String>(
                                                          gridViewServiceprovidersRow
                                                              .phone,
                                                          '-',
                                                        )
                                                      : '**********',
                                                  'N/A',
                                                )}',
                                                textAlign: TextAlign.center,
                                                style: FlutterFlowTheme.of(
                                                        context)
                                                    .bodySmall
                                                    .override(
                                                      font: GoogleFonts.lato(
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        fontStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .bodySmall
                                                                .fontStyle,
                                                      ),
                                                      color: Color(0xFF4B39EF),
                                                      fontSize: 12.0,
                                                      letterSpacing: 0.0,
                                                      fontWeight:
                                                          FontWeight.w500,
                                                      fontStyle:
                                                          FlutterFlowTheme.of(
                                                                  context)
                                                              .bodySmall
                                                              .fontStyle,
                                                    ),
                                              ),
                                              Text(
                                                'Distance from incident: ~${formatNumber(
                                                  functions.distance(
                                                      functions.stringtocoordinates(
                                                          widget!.incident!
                                                              .requesterLocation!),
                                                      functions.stringtocoordinates(
                                                          gridViewServiceprovidersRow
                                                              .coordinates!)),
                                                  formatType: FormatType.custom,
                                                  format: '0 km',
                                                  locale: '',
                                                )}',
                                                textAlign: TextAlign.center,
                                                style: FlutterFlowTheme.of(
                                                        context)
                                                    .labelMedium
                                                    .override(
                                                      font: GoogleFonts.lato(
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        fontStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .labelMedium
                                                                .fontStyle,
                                                      ),
                                                      color: Color(0xFF4B39EF),
                                                      fontSize: 12.0,
                                                      letterSpacing: 0.0,
                                                      fontWeight:
                                                          FontWeight.w500,
                                                      fontStyle:
                                                          FlutterFlowTheme.of(
                                                                  context)
                                                              .labelMedium
                                                              .fontStyle,
                                                    ),
                                              ),
                                              if (widget!.incident?.paid ??
                                                  true)
                                                Row(
                                                  mainAxisSize:
                                                      MainAxisSize.max,
                                                  children: [
                                                    Expanded(
                                                      child: FFButtonWidget(
                                                        onPressed: () async {
                                                          _model.getallreviews =
                                                              await ReviewsServiceprovidersTable()
                                                                  .queryRows(
                                                            queryFn: (q) =>
                                                                q.eqOrNull(
                                                              'service_provider',
                                                              gridViewServiceprovidersRow
                                                                  .id,
                                                            ),
                                                          );
                                                          await showModalBottomSheet(
                                                            isScrollControlled:
                                                                true,
                                                            backgroundColor:
                                                                Colors
                                                                    .transparent,
                                                            enableDrag: false,
                                                            context: context,
                                                            builder: (context) {
                                                              return WebViewAware(
                                                                child: Padding(
                                                                  padding: MediaQuery
                                                                      .viewInsetsOf(
                                                                          context),
                                                                  child:
                                                                      VendorProfileWidget(
                                                                    serviceprovider:
                                                                        gridViewServiceprovidersRow,
                                                                    reviews: _model
                                                                        .getallreviews,
                                                                  ),
                                                                ),
                                                              );
                                                            },
                                                          ).then((value) =>
                                                              safeSetState(
                                                                  () {}));

                                                          safeSetState(() {});
                                                        },
                                                        text: 'View',
                                                        options:
                                                            FFButtonOptions(
                                                          width:
                                                              double.infinity,
                                                          height: 44.0,
                                                          padding:
                                                              EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      16.0,
                                                                      0.0,
                                                                      16.0,
                                                                      0.0),
                                                          iconPadding:
                                                              EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      0.0,
                                                                      0.0,
                                                                      0.0,
                                                                      0.0),
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .primaryText,
                                                          textStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .titleSmall
                                                                  .override(
                                                                    font: GoogleFonts
                                                                        .lato(
                                                                      fontWeight: FlutterFlowTheme.of(
                                                                              context)
                                                                          .titleSmall
                                                                          .fontWeight,
                                                                      fontStyle: FlutterFlowTheme.of(
                                                                              context)
                                                                          .titleSmall
                                                                          .fontStyle,
                                                                    ),
                                                                    color: Colors
                                                                        .white,
                                                                    fontSize:
                                                                        14.0,
                                                                    letterSpacing:
                                                                        0.0,
                                                                    fontWeight: FlutterFlowTheme.of(
                                                                            context)
                                                                        .titleSmall
                                                                        .fontWeight,
                                                                    fontStyle: FlutterFlowTheme.of(
                                                                            context)
                                                                        .titleSmall
                                                                        .fontStyle,
                                                                  ),
                                                          elevation: 2.0,
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      8.0),
                                                        ),
                                                      ),
                                                    ),
                                                    Expanded(
                                                      child: FFButtonWidget(
                                                        onPressed: () async {
                                                          await RequestsTable()
                                                              .update(
                                                            data: {
                                                              'status':
                                                                  'Accepted by service provider',
                                                              'match_time':
                                                                  supaSerialize<
                                                                          DateTime>(
                                                                      getCurrentTimestamp),
                                                              'chosen_providers':
                                                                  gridViewServiceprovidersRow
                                                                      .companyName,
                                                              'chosenprovider':
                                                                  gridViewServiceprovidersRow
                                                                      .id,
                                                              'provider_number':
                                                                  gridViewServiceprovidersRow
                                                                      .phone,
                                                              'selectedprovider_image':
                                                                  gridViewServiceprovidersRow
                                                                      .logo,
                                                            },
                                                            matchingRows:
                                                                (rows) => rows
                                                                    .eqOrNull(
                                                              'id',
                                                              widget!
                                                                  .incident?.id,
                                                            ),
                                                          );
                                                          _model.findfleetcompanyC =
                                                              await TransportersTable()
                                                                  .queryRows(
                                                            queryFn: (q) =>
                                                                q.eqOrNull(
                                                              'id',
                                                              stackRequestsRow
                                                                  ?.fleetcompanyId,
                                                            ),
                                                          );
                                                          await Future.wait([
                                                            Future(() async {
                                                              _model.findspadmins =
                                                                  await UsersTable()
                                                                      .queryRows(
                                                                queryFn: (q) => q
                                                                    .eqOrNull(
                                                                      'service_provider',
                                                                      gridViewServiceprovidersRow
                                                                          .id,
                                                                    )
                                                                    .eqOrNull(
                                                                      'currentrole',
                                                                      'Service Provider',
                                                                    ),
                                                              );
                                                              _model.findspadminsFb =
                                                                  await queryUsersRecordOnce(
                                                                queryBuilder: (usersRecord) => usersRecord.whereIn(
                                                                    'uid',
                                                                    _model
                                                                        .findspadmins
                                                                        ?.map((e) =>
                                                                            e.uid)
                                                                        .withoutNulls
                                                                        .toList()),
                                                              );
                                                              await Future
                                                                  .wait([
                                                                Future(
                                                                    () async {
                                                                  triggerPushNotification(
                                                                    notificationTitle:
                                                                        'New Job (${stackRequestsRow?.serviceRequested})',
                                                                    notificationText:
                                                                        '${_model.findfleetcompanyC?.firstOrNull?.name} has selected you to assist their driver (${stackRequestsRow?.requesterName}) with ${stackRequestsRow?.serviceRequested} services at ${gridViewServiceprovidersRow.address}',
                                                                    notificationSound:
                                                                        'default',
                                                                    userRefs: _model
                                                                        .findspadminsFb!
                                                                        .map((e) =>
                                                                            e.reference)
                                                                        .toList(),
                                                                    initialPageName:
                                                                        'request_details',
                                                                    parameterData: {
                                                                      'role':
                                                                          'Service Provider',
                                                                      'requestid':
                                                                          stackRequestsRow
                                                                              ?.id,
                                                                      'completed':
                                                                          false,
                                                                    },
                                                                  );
                                                                }),
                                                                Future(
                                                                    () async {
                                                                  await NotificationsTable()
                                                                      .insert({
                                                                    'created_at':
                                                                        supaSerialize<DateTime>(
                                                                            getCurrentTimestamp),
                                                                    'title':
                                                                        'New Job (${stackRequestsRow?.serviceRequested})',
                                                                    'message':
                                                                        '${_model.findfleetcompanyC?.firstOrNull?.name} has selected you to assist their driver (${stackRequestsRow?.requesterName}) with ${stackRequestsRow?.serviceRequested} services at ${gridViewServiceprovidersRow.address}',
                                                                    'sent_by':
                                                                        currentUserUid,
                                                                    'sent_to': _model
                                                                        .findspadmins
                                                                        ?.map((e) =>
                                                                            e.uid)
                                                                        .withoutNulls
                                                                        .toList(),
                                                                    'category':
                                                                        'Incident',
                                                                  });
                                                                }),
                                                              ]);
                                                            }),
                                                            Future(() async {
                                                              _model.finddriverfb =
                                                                  await queryUsersRecordOnce(
                                                                queryBuilder:
                                                                    (usersRecord) =>
                                                                        usersRecord
                                                                            .where(
                                                                  'uid',
                                                                  isEqualTo:
                                                                      stackRequestsRow
                                                                          ?.requesterUid,
                                                                ),
                                                                singleRecord:
                                                                    true,
                                                              ).then((s) => s
                                                                      .firstOrNull);
                                                              await Future
                                                                  .wait([
                                                                Future(
                                                                    () async {
                                                                  triggerPushNotification(
                                                                    notificationTitle:
                                                                        'Service Provider Found 🛠️✅',
                                                                    notificationText:
                                                                        '${gridViewServiceprovidersRow.companyName} has been selected by your fleet manager to assist you with ${stackRequestsRow?.serviceRequested} services.',
                                                                    notificationSound:
                                                                        'default',
                                                                    userRefs: [
                                                                      _model
                                                                          .finddriverfb!
                                                                          .reference
                                                                    ],
                                                                    initialPageName:
                                                                        'request_details',
                                                                    parameterData: {
                                                                      'role':
                                                                          'Driver',
                                                                      'requestid':
                                                                          stackRequestsRow
                                                                              ?.id,
                                                                      'completed':
                                                                          false,
                                                                    },
                                                                  );
                                                                }),
                                                                Future(
                                                                    () async {
                                                                  await NotificationsTable()
                                                                      .insert({
                                                                    'created_at':
                                                                        supaSerialize<DateTime>(
                                                                            getCurrentTimestamp),
                                                                    'title':
                                                                        'Service Provider Found 🛠️✅',
                                                                    'message':
                                                                        '${gridViewServiceprovidersRow.companyName} has been selected by your fleet manager to assist you with ${stackRequestsRow?.serviceRequested} services.',
                                                                    'sent_by':
                                                                        currentUserUid,
                                                                    'sent_to': functions
                                                                        .stringtosinglevaluearray(
                                                                            stackRequestsRow!.requesterUid!),
                                                                    'category':
                                                                        'Incident',
                                                                  });
                                                                }),
                                                              ]);
                                                            }),
                                                          ]);
                                                          await ServiceProviderSelectedCall
                                                              .call(
                                                            spPhone: _model
                                                                .findspadmins
                                                                ?.firstOrNull
                                                                ?.phone,
                                                            driverPhone:
                                                                stackRequestsRow
                                                                    ?.requesterPhone,
                                                            spName:
                                                                gridViewServiceprovidersRow
                                                                    .companyName,
                                                            driverName:
                                                                stackRequestsRow
                                                                    ?.requesterName,
                                                            services:
                                                                stackRequestsRow
                                                                    ?.serviceRequested,
                                                            transporter: _model
                                                                .findfleetcompanyC
                                                                ?.firstOrNull
                                                                ?.name,
                                                            address:
                                                                stackRequestsRow
                                                                    ?.address,
                                                            incidentNumber:
                                                                stackRequestsRow
                                                                    ?.id
                                                                    ?.toString(),
                                                            vin: stackRequestsRow
                                                                ?.vehicle
                                                                ?.toString(),
                                                            transporterPhone: _model
                                                                .findfleetcompanyC
                                                                ?.firstOrNull
                                                                ?.phone,
                                                            details:
                                                                stackRequestsRow
                                                                    ?.requestDetails,
                                                          );

                                                          await showDialog(
                                                            context: context,
                                                            builder:
                                                                (alertDialogContext) {
                                                              return WebViewAware(
                                                                child:
                                                                    AlertDialog(
                                                                  title: Text(
                                                                      '${gridViewServiceprovidersRow.companyName} has been selected for this incident.'),
                                                                  content: Text(
                                                                      'All parties have been notified.'),
                                                                  actions: [
                                                                    TextButton(
                                                                      onPressed:
                                                                          () =>
                                                                              Navigator.pop(alertDialogContext),
                                                                      child: Text(
                                                                          'Ok'),
                                                                    ),
                                                                  ],
                                                                ),
                                                              );
                                                            },
                                                          );
                                                          await widget.refresh
                                                              ?.call();
                                                          Navigator.pop(
                                                              context);

                                                          safeSetState(() {});
                                                        },
                                                        text: 'Confirm',
                                                        options:
                                                            FFButtonOptions(
                                                          width:
                                                              double.infinity,
                                                          height: 44.0,
                                                          padding:
                                                              EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      16.0,
                                                                      0.0,
                                                                      16.0,
                                                                      0.0),
                                                          iconPadding:
                                                              EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      0.0,
                                                                      0.0,
                                                                      0.0,
                                                                      0.0),
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .primary,
                                                          textStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .titleSmall
                                                                  .override(
                                                                    font: GoogleFonts
                                                                        .lato(
                                                                      fontWeight: FlutterFlowTheme.of(
                                                                              context)
                                                                          .titleSmall
                                                                          .fontWeight,
                                                                      fontStyle: FlutterFlowTheme.of(
                                                                              context)
                                                                          .titleSmall
                                                                          .fontStyle,
                                                                    ),
                                                                    color: Colors
                                                                        .white,
                                                                    fontSize:
                                                                        14.0,
                                                                    letterSpacing:
                                                                        0.0,
                                                                    fontWeight: FlutterFlowTheme.of(
                                                                            context)
                                                                        .titleSmall
                                                                        .fontWeight,
                                                                    fontStyle: FlutterFlowTheme.of(
                                                                            context)
                                                                        .titleSmall
                                                                        .fontStyle,
                                                                  ),
                                                          elevation: 2.0,
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      8.0),
                                                        ),
                                                      ),
                                                    ),
                                                  ].divide(
                                                      SizedBox(width: 12.0)),
                                                ),
                                              if (stackRequestsRow?.paid ==
                                                  false)
                                                Container(
                                                  width: double.infinity,
                                                  height: 52.0,
                                                  decoration: BoxDecoration(
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .secondaryBackground,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            8.0),
                                                    border: Border.all(
                                                      color: FlutterFlowTheme
                                                              .of(context)
                                                          .primaryBackground,
                                                      width: 2.0,
                                                    ),
                                                  ),
                                                  child: Row(
                                                    mainAxisSize:
                                                        MainAxisSize.max,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    children: [
                                                      Icon(
                                                        Icons.lock,
                                                        color:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .primaryText,
                                                        size: 20.0,
                                                      ),
                                                      Padding(
                                                        padding:
                                                            EdgeInsetsDirectional
                                                                .fromSTEB(
                                                                    4.0,
                                                                    0.0,
                                                                    0.0,
                                                                    0.0),
                                                        child: Text(
                                                          'Pay to unlock',
                                                          style: FlutterFlowTheme
                                                                  .of(context)
                                                              .bodyMedium
                                                              .override(
                                                                font:
                                                                    GoogleFonts
                                                                        .lato(
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w600,
                                                                  fontStyle: FlutterFlowTheme.of(
                                                                          context)
                                                                      .bodyMedium
                                                                      .fontStyle,
                                                                ),
                                                                letterSpacing:
                                                                    0.0,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w600,
                                                                fontStyle: FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyMedium
                                                                    .fontStyle,
                                                              ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                            ],
                                          );
                                        },
                                      );
                                    },
                                  ),
                                ),
                              ),
                            if ((stackRequestsRow?.providersTendered != null &&
                                    (stackRequestsRow?.providersTendered)!
                                        .isNotEmpty) ==
                                false)
                              Expanded(
                                child: Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 24.0, 0.0, 0.0),
                                  child: Builder(
                                    builder: (context) {
                                      final availableproviders = containerServiceprovidersRowList
                                          .where((e) =>
                                              functions.distance(
                                                  functions.stringtocoordinates(
                                                      e.coordinates!),
                                                  functions.stringtocoordinates(
                                                      widget!.incident!
                                                          .requesterLocation!)) <
                                              800000)
                                          .toList()
                                          .sortedList(
                                              keyOf: (e) => functions.distance(
                                                  functions.stringtocoordinates(
                                                      e.coordinates!),
                                                  functions.stringtocoordinates(
                                                      widget!.incident!
                                                          .requesterLocation!)),
                                              desc: false)
                                          .toList();

                                      return GridView.builder(
                                        padding: EdgeInsets.zero,
                                        gridDelegate:
                                            SliverGridDelegateWithFixedCrossAxisCount(
                                          crossAxisCount: 5,
                                          crossAxisSpacing: 24.0,
                                          mainAxisSpacing: 24.0,
                                          childAspectRatio: 1.0,
                                        ),
                                        scrollDirection: Axis.vertical,
                                        itemCount: availableproviders.length,
                                        itemBuilder:
                                            (context, availableprovidersIndex) {
                                          final availableprovidersItem =
                                              availableproviders[
                                                  availableprovidersIndex];
                                          return Column(
                                            mainAxisSize: MainAxisSize.max,
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceEvenly,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(8.0),
                                                child: OctoImage(
                                                  placeholderBuilder: (_) =>
                                                      SizedBox.expand(
                                                    child: Image(
                                                      image: BlurHashImage(
                                                          'LBS~q=-;?^-;?Hj[S3fQ?^j[DOay'),
                                                      fit: BoxFit.cover,
                                                    ),
                                                  ),
                                                  image: NetworkImage(
                                                    getCORSProxyUrl(
                                                      stackRequestsRow!.paid!
                                                          ? availableprovidersItem
                                                              .logo!
                                                          : 'https://hkltjfqbbpmdboobsonx.supabase.co/storage/v1/object/public/files//Gova%20logo.png',
                                                    ),
                                                  ),
                                                  width: 44.0,
                                                  height: 44.0,
                                                  fit: BoxFit.cover,
                                                ),
                                              ),
                                              Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        0.0, 8.0, 0.0, 0.0),
                                                child: Text(
                                                  valueOrDefault<String>(
                                                    widget!.incident!.paid!
                                                        ? valueOrDefault<
                                                            String>(
                                                            availableprovidersItem
                                                                .companyName,
                                                            'N/A',
                                                          )
                                                        : '**********',
                                                    'N/A',
                                                  ),
                                                  maxLines: 1,
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .headlineSmall
                                                      .override(
                                                        font: GoogleFonts.lato(
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .headlineSmall
                                                                  .fontStyle,
                                                        ),
                                                        color:
                                                            Color(0xFF14181B),
                                                        fontSize: 14.0,
                                                        letterSpacing: 0.0,
                                                        fontWeight:
                                                            FontWeight.w600,
                                                        fontStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .headlineSmall
                                                                .fontStyle,
                                                      ),
                                                ),
                                              ),
                                              Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        0.0, 4.0, 0.0, 0.0),
                                                child: Text(
                                                  'Phone: ${valueOrDefault<String>(
                                                    widget!.incident!.paid!
                                                        ? valueOrDefault<
                                                            String>(
                                                            availableprovidersItem
                                                                .phone,
                                                            'N/A',
                                                          )
                                                        : '**********',
                                                    'N/A',
                                                  )}',
                                                  maxLines: 1,
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .bodySmall
                                                      .override(
                                                        font: GoogleFonts.lato(
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .bodySmall
                                                                  .fontStyle,
                                                        ),
                                                        color:
                                                            Color(0xFF4B39EF),
                                                        fontSize: 12.0,
                                                        letterSpacing: 0.0,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        fontStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .bodySmall
                                                                .fontStyle,
                                                      ),
                                                ),
                                              ),
                                              Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        0.0, 4.0, 0.0, 0.0),
                                                child: Text(
                                                  'Distance from incident: ~${formatNumber(
                                                    functions.distance(
                                                        functions.stringtocoordinates(
                                                            widget!.incident!
                                                                .requesterLocation!),
                                                        functions.stringtocoordinates(
                                                            availableprovidersItem
                                                                .coordinates!)),
                                                    formatType:
                                                        FormatType.custom,
                                                    format: '0',
                                                    locale: '',
                                                  )}km',
                                                  maxLines: 1,
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .labelMedium
                                                      .override(
                                                        font: GoogleFonts.lato(
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .labelMedium
                                                                  .fontStyle,
                                                        ),
                                                        color:
                                                            Color(0xFF4B39EF),
                                                        fontSize: 12.0,
                                                        letterSpacing: 0.0,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        fontStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .labelMedium
                                                                .fontStyle,
                                                      ),
                                                ),
                                              ),
                                              Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        0.0, 4.0, 0.0, 0.0),
                                                child: Text(
                                                  'Truck services: ${availableprovidersItem.truckCategories.isNotEmpty ? functions.arraytostring(availableprovidersItem.truckCategories.toList()) : 'None'}',
                                                  maxLines: 2,
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .labelMedium
                                                      .override(
                                                        font: GoogleFonts.lato(
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .labelMedium
                                                                  .fontStyle,
                                                        ),
                                                        color:
                                                            Color(0xFF57636C),
                                                        fontSize: 12.0,
                                                        letterSpacing: 0.0,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        fontStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .labelMedium
                                                                .fontStyle,
                                                      ),
                                                ),
                                              ),
                                              Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        0.0, 4.0, 0.0, 0.0),
                                                child: Text(
                                                  'Trailer services: ${availableprovidersItem.trailerCategories.isNotEmpty ? functions.arraytostring(availableprovidersItem.trailerCategories.toList()) : 'None'}',
                                                  maxLines: 2,
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .labelMedium
                                                      .override(
                                                        font: GoogleFonts.lato(
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .labelMedium
                                                                  .fontStyle,
                                                        ),
                                                        color:
                                                            Color(0xFF57636C),
                                                        fontSize: 12.0,
                                                        letterSpacing: 0.0,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        fontStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .labelMedium
                                                                .fontStyle,
                                                      ),
                                                ),
                                              ),
                                            ],
                                          );
                                        },
                                      );
                                    },
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ),
                      if (_model.cardpmt)
                        Align(
                          alignment: AlignmentDirectional(0.0, 0.0),
                          child: InkWell(
                            splashColor: Colors.transparent,
                            focusColor: Colors.transparent,
                            hoverColor: Colors.transparent,
                            highlightColor: Colors.transparent,
                            onTap: () async {
                              _model.cardpmt = false;
                              safeSetState(() {});
                            },
                            child: Container(
                              width: double.infinity,
                              height: double.infinity,
                              decoration: BoxDecoration(
                                color: Color(0xC714181B),
                              ),
                            ),
                          ).animateOnActionTrigger(
                            animationsMap[
                                'containerOnActionTriggerAnimation1']!,
                          ),
                        ),
                      if (_model.cardpmt)
                        Align(
                          alignment: AlignmentDirectional(1.0, 0.0),
                          child: Container(
                            width: 640.0,
                            height: double.infinity,
                            decoration: BoxDecoration(
                              color: FlutterFlowTheme.of(context)
                                  .secondaryBackground,
                              borderRadius: BorderRadius.only(
                                bottomLeft: Radius.circular(0.0),
                                bottomRight: Radius.circular(16.0),
                                topLeft: Radius.circular(0.0),
                                topRight: Radius.circular(16.0),
                              ),
                            ),
                            child: Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 16.0, 0.0, 0.0),
                              child: Column(
                                mainAxisSize: MainAxisSize.max,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisSize: MainAxisSize.max,
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            16.0, 0.0, 0.0, 0.0),
                                        child: Text(
                                          'Secure Payment',
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                font: GoogleFonts.lato(
                                                  fontWeight: FontWeight.w600,
                                                  fontStyle:
                                                      FlutterFlowTheme.of(
                                                              context)
                                                          .bodyMedium
                                                          .fontStyle,
                                                ),
                                                fontSize: 24.0,
                                                letterSpacing: 0.0,
                                                fontWeight: FontWeight.w600,
                                                fontStyle:
                                                    FlutterFlowTheme.of(context)
                                                        .bodyMedium
                                                        .fontStyle,
                                              ),
                                        ),
                                      ),
                                      Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            0.0, 0.0, 16.0, 0.0),
                                        child: FFButtonWidget(
                                          onPressed: () async {
                                            _model.cardpmt = false;
                                            safeSetState(() {});
                                          },
                                          text: 'Close',
                                          options: FFButtonOptions(
                                            height: 40.0,
                                            padding:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    16.0, 0.0, 16.0, 0.0),
                                            iconPadding:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    0.0, 0.0, 0.0, 0.0),
                                            color: FlutterFlowTheme.of(context)
                                                .secondaryBackground,
                                            textStyle:
                                                FlutterFlowTheme.of(context)
                                                    .titleSmall
                                                    .override(
                                                      font: GoogleFonts.lato(
                                                        fontWeight:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .titleSmall
                                                                .fontWeight,
                                                        fontStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .titleSmall
                                                                .fontStyle,
                                                      ),
                                                      color: Color(0xFFFF004D),
                                                      letterSpacing: 0.0,
                                                      fontWeight:
                                                          FlutterFlowTheme.of(
                                                                  context)
                                                              .titleSmall
                                                              .fontWeight,
                                                      fontStyle:
                                                          FlutterFlowTheme.of(
                                                                  context)
                                                              .titleSmall
                                                              .fontStyle,
                                                    ),
                                            elevation: 0.0,
                                            borderRadius:
                                                BorderRadius.circular(8.0),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        16.0, 16.0, 16.0, 0.0),
                                    child: Text(
                                      'You will be charged a R150.00 admin fee to complete this request and match with your selected service provider.',
                                      textAlign: TextAlign.start,
                                      style: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .override(
                                            font: GoogleFonts.lato(
                                              fontWeight: FontWeight.normal,
                                              fontStyle:
                                                  FlutterFlowTheme.of(context)
                                                      .bodyMedium
                                                      .fontStyle,
                                            ),
                                            fontSize: 16.0,
                                            letterSpacing: 0.0,
                                            fontWeight: FontWeight.normal,
                                            fontStyle:
                                                FlutterFlowTheme.of(context)
                                                    .bodyMedium
                                                    .fontStyle,
                                          ),
                                    ),
                                  ),
                                  Expanded(
                                    child: Padding(
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          0.0, 24.0, 0.0, 0.0),
                                      child: FlutterFlowWebView(
                                        content: _model.link!,
                                        bypass: false,
                                        height: 400.0,
                                        verticalScroll: false,
                                        horizontalScroll: false,
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        16.0, 16.0, 16.0, 0.0),
                                    child: Text(
                                      'Make sure to click \"Pay\" on the paygate before clicking the finish button',
                                      textAlign: TextAlign.center,
                                      style: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .override(
                                            font: GoogleFonts.lato(
                                              fontWeight: FontWeight.w600,
                                              fontStyle:
                                                  FlutterFlowTheme.of(context)
                                                      .bodyMedium
                                                      .fontStyle,
                                            ),
                                            fontSize: 14.0,
                                            letterSpacing: 0.0,
                                            fontWeight: FontWeight.w600,
                                            fontStyle:
                                                FlutterFlowTheme.of(context)
                                                    .bodyMedium
                                                    .fontStyle,
                                          ),
                                    ),
                                  ),
                                  Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        16.0, 16.0, 16.0, 0.0),
                                    child: FFButtonWidget(
                                      onPressed: () async {
                                        _model.verifypayment =
                                            await VerifyCall.call(
                                          transactionRef: _model.ref,
                                        );

                                        if (VerifyCall.status(
                                              (_model.verifypayment?.jsonBody ??
                                                  ''),
                                            ) ==
                                            'success') {
                                          await TransportersTable().update(
                                            data: {
                                              'card_auth': VerifyCall.authcode(
                                                (_model.verifypayment
                                                        ?.jsonBody ??
                                                    ''),
                                              ),
                                            },
                                            matchingRows: (rows) =>
                                                rows.eqOrNull(
                                              'id',
                                              widget!.incident?.fleetcompanyId,
                                            ),
                                          );
                                          _model.findallserviceproviders =
                                              await ServiceprovidersTable()
                                                  .queryRows(
                                            queryFn: (q) => q.or(
                                                "truck_categories.cs.{${stackRequestsRow?.serviceRequested}}, trailer_categories.cs.{${stackRequestsRow?.serviceRequested}}"),
                                          );
                                          if (_model.findallserviceproviders!
                                              .where((e) =>
                                                  functions.distance(
                                                      functions.stringtocoordinates(
                                                          stackRequestsRow!
                                                              .requesterLocation!),
                                                      functions
                                                          .stringtocoordinates(
                                                              e.coordinates!)) <
                                                  80000)
                                              .toList()
                                              .isNotEmpty) {
                                            await Future.wait([
                                              Future(() async {
                                                _model.findsuperadminsnearby =
                                                    await UsersTable()
                                                        .queryRows(
                                                  queryFn: (q) => q
                                                      .eqOrNull(
                                                        'currentrole',
                                                        'Service Provider',
                                                      )
                                                      .inFilterOrNull(
                                                        'service_provider',
                                                        _model
                                                            .findallserviceproviders
                                                            ?.where((e) =>
                                                                functions.distance(
                                                                    functions.stringtocoordinates(
                                                                        stackRequestsRow!
                                                                            .requesterLocation!),
                                                                    functions
                                                                        .stringtocoordinates(
                                                                            e.coordinates!)) <
                                                                80000)
                                                            .toList()
                                                            ?.map((e) => e.id)
                                                            .toList(),
                                                      ),
                                                );
                                                _model.findsuperadminsFb =
                                                    await queryUsersRecordOnce(
                                                  queryBuilder: (usersRecord) =>
                                                      usersRecord.whereIn(
                                                          'uid',
                                                          _model
                                                              .findsuperadminsnearby
                                                              ?.map(
                                                                  (e) => e.uid)
                                                              .withoutNulls
                                                              .toList()),
                                                );
                                                triggerPushNotification(
                                                  notificationTitle:
                                                      'New incident nearby!',
                                                  notificationText:
                                                      '${stackRequestsRow?.serviceRequested} services have been requested by ${stackRequestsRow?.fleetcompanyName} within 100km of your main location.',
                                                  notificationImageUrl:
                                                      stackRequestsRow
                                                          ?.images?.firstOrNull,
                                                  notificationSound: 'default',
                                                  userRefs: _model
                                                      .findsuperadminsFb!
                                                      .map((e) => e.reference)
                                                      .toList(),
                                                  initialPageName: 'dashboard',
                                                  parameterData: {},
                                                );
                                              }),
                                              Future(() async {
                                                _model.finddriver =
                                                    await queryUsersRecordOnce(
                                                  queryBuilder: (usersRecord) =>
                                                      usersRecord.where(
                                                    'uid',
                                                    isEqualTo: stackRequestsRow
                                                        ?.requesterUid,
                                                  ),
                                                  singleRecord: true,
                                                ).then((s) => s.firstOrNull);
                                                triggerPushNotification(
                                                  notificationTitle:
                                                      'Incident Update',
                                                  notificationText:
                                                      'Your fleet manager has sent your incident request to service providers nearby. You will be notified when a service provider is selected and a technician is assigned.',
                                                  notificationSound: 'default',
                                                  userRefs: [
                                                    _model.finddriver!.reference
                                                  ],
                                                  initialPageName:
                                                      'request_details',
                                                  parameterData: {
                                                    'role': 'Driver',
                                                    'requestid':
                                                        stackRequestsRow?.id,
                                                    'completed': false,
                                                  },
                                                );
                                              }),
                                            ]);
                                            await RequestsTable().update(
                                              data: {
                                                'status':
                                                    'Sent to service providers',
                                                'provider_sentto': _model
                                                    .findallserviceproviders
                                                    ?.where((e) =>
                                                        functions.distance(
                                                            functions.stringtocoordinates(
                                                                stackRequestsRow!
                                                                    .requesterLocation!),
                                                            functions
                                                                .stringtocoordinates(
                                                                    e.coordinates!)) <
                                                        80000)
                                                    .toList()
                                                    ?.map((e) => e.id)
                                                    .toList(),
                                                'bidsopen': true,
                                                'paid': true,
                                              },
                                              matchingRows: (rows) =>
                                                  rows.eqOrNull(
                                                'id',
                                                stackRequestsRow?.id,
                                              ),
                                            );
                                            safeSetState(() => _model
                                                .requestCompleter2 = null);
                                            await showDialog(
                                              context: context,
                                              builder: (alertDialogContext) {
                                                return WebViewAware(
                                                  child: AlertDialog(
                                                    title: Text(
                                                        'Thank you for your payment  ✅'),
                                                    content: Text(
                                                        'Thank you for your payment. Your job has been shared with local service providers who will now place their bids.'),
                                                    actions: [
                                                      TextButton(
                                                        onPressed: () =>
                                                            Navigator.pop(
                                                                alertDialogContext),
                                                        child: Text('Ok'),
                                                      ),
                                                    ],
                                                  ),
                                                );
                                              },
                                            );
                                          } else {
                                            await showDialog(
                                              context: context,
                                              builder: (alertDialogContext) {
                                                return WebViewAware(
                                                  child: AlertDialog(
                                                    title: Text(
                                                        'There are no service providers in the area'),
                                                    actions: [
                                                      TextButton(
                                                        onPressed: () =>
                                                            Navigator.pop(
                                                                alertDialogContext),
                                                        child: Text('Ok'),
                                                      ),
                                                    ],
                                                  ),
                                                );
                                              },
                                            );
                                          }

                                          _model.cardpmt = false;
                                          safeSetState(() {});
                                        } else {
                                          await showDialog(
                                            context: context,
                                            builder: (alertDialogContext) {
                                              return WebViewAware(
                                                child: AlertDialog(
                                                  title:
                                                      Text('Payment Failed.'),
                                                  content: Text(
                                                      'Please try again. Make sure to click \"Pay\" on the paygate before clicking the finish button'),
                                                  actions: [
                                                    TextButton(
                                                      onPressed: () =>
                                                          Navigator.pop(
                                                              alertDialogContext),
                                                      child: Text('Ok'),
                                                    ),
                                                  ],
                                                ),
                                              );
                                            },
                                          );
                                        }

                                        safeSetState(() {});
                                      },
                                      text: 'Finish',
                                      options: FFButtonOptions(
                                        width: double.infinity,
                                        height: 56.0,
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            0.0, 0.0, 0.0, 0.0),
                                        iconPadding:
                                            EdgeInsetsDirectional.fromSTEB(
                                                0.0, 0.0, 0.0, 0.0),
                                        color: FlutterFlowTheme.of(context)
                                            .primary,
                                        textStyle: FlutterFlowTheme.of(context)
                                            .titleSmall
                                            .override(
                                              font: GoogleFonts.lato(
                                                fontWeight: FontWeight.w600,
                                                fontStyle:
                                                    FlutterFlowTheme.of(context)
                                                        .titleSmall
                                                        .fontStyle,
                                              ),
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .secondaryBackground,
                                              fontSize: 14.0,
                                              letterSpacing: 0.0,
                                              fontWeight: FontWeight.w600,
                                              fontStyle:
                                                  FlutterFlowTheme.of(context)
                                                      .titleSmall
                                                      .fontStyle,
                                            ),
                                        elevation: 2.0,
                                        borderSide: BorderSide(
                                          color: Colors.transparent,
                                          width: 1.0,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        16.0, 16.0, 16.0, 0.0),
                                    child: FFButtonWidget(
                                      onPressed: () async {
                                        _model.cardpmt = false;
                                        safeSetState(() {});
                                      },
                                      text: 'Cancel',
                                      options: FFButtonOptions(
                                        width: double.infinity,
                                        height: 52.0,
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            0.0, 0.0, 0.0, 0.0),
                                        iconPadding:
                                            EdgeInsetsDirectional.fromSTEB(
                                                0.0, 0.0, 0.0, 0.0),
                                        color: FlutterFlowTheme.of(context)
                                            .secondaryBackground,
                                        textStyle: FlutterFlowTheme.of(context)
                                            .titleSmall
                                            .override(
                                              font: GoogleFonts.lato(
                                                fontWeight: FontWeight.w500,
                                                fontStyle:
                                                    FlutterFlowTheme.of(context)
                                                        .titleSmall
                                                        .fontStyle,
                                              ),
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .secondaryText,
                                              fontSize: 14.0,
                                              letterSpacing: 0.0,
                                              fontWeight: FontWeight.w500,
                                              fontStyle:
                                                  FlutterFlowTheme.of(context)
                                                      .titleSmall
                                                      .fontStyle,
                                            ),
                                        elevation: 0.0,
                                        borderSide: BorderSide(
                                          color: Colors.transparent,
                                          width: 1.0,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ).animateOnActionTrigger(
                            animationsMap[
                                'containerOnActionTriggerAnimation2']!,
                          ),
                        ),
                    ],
                  );
                },
              ),
            );
          },
        ),
      ),
    );
  }
}

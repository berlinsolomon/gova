import '/backend/supabase/supabase.dart';
import '/components/emptyserviceproviders/emptyserviceproviders_widget.dart';
import '/flutter_flow/flutter_flow_expanded_image_view.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import 'editincident_widget.dart' show EditincidentWidget;
import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_blurhash/flutter_blurhash.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:octo_image/octo_image.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';

class EditincidentModel extends FlutterFlowModel<EditincidentWidget> {
  ///  Local state fields for this component.

  bool changesmade = false;

  List<String> allimages = [];
  void addToAllimages(String item) => allimages.add(item);
  void removeFromAllimages(String item) => allimages.remove(item);
  void removeAtIndexFromAllimages(int index) => allimages.removeAt(index);
  void insertAtIndexInAllimages(int index, String item) =>
      allimages.insert(index, item);
  void updateAllimagesAtIndex(int index, Function(String) updateFn) =>
      allimages[index] = updateFn(allimages[index]);

  ///  State fields for stateful widgets in this component.

  // Stores action output result for [Backend Call - Update Row(s)] action in Button widget.
  List<RequestsRow>? updaterequest;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode1;
  TextEditingController? textController1;
  String? Function(BuildContext, String?)? textController1Validator;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode2;
  TextEditingController? textController2;
  String? Function(BuildContext, String?)? textController2Validator;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode3;
  TextEditingController? textController3;
  String? Function(BuildContext, String?)? textController3Validator;
  bool isDataUploading_addimages = false;
  List<FFUploadedFile> uploadedLocalFiles_addimages = [];
  List<String> uploadedFileUrls_addimages = [];

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    textFieldFocusNode1?.dispose();
    textController1?.dispose();

    textFieldFocusNode2?.dispose();
    textController2?.dispose();

    textFieldFocusNode3?.dispose();
    textController3?.dispose();
  }
}

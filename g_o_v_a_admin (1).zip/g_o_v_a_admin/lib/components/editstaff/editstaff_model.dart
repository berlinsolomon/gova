import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import 'editstaff_widget.dart' show EditstaffWidget;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_blurhash/flutter_blurhash.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:octo_image/octo_image.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';

class EditstaffModel extends FlutterFlowModel<EditstaffWidget> {
  ///  Local state fields for this component.

  List<String> license = [];
  void addToLicense(String item) => license.add(item);
  void removeFromLicense(String item) => license.remove(item);
  void removeAtIndexFromLicense(int index) => license.removeAt(index);
  void insertAtIndexInLicense(int index, String item) =>
      license.insert(index, item);
  void updateLicenseAtIndex(int index, Function(String) updateFn) =>
      license[index] = updateFn(license[index]);

  String? profile;

  ///  State fields for stateful widgets in this component.

  bool isDataUploading_editstaffimage = false;
  FFUploadedFile uploadedLocalFile_editstaffimage =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  String uploadedFileUrl_editstaffimage = '';

  // State field(s) for firstname widget.
  FocusNode? firstnameFocusNode;
  TextEditingController? firstnameTextController;
  String? Function(BuildContext, String?)? firstnameTextControllerValidator;
  // State field(s) for lastname widget.
  FocusNode? lastnameFocusNode;
  TextEditingController? lastnameTextController;
  String? Function(BuildContext, String?)? lastnameTextControllerValidator;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode1;
  TextEditingController? textController3;
  String? Function(BuildContext, String?)? textController3Validator;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode2;
  TextEditingController? textController4;
  String? Function(BuildContext, String?)? textController4Validator;
  // State field(s) for phone widget.
  FocusNode? phoneFocusNode;
  TextEditingController? phoneTextController;
  String? Function(BuildContext, String?)? phoneTextControllerValidator;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<ServiceprovidersRow>? findcompany;
  // Stores action output result for [Backend Call - Update Row(s)] action in Button widget.
  List<ServiceproviderStaffRow>? newstaffmember;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    firstnameFocusNode?.dispose();
    firstnameTextController?.dispose();

    lastnameFocusNode?.dispose();
    lastnameTextController?.dispose();

    textFieldFocusNode1?.dispose();
    textController3?.dispose();

    textFieldFocusNode2?.dispose();
    textController4?.dispose();

    phoneFocusNode?.dispose();
    phoneTextController?.dispose();
  }
}

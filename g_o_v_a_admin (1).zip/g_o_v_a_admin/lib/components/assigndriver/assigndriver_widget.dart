import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'assigndriver_model.dart';
export 'assigndriver_model.dart';

class AssigndriverWidget extends StatefulWidget {
  const AssigndriverWidget({
    super.key,
    this.drivers,
    required this.current,
    required this.assign,
  });

  final List<TransporterStaffRow>? drivers;
  final int? current;
  final Future Function(int driver)? assign;

  @override
  State<AssigndriverWidget> createState() => _AssigndriverWidgetState();
}

class _AssigndriverWidgetState extends State<AssigndriverWidget> {
  late AssigndriverModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => AssigndriverModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FlutterFlowDropDown<int>(
      controller: _model.dropDownValueController ??= FormFieldController<int>(
        _model.dropDownValue ??= widget!.current,
      ),
      options: List<int>.from(widget!.drivers!.map((e) => e.id).toList()),
      optionLabels:
          widget!.drivers!.map((e) => e.fullname).withoutNulls.toList(),
      onChanged: (val) async {
        safeSetState(() => _model.dropDownValue = val);
        await widget.assign?.call(
          _model.dropDownValue!,
        );
      },
      width: 200.0,
      height: 44.0,
      textStyle: FlutterFlowTheme.of(context).bodyMedium.override(
            font: GoogleFonts.lato(
              fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
              fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
            ),
            letterSpacing: 0.0,
            fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
            fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
          ),
      hintText: 'Select...',
      icon: Icon(
        Icons.keyboard_arrow_down_rounded,
        color: FlutterFlowTheme.of(context).secondaryText,
        size: 24.0,
      ),
      fillColor: FlutterFlowTheme.of(context).secondaryBackground,
      elevation: 2.0,
      borderColor: FlutterFlowTheme.of(context).alternate,
      borderWidth: 1.0,
      borderRadius: 8.0,
      margin: EdgeInsetsDirectional.fromSTEB(12.0, 0.0, 12.0, 0.0),
      hidesUnderline: true,
      isOverButton: false,
      isSearchable: false,
      isMultiSelect: false,
    );
  }
}

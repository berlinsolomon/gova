import 'package:flutter/material.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/api_requests/api_manager.dart';
import 'backend/supabase/supabase.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    prefs = await SharedPreferences.getInstance();
    _safeInit(() {
      _lastincidentnearme = prefs.containsKey('ff_lastincidentnearme')
          ? DateTime.fromMillisecondsSinceEpoch(
              prefs.getInt('ff_lastincidentnearme')!)
          : _lastincidentnearme;
    });
    _safeInit(() {
      _role = prefs.getString('ff_role') ?? _role;
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late SharedPreferences prefs;

  String _fmpage = 'Dashboard';
  String get fmpage => _fmpage;
  set fmpage(String value) {
    _fmpage = value;
  }

  String _sppage = 'Dashboard';
  String get sppage => _sppage;
  set sppage(String value) {
    _sppage = value;
  }

  DateTime? _lastincidentnearme =
      DateTime.fromMillisecondsSinceEpoch(1751357880000);
  DateTime? get lastincidentnearme => _lastincidentnearme;
  set lastincidentnearme(DateTime? value) {
    _lastincidentnearme = value;
    value != null
        ? prefs.setInt('ff_lastincidentnearme', value.millisecondsSinceEpoch)
        : prefs.remove('ff_lastincidentnearme');
  }

  String _role = '';
  String get role => _role;
  set role(String value) {
    _role = value;
    prefs.setString('ff_role', value);
  }
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}

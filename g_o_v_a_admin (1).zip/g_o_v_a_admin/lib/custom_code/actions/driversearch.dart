// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

// use the searchterm argument to search the first_name, last_name, fullname, national_id and phone fields of the drivers rows. The search term doesn't need to be an exact match and the searchterm can contain one or multiple of the fields in it
Future<List<TransporterStaffRow>> driversearch(
  List<TransporterStaffRow> drivers,
  String searchterm,
) async {
  if (searchterm.isEmpty) {
    return drivers;
  }

  final String normalizedSearchTerm = searchterm.toLowerCase().trim();

  return drivers.where((driver) {
    // Get field values and normalize them for comparison
    final String firstName = (driver.firstName ?? '').toLowerCase();
    final String lastName = (driver.lastName ?? '').toLowerCase();
    final String fullName = (driver.fullname ?? '').toLowerCase();
    final String nationalId = (driver.nationalId ?? '').toLowerCase();
    final String phone = (driver.phone ?? '').toLowerCase();

    // Create a combined string of all searchable fields
    final String combinedFields =
        '$firstName $lastName $fullName $nationalId $phone';

    // Split search term into individual words for flexible matching
    final List<String> searchWords = normalizedSearchTerm
        .split(' ')
        .where((word) => word.isNotEmpty)
        .toList();

    // Check if any individual field contains the full search term
    if (firstName.contains(normalizedSearchTerm) ||
        lastName.contains(normalizedSearchTerm) ||
        fullName.contains(normalizedSearchTerm) ||
        nationalId.contains(normalizedSearchTerm) ||
        phone.contains(normalizedSearchTerm)) {
      return true;
    }

    // Check if all search words are found in the combined fields
    // This allows for partial matches across multiple fields
    if (searchWords.every((word) => combinedFields.contains(word))) {
      return true;
    }

    return false;
  }).toList();
}

// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:geocoding/geocoding.dart';
import '/flutter_flow/lat_lng.dart';

Future<String> getAddressFromLatLng(LatLng latLng) async {
  try {
    // Perform reverse-geocoding
    final placemarks = await placemarkFromCoordinates(
      latLng.latitude,
      latLng.longitude,
    );
    if (placemarks.isEmpty) {
      return '';
    }

    final p = placemarks.first;
    // Build a single comma-separated address line
    final addressParts = [
      p.street,
      p.subLocality,
      p.locality,
      p.administrativeArea,
      p.postalCode,
      p.country,
    ];

    final address = addressParts
        .where((part) => part != null && part.isNotEmpty)
        .join(', ');
    return address;
  } catch (e) {
    // Optionally log or handle errors
    print('🗺 Reverse geocoding failed: $e');
    return '';
  }
}

// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

// use the searchterm argument to search the make, model, year, vin_number and number_plate fields of the vehicles rows. The search term doesn't need to be an exact match and the searchterm can contain one or multiple of the fields in it
Future<List<FleetRow>> search(
  List<FleetRow> vehicles,
  String searchterm,
) async {
  if (searchterm.isEmpty) {
    return vehicles;
  }

  final String normalizedSearchTerm = searchterm.toLowerCase().trim();

  return vehicles.where((vehicle) {
    // Get field values and normalize them for comparison
    final String make = (vehicle.make ?? '').toLowerCase();
    final String model = (vehicle.model ?? '').toLowerCase();
    final String year = (vehicle.year?.toString() ?? '').toLowerCase();
    final String vinNumber = (vehicle.vinNumber ?? '').toLowerCase();
    final String numberPlate = (vehicle.numberPlate ?? '').toLowerCase();

    // Check if search term matches any individual field
    if (make.contains(normalizedSearchTerm) ||
        model.contains(normalizedSearchTerm) ||
        year.contains(normalizedSearchTerm) ||
        vinNumber.contains(normalizedSearchTerm) ||
        numberPlate.contains(normalizedSearchTerm)) {
      return true;
    }

    // Check if search term contains multiple words that match across fields
    final List<String> searchWords = normalizedSearchTerm
        .split(' ')
        .where((word) => word.isNotEmpty)
        .toList();

    if (searchWords.length > 1) {
      final String combinedFields =
          '$make $model $year $vinNumber $numberPlate';

      // Check if all search words are found in the combined fields
      return searchWords.every((word) => combinedFields.contains(word));
    }

    return false;
  }).toList();
}

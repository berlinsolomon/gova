// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

// // // use the searchterm argument to search the first_name, last_name, national_id and phone fields of the technicians rows. The search term doesn't need to be an exact match and the searchterm can contain one or multiple of the fields in it
Future<List<ServiceproviderStaffRow>> techniciansearch(
  List<ServiceproviderStaffRow> technicians,
  String searchterm,
) async {
  if (searchterm.isEmpty) {
    return technicians;
  }

  final searchTermLower = searchterm.toLowerCase().trim();
  final searchWords =
      searchTermLower.split(' ').where((word) => word.isNotEmpty).toList();

  return technicians.where((technician) {
    final firstName = technician.firstName?.toLowerCase() ?? '';
    final lastName = technician.lastName?.toLowerCase() ?? '';
    final nationalId = technician.nationalId?.toLowerCase() ?? '';
    final phone = technician.phone?.toLowerCase() ?? '';

    final combinedFields = '$firstName $lastName $nationalId $phone';

    // Check if all search words are found in any of the fields
    return searchWords.every((word) =>
        firstName.contains(word) ||
        lastName.contains(word) ||
        nationalId.contains(word) ||
        phone.contains(word) ||
        combinedFields.contains(word));
  }).toList();
}

import '/auth/firebase_auth/auth_util.dart';
import '/backend/supabase/supabase.dart';
import '/components/addstaff/addstaff_widget.dart';
import '/components/editstaff/editstaff_widget.dart';
import '/components/emptyactiveincidents/emptyactiveincidents_widget.dart';
import '/components/emptydrivers/emptydrivers_widget.dart';
import '/components/emptynotifs/emptynotifs_widget.dart';
import '/components/emptyreviews2/emptyreviews2_widget.dart';
import '/components/invoicestatus/invoicestatus_widget.dart';
import '/components/newincident_provider/newincident_provider_widget.dart';
import '/components/respond_sp/respond_sp_widget.dart';
import '/components/technicianstatus/technicianstatus_widget.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_choice_chips.dart';
import '/flutter_flow/flutter_flow_expanded_image_view.dart';
import '/flutter_flow/flutter_flow_google_map.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_place_picker.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/flutter_flow/instant_timer.dart';
import '/flutter_flow/place.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:io';
import 'dart:math';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'dart:async';
import 'sp_dash_widget.dart' show SpDashWidget;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_blurhash/flutter_blurhash.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:octo_image/octo_image.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';

class SpDashModel extends FlutterFlowModel<SpDashWidget> {
  ///  Local state fields for this page.

  DateTime? lastupdated;

  List<TransporterStaffRow> drivers = [];
  void addToDrivers(TransporterStaffRow item) => drivers.add(item);
  void removeFromDrivers(TransporterStaffRow item) => drivers.remove(item);
  void removeAtIndexFromDrivers(int index) => drivers.removeAt(index);
  void insertAtIndexInDrivers(int index, TransporterStaffRow item) =>
      drivers.insert(index, item);
  void updateDriversAtIndex(
          int index, Function(TransporterStaffRow) updateFn) =>
      drivers[index] = updateFn(drivers[index]);

  List<FleetRow> vehicles = [];
  void addToVehicles(FleetRow item) => vehicles.add(item);
  void removeFromVehicles(FleetRow item) => vehicles.remove(item);
  void removeAtIndexFromVehicles(int index) => vehicles.removeAt(index);
  void insertAtIndexInVehicles(int index, FleetRow item) =>
      vehicles.insert(index, item);
  void updateVehiclesAtIndex(int index, Function(FleetRow) updateFn) =>
      vehicles[index] = updateFn(vehicles[index]);

  List<ServiceproviderStaffRow> staff = [];
  void addToStaff(ServiceproviderStaffRow item) => staff.add(item);
  void removeFromStaff(ServiceproviderStaffRow item) => staff.remove(item);
  void removeAtIndexFromStaff(int index) => staff.removeAt(index);
  void insertAtIndexInStaff(int index, ServiceproviderStaffRow item) =>
      staff.insert(index, item);
  void updateStaffAtIndex(
          int index, Function(ServiceproviderStaffRow) updateFn) =>
      staff[index] = updateFn(staff[index]);

  List<ServiceproviderStaffRow> staffsearch = [];
  void addToStaffsearch(ServiceproviderStaffRow item) => staffsearch.add(item);
  void removeFromStaffsearch(ServiceproviderStaffRow item) =>
      staffsearch.remove(item);
  void removeAtIndexFromStaffsearch(int index) => staffsearch.removeAt(index);
  void insertAtIndexInStaffsearch(int index, ServiceproviderStaffRow item) =>
      staffsearch.insert(index, item);
  void updateStaffsearchAtIndex(
          int index, Function(ServiceproviderStaffRow) updateFn) =>
      staffsearch[index] = updateFn(staffsearch[index]);

  String? profilepic;

  String? logo;

  bool changesmadeprofile = false;

  bool changesmadecompany = false;

  ///  State fields for stateful widgets in this page.

  // Stores action output result for [Backend Call - Query Rows] action in sp_dash widget.
  List<UsersRow>? finduser;
  // Stores action output result for [Backend Call - Query Rows] action in sp_dash widget.
  List<ServiceprovidersRow>? findserviceprovider;
  InstantTimer? instantTimer;
  // Stores action output result for [Backend Call - Query Rows] action in sp_dash widget.
  List<RequestsRow>? findunassignedincidents;
  Completer<List<RequestsRow>>? requestCompleter3;
  Completer<List<RequestsRow>>? requestCompleter7;
  Completer<List<RequestsRow>>? requestCompleter8;
  Completer<List<RequestsRow>>? requestCompleter11;
  Completer<List<RequestsRow>>? requestCompleter1;
  Completer<List<RequestsRow>>? requestCompleter4;
  // Stores action output result for [Backend Call - Query Rows] action in sp_dash widget.
  List<RequestsRow>? findincidentsSenttous;
  // Stores action output result for [Backend Call - Update Row(s)] action in sp_dash widget.
  List<RequestsRow>? updateincident;
  // Stores action output result for [Backend Call - Query Rows] action in contentView_1 widget.
  List<ServiceproviderStaffRow>? getstaff;
  // State field(s) for GoogleMap widget.
  LatLng? googleMapsCenter;
  final googleMapsController = Completer<GoogleMapController>();
  // State field(s) for statuscc widget.
  FormFieldController<List<String>>? statusccValueController;
  String? get statusccValue => statusccValueController?.value?.firstOrNull;
  set statusccValue(String? val) =>
      statusccValueController?.value = val != null ? [val] : [];
  // State field(s) for staffsearch widget.
  FocusNode? staffsearchFocusNode;
  TextEditingController? staffsearchTextController;
  String? Function(BuildContext, String?)? staffsearchTextControllerValidator;
  // Stores action output result for [Backend Call - Query Rows] action in staffsearch widget.
  List<ServiceproviderStaffRow>? getalltechs;
  // Stores action output result for [Custom Action - techniciansearch] action in staffsearch widget.
  List<ServiceproviderStaffRow>? staffsearchresults;
  Completer<List<ServiceproviderStaffRow>>? requestCompleter9;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<DialingcodesRow>? getcodes;
  // Models for technicianstatus dynamic component.
  late FlutterFlowDynamicModels<TechnicianstatusModel> technicianstatusModels1;
  // Models for technicianstatus dynamic component.
  late FlutterFlowDynamicModels<TechnicianstatusModel> technicianstatusModels2;
  Completer<List<RequestsRow>>? requestCompleter10;
  // Models for invoicestatus dynamic component.
  late FlutterFlowDynamicModels<InvoicestatusModel> invoicestatusModels;
  Completer<List<ReviewsServiceprovidersRow>>? requestCompleter6;
  Completer<List<ReviewsFleetcompaniesRow>>? requestCompleter5;
  // State field(s) for ChoiceChips widget.
  FormFieldController<List<String>>? choiceChipsValueController;
  String? get choiceChipsValue =>
      choiceChipsValueController?.value?.firstOrNull;
  set choiceChipsValue(String? val) =>
      choiceChipsValueController?.value = val != null ? [val] : [];
  bool isDataUploading_uploadDataMypfp = false;
  FFUploadedFile uploadedLocalFile_uploadDataMypfp =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  String uploadedFileUrl_uploadDataMypfp = '';

  // State field(s) for firstname widget.
  FocusNode? firstnameFocusNode;
  TextEditingController? firstnameTextController;
  String? Function(BuildContext, String?)? firstnameTextControllerValidator;
  // State field(s) for lastname widget.
  FocusNode? lastnameFocusNode;
  TextEditingController? lastnameTextController;
  String? Function(BuildContext, String?)? lastnameTextControllerValidator;
  // State field(s) for email widget.
  FocusNode? emailFocusNode;
  TextEditingController? emailTextController;
  String? Function(BuildContext, String?)? emailTextControllerValidator;
  // State field(s) for phone widget.
  FocusNode? phoneFocusNode;
  TextEditingController? phoneTextController;
  String? Function(BuildContext, String?)? phoneTextControllerValidator;
  // Stores action output result for [Backend Call - Update Row(s)] action in Button widget.
  List<UsersRow>? updateuser;
  Completer<List<UsersRow>>? requestCompleter12;
  bool isDataUploading_uploadDataNewsplogo = false;
  FFUploadedFile uploadedLocalFile_uploadDataNewsplogo =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  String uploadedFileUrl_uploadDataNewsplogo = '';

  // State field(s) for busname widget.
  FocusNode? busnameFocusNode;
  TextEditingController? busnameTextController;
  String? Function(BuildContext, String?)? busnameTextControllerValidator;
  // State field(s) for busreg widget.
  FocusNode? busregFocusNode;
  TextEditingController? busregTextController;
  String? Function(BuildContext, String?)? busregTextControllerValidator;
  // State field(s) for emailaddy widget.
  FocusNode? emailaddyFocusNode;
  TextEditingController? emailaddyTextController;
  String? Function(BuildContext, String?)? emailaddyTextControllerValidator;
  // State field(s) for phonenum widget.
  FocusNode? phonenumFocusNode;
  TextEditingController? phonenumTextController;
  String? Function(BuildContext, String?)? phonenumTextControllerValidator;
  // State field(s) for PlacePicker widget.
  FFPlace placePickerValue = FFPlace();
  Completer<List<ServiceprovidersRow>>? requestCompleter2;
  bool isDataUploading_uploadcompanyreg2 = false;
  List<FFUploadedFile> uploadedLocalFiles_uploadcompanyreg2 = [];
  List<String> uploadedFileUrls_uploadcompanyreg2 = [];

  bool isDataUploading_uploadcompanyreg = false;
  List<FFUploadedFile> uploadedLocalFiles_uploadcompanyreg = [];
  List<String> uploadedFileUrls_uploadcompanyreg = [];

  bool isDataUploading_uploadvatreg2 = false;
  List<FFUploadedFile> uploadedLocalFiles_uploadvatreg2 = [];
  List<String> uploadedFileUrls_uploadvatreg2 = [];

  bool isDataUploading_uploadvatreg = false;
  List<FFUploadedFile> uploadedLocalFiles_uploadvatreg = [];
  List<String> uploadedFileUrls_uploadvatreg = [];

  bool isDataUploading_uploadproofins2 = false;
  List<FFUploadedFile> uploadedLocalFiles_uploadproofins2 = [];
  List<String> uploadedFileUrls_uploadproofins2 = [];

  bool isDataUploading_uploadproofins = false;
  List<FFUploadedFile> uploadedLocalFiles_uploadproofins = [];
  List<String> uploadedFileUrls_uploadproofins = [];

  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<ServicesRow>? getallservices;

  @override
  void initState(BuildContext context) {
    technicianstatusModels1 =
        FlutterFlowDynamicModels(() => TechnicianstatusModel());
    technicianstatusModels2 =
        FlutterFlowDynamicModels(() => TechnicianstatusModel());
    invoicestatusModels = FlutterFlowDynamicModels(() => InvoicestatusModel());
  }

  @override
  void dispose() {
    instantTimer?.cancel();
    staffsearchFocusNode?.dispose();
    staffsearchTextController?.dispose();

    technicianstatusModels1.dispose();
    technicianstatusModels2.dispose();
    invoicestatusModels.dispose();
    firstnameFocusNode?.dispose();
    firstnameTextController?.dispose();

    lastnameFocusNode?.dispose();
    lastnameTextController?.dispose();

    emailFocusNode?.dispose();
    emailTextController?.dispose();

    phoneFocusNode?.dispose();
    phoneTextController?.dispose();

    busnameFocusNode?.dispose();
    busnameTextController?.dispose();

    busregFocusNode?.dispose();
    busregTextController?.dispose();

    emailaddyFocusNode?.dispose();
    emailaddyTextController?.dispose();

    phonenumFocusNode?.dispose();
    phonenumTextController?.dispose();
  }

  /// Additional helper methods.
  Future waitForRequestCompleted3({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter3?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }

  Future waitForRequestCompleted7({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter7?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }

  Future waitForRequestCompleted8({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter8?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }

  Future waitForRequestCompleted11({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter11?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }

  Future waitForRequestCompleted1({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter1?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }

  Future waitForRequestCompleted4({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter4?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }

  Future waitForRequestCompleted9({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter9?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }

  Future waitForRequestCompleted10({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter10?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }

  Future waitForRequestCompleted6({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter6?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }

  Future waitForRequestCompleted5({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter5?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }

  Future waitForRequestCompleted12({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter12?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }

  Future waitForRequestCompleted2({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter2?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }
}

import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/supabase/supabase.dart';
import '/components/operatinghours/operatinghours_widget.dart';
import '/components/terms/terms_widget.dart';
import '/flutter_flow/flutter_flow_choice_chips.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_pdf_viewer.dart';
import '/flutter_flow/flutter_flow_place_picker.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/flutter_flow/place.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:io';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import '/flutter_flow/random_data_util.dart' as random_data;
import '/index.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'step3_widget.dart' show Step3Widget;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:percent_indicator/percent_indicator.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';

class Step3Model extends FlutterFlowModel<Step3Widget> {
  ///  Local state fields for this page.

  List<EmergencycontactsStruct> emergencycontacts = [];
  void addToEmergencycontacts(EmergencycontactsStruct item) =>
      emergencycontacts.add(item);
  void removeFromEmergencycontacts(EmergencycontactsStruct item) =>
      emergencycontacts.remove(item);
  void removeAtIndexFromEmergencycontacts(int index) =>
      emergencycontacts.removeAt(index);
  void insertAtIndexInEmergencycontacts(
          int index, EmergencycontactsStruct item) =>
      emergencycontacts.insert(index, item);
  void updateEmergencycontactsAtIndex(
          int index, Function(EmergencycontactsStruct) updateFn) =>
      emergencycontacts[index] = updateFn(emergencycontacts[index]);

  List<OperatinghoursStruct> operatinghours = [];
  void addToOperatinghours(OperatinghoursStruct item) =>
      operatinghours.add(item);
  void removeFromOperatinghours(OperatinghoursStruct item) =>
      operatinghours.remove(item);
  void removeAtIndexFromOperatinghours(int index) =>
      operatinghours.removeAt(index);
  void insertAtIndexInOperatinghours(int index, OperatinghoursStruct item) =>
      operatinghours.insert(index, item);
  void updateOperatinghoursAtIndex(
          int index, Function(OperatinghoursStruct) updateFn) =>
      operatinghours[index] = updateFn(operatinghours[index]);

  List<String> regdocs = [];
  void addToRegdocs(String item) => regdocs.add(item);
  void removeFromRegdocs(String item) => regdocs.remove(item);
  void removeAtIndexFromRegdocs(int index) => regdocs.removeAt(index);
  void insertAtIndexInRegdocs(int index, String item) =>
      regdocs.insert(index, item);
  void updateRegdocsAtIndex(int index, Function(String) updateFn) =>
      regdocs[index] = updateFn(regdocs[index]);

  List<String> license = [];
  void addToLicense(String item) => license.add(item);
  void removeFromLicense(String item) => license.remove(item);
  void removeAtIndexFromLicense(int index) => license.removeAt(index);
  void insertAtIndexInLicense(int index, String item) =>
      license.insert(index, item);
  void updateLicenseAtIndex(int index, Function(String) updateFn) =>
      license[index] = updateFn(license[index]);

  int? contactsadded = 0;

  String? vehicleimage;

  ServiceprovidersRow? businessexists;

  bool? verificationchecked = false;

  List<int> regions = [];
  void addToRegions(int item) => regions.add(item);
  void removeFromRegions(int item) => regions.remove(item);
  void removeAtIndexFromRegions(int index) => regions.removeAt(index);
  void insertAtIndexInRegions(int index, int item) =>
      regions.insert(index, item);
  void updateRegionsAtIndex(int index, Function(int) updateFn) =>
      regions[index] = updateFn(regions[index]);

  int? operatinghoursentered = 0;

  bool twentyfourseven = false;

  TransportersRow? fleetexists;

  int? ecEntered = 0;

  ///  State fields for stateful widgets in this page.

  // State field(s) for fleetcompany widget.
  FocusNode? fleetcompanyFocusNode;
  TextEditingController? fleetcompanyTextController;
  String? Function(BuildContext, String?)? fleetcompanyTextControllerValidator;
  // State field(s) for fm_companyreg widget.
  FocusNode? fmCompanyregFocusNode;
  TextEditingController? fmCompanyregTextController;
  late MaskTextInputFormatter fmCompanyregMask;
  String? Function(BuildContext, String?)? fmCompanyregTextControllerValidator;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<TransportersRow>? searchfleetcompany;
  // State field(s) for fm_adminPinCode widget.
  TextEditingController? fmAdminPinCode;
  FocusNode? fmAdminPinCodeFocusNode;
  String? Function(BuildContext, String?)? fmAdminPinCodeValidator;
  bool isDataUploading_fmLogo = false;
  FFUploadedFile uploadedLocalFile_fmLogo =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  String uploadedFileUrl_fmLogo = '';

  // State field(s) for fleetsize widget.
  FocusNode? fleetsizeFocusNode;
  TextEditingController? fleetsizeTextController;
  String? Function(BuildContext, String?)? fleetsizeTextControllerValidator;
  // State field(s) for fm_address widget.
  FocusNode? fmAddressFocusNode;
  TextEditingController? fmAddressTextController;
  String? Function(BuildContext, String?)? fmAddressTextControllerValidator;
  // State field(s) for fm_phone widget.
  FocusNode? fmPhoneFocusNode;
  TextEditingController? fmPhoneTextController;
  late MaskTextInputFormatter fmPhoneMask;
  String? Function(BuildContext, String?)? fmPhoneTextControllerValidator;
  // State field(s) for fm_email widget.
  FocusNode? fmEmailFocusNode;
  TextEditingController? fmEmailTextController;
  String? Function(BuildContext, String?)? fmEmailTextControllerValidator;
  // State field(s) for fm_website widget.
  FocusNode? fmWebsiteFocusNode;
  TextEditingController? fmWebsiteTextController;
  String? Function(BuildContext, String?)? fmWebsiteTextControllerValidator;
  bool isDataUploading_uploadcompreg = false;
  List<FFUploadedFile> uploadedLocalFiles_uploadcompreg = [];
  List<String> uploadedFileUrls_uploadcompreg = [];

  // State field(s) for serviceprovider_name widget.
  FocusNode? serviceproviderNameFocusNode;
  TextEditingController? serviceproviderNameTextController;
  String? Function(BuildContext, String?)?
      serviceproviderNameTextControllerValidator;
  // State field(s) for provider_role widget.
  String? providerRoleValue;
  FormFieldController<String>? providerRoleValueController;
  // State field(s) for staffPinCode widget.
  TextEditingController? staffPinCode;
  FocusNode? staffPinCodeFocusNode;
  String? Function(BuildContext, String?)? staffPinCodeValidator;
  // State field(s) for sp_businessreg widget.
  FocusNode? spBusinessregFocusNode;
  TextEditingController? spBusinessregTextController;
  late MaskTextInputFormatter spBusinessregMask;
  String? Function(BuildContext, String?)? spBusinessregTextControllerValidator;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<ServiceprovidersRow>? searchserviceprovider;
  // State field(s) for adminPinCode widget.
  TextEditingController? adminPinCode;
  FocusNode? adminPinCodeFocusNode;
  String? Function(BuildContext, String?)? adminPinCodeValidator;
  bool isDataUploading_spLogo = false;
  FFUploadedFile uploadedLocalFile_spLogo =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  String uploadedFileUrl_spLogo = '';

  // State field(s) for ChoiceChips widget.
  FormFieldController<List<String>>? choiceChipsValueController;
  List<String>? get choiceChipsValues => choiceChipsValueController?.value;
  set choiceChipsValues(List<String>? val) =>
      choiceChipsValueController?.value = val;
  // State field(s) for truck_categories widget.
  List<String>? truckCategoriesValue;
  FormFieldController<List<String>>? truckCategoriesValueController;
  // State field(s) for trailer_categories widget.
  List<String>? trailerCategoriesValue;
  FormFieldController<List<String>>? trailerCategoriesValueController;
  // State field(s) for description widget.
  FocusNode? descriptionFocusNode;
  TextEditingController? descriptionTextController;
  String? Function(BuildContext, String?)? descriptionTextControllerValidator;
  // State field(s) for PlacePicker widget.
  FFPlace placePickerValue = FFPlace();
  // State field(s) for sp_phone widget.
  FocusNode? spPhoneFocusNode;
  TextEditingController? spPhoneTextController;
  late MaskTextInputFormatter spPhoneMask;
  String? Function(BuildContext, String?)? spPhoneTextControllerValidator;
  // State field(s) for sp_email widget.
  FocusNode? spEmailFocusNode;
  TextEditingController? spEmailTextController;
  String? Function(BuildContext, String?)? spEmailTextControllerValidator;
  // State field(s) for emergencyhotline widget.
  FocusNode? emergencyhotlineFocusNode;
  TextEditingController? emergencyhotlineTextController;
  String? Function(BuildContext, String?)?
      emergencyhotlineTextControllerValidator;
  // State field(s) for emergencyprocedure widget.
  FocusNode? emergencyprocedureFocusNode;
  TextEditingController? emergencyprocedureTextController;
  String? Function(BuildContext, String?)?
      emergencyprocedureTextControllerValidator;
  bool isDataUploading_spuploaddocs = false;
  List<FFUploadedFile> uploadedLocalFiles_spuploaddocs = [];
  List<String> uploadedFileUrls_spuploaddocs = [];

  // State field(s) for Checkbox widget.
  bool? checkboxValue;
  // Stores action output result for [Backend Call - Query Rows] action in Text widget.
  List<TermsRow>? findterms;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<UsersRow>? finduser;
  // Stores action output result for [Backend Call - Insert Row] action in Button widget.
  TransportersRow? newfleetcomp;
  // Stores action output result for [Backend Call - Update Row(s)] action in Button widget.
  List<UsersRow>? updatedfleetmanager;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<UsersRow>? findspuser;
  // Stores action output result for [Backend Call - Insert Row] action in Button widget.
  ServiceprovidersRow? newserviceprovider1;
  // Stores action output result for [Backend Call - Update Row(s)] action in Button widget.
  List<UsersRow>? updatedserviceprovider1;
  // Stores action output result for [Backend Call - Insert Row] action in Button widget.
  ServiceprovidersRow? newserviceprovider2;
  // Stores action output result for [Backend Call - Update Row(s)] action in Button widget.
  List<UsersRow>? updatedserviceprovider2;
  // Stores action output result for [Backend Call - Insert Row] action in Button widget.
  ServiceprovidersRow? newserviceprovider3;
  // Stores action output result for [Backend Call - Update Row(s)] action in Button widget.
  List<UsersRow>? updatedserviceprovider3;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<ServiceproviderStaffRow>? checkifstaffexists;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<UsersRow>? findassociateduser;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<UsersRow>? findmyprofile;

  @override
  void initState(BuildContext context) {
    fmAdminPinCode = TextEditingController();
    staffPinCode = TextEditingController();
    adminPinCode = TextEditingController();
  }

  @override
  void dispose() {
    fleetcompanyFocusNode?.dispose();
    fleetcompanyTextController?.dispose();

    fmCompanyregFocusNode?.dispose();
    fmCompanyregTextController?.dispose();

    fmAdminPinCodeFocusNode?.dispose();
    fmAdminPinCode?.dispose();

    fleetsizeFocusNode?.dispose();
    fleetsizeTextController?.dispose();

    fmAddressFocusNode?.dispose();
    fmAddressTextController?.dispose();

    fmPhoneFocusNode?.dispose();
    fmPhoneTextController?.dispose();

    fmEmailFocusNode?.dispose();
    fmEmailTextController?.dispose();

    fmWebsiteFocusNode?.dispose();
    fmWebsiteTextController?.dispose();

    serviceproviderNameFocusNode?.dispose();
    serviceproviderNameTextController?.dispose();

    staffPinCodeFocusNode?.dispose();
    staffPinCode?.dispose();

    spBusinessregFocusNode?.dispose();
    spBusinessregTextController?.dispose();

    adminPinCodeFocusNode?.dispose();
    adminPinCode?.dispose();

    descriptionFocusNode?.dispose();
    descriptionTextController?.dispose();

    spPhoneFocusNode?.dispose();
    spPhoneTextController?.dispose();

    spEmailFocusNode?.dispose();
    spEmailTextController?.dispose();

    emergencyhotlineFocusNode?.dispose();
    emergencyhotlineTextController?.dispose();

    emergencyprocedureFocusNode?.dispose();
    emergencyprocedureTextController?.dispose();
  }
}

import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '/backend/schema/structs/index.dart';
import '/backend/supabase/supabase.dart';
import '/auth/firebase_auth/auth_util.dart';

List<String> stringtosinglevaluearray(String input) {
  // make the input an array with the only value being the input
  return [input]; // Return an array with the input as the only value
}

String arraytostring(List<String> list) {
  // convert the list to a string seperated by commas
  return list.join(', '); // Convert the list to a string separated by commas
}

String removespaces(String input) {
  // remove all blank spaces from the input
  return input.replaceAll(' ', ''); // Remove all blank spaces from the input
}

List<String> startendtime(String input) {
  // the input is a time range in the format HH:mm - HH:mm. Return the start time and end time
  // Split the input string by ' - ' to separate start and end times
  List<String> times = input.split(' - ');

  // Return the list containing start and end times
  return times;
}

String eta(DateTime deadline) {
  // calculate the difference between the deadline and the current time. Return the answer as a string in this format # hrs # mins. if thee are no hours just return # mins
  final now = DateTime.now();
  final difference = deadline.difference(now);

  final hours = difference.inHours;
  final minutes = difference.inMinutes.remainder(60);

  if (hours > 0) {
    return '$hours hrs $minutes mins';
  } else {
    return '$minutes mins';
  }
}

String latlngtostring(LatLng location) {
  // convert the location to a string with ONLY the coordinates
  return '${location.latitude},${location.longitude}'; // Convert LatLng to string with only coordinates
}

LatLng stringtocoordinates(String input) {
  // convert the string to coordinates
  // Split the input string by ',' to separate latitude and longitude
  List<String> parts = input.split(',');

  // Parse the latitude and longitude from the parts
  double latitude = double.parse(parts[0]);
  double longitude = double.parse(parts[1]);

  // Return a LatLng object with the parsed coordinates
  return LatLng(latitude, longitude);
}

double distance(
  LatLng point1,
  LatLng point2,
) {
  // calculate the distance between point1 and point2
  const double earthRadius = 6371; // Earth's radius in kilometers

  double lat1 = point1.latitude * (math.pi / 180);
  double lon1 = point1.longitude * (math.pi / 180);
  double lat2 = point2.latitude * (math.pi / 180);
  double lon2 = point2.longitude * (math.pi / 180);

  double dlat = lat2 - lat1;
  double dlon = lon2 - lon1;

  double a = math.sin(dlat / 2) * math.sin(dlat / 2) +
      math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2) * math.sin(dlon / 2);
  double c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a));

  return earthRadius * c; // Distance in kilometers
}

List<DateTime> startenddate(DateTime date) {
  // return the start and end of day times of the date argument
  DateTime startOfDay = DateTime(date.year, date.month, date.day, 0, 0, 0);
  DateTime endOfDay = DateTime(date.year, date.month, date.day, 23, 59, 59);
  return [startOfDay, endOfDay];
}

List<String> combinelists(
  List<String> list1,
  List<String> list2,
) {
  // combine the lists
  return [...list1, ...list2]; // Combine the two lists
}

List<int> addintegertolist(
  int input,
  List<int> list,
) {
  // add the input to the list
  list.add(input); // Add the input integer to the list
  return list; // Return the updated list
}

List<LatLng> coordinateslist(List<String> coordinates) {
  // take the list of coordinates in string format and convert it to a list of latlng values
  return coordinates.map((coord) {
    final parts = coord.split(',');
    final latitude = double.parse(parts[0]);
    final longitude = double.parse(parts[1]);
    return LatLng(latitude, longitude);
  }).toList();
}

bool overlappinglists(
  List<String> list1,
  List<String> list2,
) {
  // do list1 and list2 overlap
  return list1.any((item) => list2.contains(item));
}

List<int> removeintfromlist(
  List<int> list,
  int input,
) {
  // remove all instances of the input from the list
  return list.where((element) => element != input).toList();
}

String? phonenumber(String? input) {
  // convert the input string to a South African phone number with the official dialing code
  if (input == null) {
    return null;
  }

  if (input.startsWith('0')) {
    return '+27${input.substring(1)}';
  } else if (input.startsWith('27')) {
    return '+$input';
  } else {
    return '+27$input';
  }
}

List<String> removestringfromlist(
  String value,
  List<String> list,
) {
  // remove the value from the list
  list.remove(value); // Remove the specified value from the list
  return list; // Return the updated list
}

String phoneformat(
  String countrycode,
  String phonenumber,
) {
  // Clean both inputs
  String code = countrycode.trim().replaceAll(RegExp(r'[^+\d]'), '');
  String number = phonenumber.trim().replaceAll(RegExp(r'\s+'), '');

  // Normalize country code
  if (code.startsWith('00')) {
    code = '+' + code.substring(2);
  } else if (!code.startsWith('+')) {
    code = '+' + code;
  }

  // Remove any non-digit/plus characters from number
  number = number.replaceAll(RegExp(r'[^+\d]'), '');

  // --- SMART COMBINATION LOGIC ---
  // Case 1: If number already starts with '+', just return it
  if (number.startsWith('+')) {
    return number;
  }

  // Case 2: If number already includes the country code (without '+')
  if (number.startsWith(code.replaceAll('+', ''))) {
    return '+' + number;
  }

  // Case 3: If number starts with 0, drop it and prepend code
  if (number.startsWith('0')) {
    number = number.substring(1);
  }

  // Default: combine
  final formatted = '$code$number';

  // Validate (optional)
  final RegExp regex = RegExp(r'^\+[1-9]\d{6,14}$');
  if (!regex.hasMatch(formatted)) {
    throw FormatException('Invalid phone number format: $formatted');
  }

  return formatted;
}

String zaphone(String input) {
  // the input is a phone number. if it starts with 0, add the international dialing code for south africa
  if (input.startsWith('0')) {
    return '+27' + input.substring(1);
  }
  return input;
}

bool intlphone(String input) {
  // Regex: + followed by country code (1–3 digits, first digit 1–9),
  // then subscriber number (up to 14 digits). Total max length 15 digits.
  final RegExp regex = RegExp(r'^\+[1-9]\d{1,14}$');
  return regex.hasMatch(input);
}

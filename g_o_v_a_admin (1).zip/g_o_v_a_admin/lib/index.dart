// Export pages
export '/onboarding/authentication/authentication_widget.dart'
    show AuthenticationWidget;
export '/onboarding/step1/step1_widget.dart' show Step1Widget;
export '/onboarding/step2/step2_widget.dart' show Step2Widget;
export '/onboarding/step3/step3_widget.dart' show Step3Widget;
export '/main/incidentdetails/incidentdetails_widget.dart'
    show IncidentdetailsWidget;
export '/fleetmanager/fm_dashboard/fm_dashboard_widget.dart'
    show FmDashboardWidget;
export '/service_provider/sp_dash/sp_dash_widget.dart' show SpDashWidget;
export '/dummypages/dashboard/dashboard_widget.dart' show DashboardWidget;
export '/dummypages/loader/loader_widget.dart' show LoaderWidget;
export '/dummypages/request_details/request_details_widget.dart'
    show RequestDetailsWidget;

import '/auth/firebase_auth/auth_util.dart';
import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/backend/push_notifications/push_notifications_util.dart';
import '/backend/supabase/supabase.dart';
import '/components/assign/assign_widget.dart';
import '/components/assignedtechnician/assignedtechnician_widget.dart';
import '/components/card_pmt/card_pmt_widget.dart';
import '/components/editincident/editincident_widget.dart';
import '/components/emptyimages/emptyimages_widget.dart';
import '/components/incidentbidders/incidentbidders_widget.dart';
import '/components/manager_cancel/manager_cancel_widget.dart';
import '/components/provider_cancel/provider_cancel_widget.dart';
import '/components/vendor_profile/vendor_profile_widget.dart';
import '/fleetmanager/add_details/add_details_widget.dart';
import '/fleetmanager/editdetails/editdetails_widget.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_expanded_image_view.dart';
import '/flutter_flow/flutter_flow_google_map.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/instant_timer.dart';
import '/service_provider/view_details/view_details_widget.dart';
import 'dart:math';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'dart:async';
import 'incidentdetails_widget.dart' show IncidentdetailsWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_blurhash/flutter_blurhash.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:octo_image/octo_image.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';

class IncidentdetailsModel extends FlutterFlowModel<IncidentdetailsWidget> {
  ///  Local state fields for this page.

  List<ServiceprovidersRow> selectedproviders = [];
  void addToSelectedproviders(ServiceprovidersRow item) =>
      selectedproviders.add(item);
  void removeFromSelectedproviders(ServiceprovidersRow item) =>
      selectedproviders.remove(item);
  void removeAtIndexFromSelectedproviders(int index) =>
      selectedproviders.removeAt(index);
  void insertAtIndexInSelectedproviders(int index, ServiceprovidersRow item) =>
      selectedproviders.insert(index, item);
  void updateSelectedprovidersAtIndex(
          int index, Function(ServiceprovidersRow) updateFn) =>
      selectedproviders[index] = updateFn(selectedproviders[index]);

  List<int> selectedproviderids = [];
  void addToSelectedproviderids(int item) => selectedproviderids.add(item);
  void removeFromSelectedproviderids(int item) =>
      selectedproviderids.remove(item);
  void removeAtIndexFromSelectedproviderids(int index) =>
      selectedproviderids.removeAt(index);
  void insertAtIndexInSelectedproviderids(int index, int item) =>
      selectedproviderids.insert(index, item);
  void updateSelectedprovideridsAtIndex(int index, Function(int) updateFn) =>
      selectedproviderids[index] = updateFn(selectedproviderids[index]);

  CancellationRequestsRow? cancellation;

  ///  State fields for stateful widgets in this page.

  // Stores action output result for [Custom Action - getAddressFromLatLng] action in incidentdetails widget.
  String? getincidentaddress;
  // Stores action output result for [Backend Call - Query Rows] action in incidentdetails widget.
  List<RequestsRow>? findrequest;
  // Stores action output result for [Backend Call - Query Rows] action in incidentdetails widget.
  List<UsersRow>? finduser;
  // Stores action output result for [Backend Call - Query Rows] action in incidentdetails widget.
  List<CancellationRequestsRow>? findcancrequestsbytrans;
  // Stores action output result for [Backend Call - Query Rows] action in incidentdetails widget.
  List<CancellationRequestsRow>? findcancrequestsbyprov;
  // Stores action output result for [Firestore Query - Query a collection] action in incidentdetails widget.
  UsersRecord? findrequesterFirebase;
  // Stores action output result for [Firestore Query - Query a collection] action in incidentdetails widget.
  UsersRecord? findrequesterFirebase1;
  InstantTimer? instantTimer;
  Completer<List<RequestsRow>>? requestCompleter;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<UsersRow>? findfleetmanager;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  List<UsersRecord>? findfmFb;
  // State field(s) for GoogleMap widget.
  LatLng? googleMapsCenter;
  final googleMapsController = Completer<GoogleMapController>();
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<TransportersRow>? findfleetcompany;
  // Stores action output result for [Backend Call - API (Initiate)] action in Button widget.
  ApiCallResponse? initiatetransaction;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  List<UsersRecord>? findsuperadminsFb1;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<UsersRow>? findsuperadminsnearby;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  UsersRecord? finddriver1;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<ServiceprovidersRow>? findallserviceproviders;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<ReviewsServiceprovidersRow>? getallreviews;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<TransportersRow>? findfleetcompanyB;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<UsersRow>? findspadmins;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  List<UsersRecord>? findspadminsFb;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  UsersRecord? finddriverfb;
  // State field(s) for RatingBar widget.
  double? ratingBarValue;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<UsersRow>? findfleetmanagerA;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  List<UsersRecord>? findfmFbA;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    instantTimer?.cancel();
  }

  /// Additional helper methods.
  Future waitForRequestCompleted({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }
}

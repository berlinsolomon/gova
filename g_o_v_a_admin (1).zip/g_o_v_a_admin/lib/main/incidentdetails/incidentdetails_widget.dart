import '/auth/firebase_auth/auth_util.dart';
import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/backend/push_notifications/push_notifications_util.dart';
import '/backend/supabase/supabase.dart';
import '/components/assign/assign_widget.dart';
import '/components/assignedtechnician/assignedtechnician_widget.dart';
import '/components/card_pmt/card_pmt_widget.dart';
import '/components/editincident/editincident_widget.dart';
import '/components/emptyimages/emptyimages_widget.dart';
import '/components/incidentbidders/incidentbidders_widget.dart';
import '/components/manager_cancel/manager_cancel_widget.dart';
import '/components/provider_cancel/provider_cancel_widget.dart';
import '/components/vendor_profile/vendor_profile_widget.dart';
import '/fleetmanager/add_details/add_details_widget.dart';
import '/fleetmanager/editdetails/editdetails_widget.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_expanded_image_view.dart';
import '/flutter_flow/flutter_flow_google_map.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/instant_timer.dart';
import '/service_provider/view_details/view_details_widget.dart';
import 'dart:math';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_blurhash/flutter_blurhash.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:octo_image/octo_image.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';
import 'incidentdetails_model.dart';
export 'incidentdetails_model.dart';

class IncidentdetailsWidget extends StatefulWidget {
  const IncidentdetailsWidget({
    super.key,
    required this.requestid,
    required this.location,
  });

  final int? requestid;
  final String? location;

  static String routeName = 'incidentdetails';
  static String routePath = '/incidentdetails';

  @override
  State<IncidentdetailsWidget> createState() => _IncidentdetailsWidgetState();
}

class _IncidentdetailsWidgetState extends State<IncidentdetailsWidget>
    with TickerProviderStateMixin {
  late IncidentdetailsModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  final animationsMap = <String, AnimationInfo>{};

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => IncidentdetailsModel());

    // On page load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      await Future.wait([
        Future(() async {
          _model.getincidentaddress = await actions.getAddressFromLatLng(
            functions.stringtocoordinates(widget!.location!),
          );
          _model.findrequest = await RequestsTable().queryRows(
            queryFn: (q) => q.eqOrNull(
              'id',
              widget!.requestid,
            ),
          );
          _model.finduser = await UsersTable().queryRows(
            queryFn: (q) => q.eqOrNull(
              'uid',
              currentUserUid,
            ),
          );
          if (_model.finduser?.firstOrNull?.currentrole == 'Fleet Manager') {
            _model.findcancrequestsbytrans =
                await CancellationRequestsTable().queryRows(
              queryFn: (q) => q
                  .eqOrNull(
                    'id',
                    widget!.requestid,
                  )
                  .eqOrNull(
                    'transporter_id',
                    _model.finduser?.firstOrNull?.transporterId,
                  ),
            );
            _model.cancellation = _model.findcancrequestsbytrans?.firstOrNull;
            safeSetState(() {});
          } else {
            _model.findcancrequestsbyprov =
                await CancellationRequestsTable().queryRows(
              queryFn: (q) => q
                  .eqOrNull(
                    'id',
                    widget!.requestid,
                  )
                  .eqOrNull(
                    'service_provider',
                    _model.finduser?.firstOrNull?.serviceProvider,
                  ),
            );
            _model.cancellation = _model.findcancrequestsbyprov?.firstOrNull;
            safeSetState(() {});
          }

          if (_model.findrequest?.firstOrNull?.status ==
              'Sent to fleet manager') {
            _model.findrequesterFirebase = await queryUsersRecordOnce(
              queryBuilder: (usersRecord) => usersRecord.where(
                'uid',
                isEqualTo: _model.findrequest?.firstOrNull?.requesterUid,
              ),
              singleRecord: true,
            ).then((s) => s.firstOrNull);
            triggerPushNotification(
              notificationTitle:
                  'Incident #${widget!.requestid?.toString()} status update',
              notificationText:
                  'Your fleet manager has viewed your incident request',
              notificationSound: 'default',
              userRefs: [_model.findrequesterFirebase!.reference],
              initialPageName: 'dashboard',
              parameterData: {},
            );
            await RequestsTable().update(
              data: {
                'status': 'Viewed by fleet manager',
                'notification_sent': true,
              },
              matchingRows: (rows) => rows.eqOrNull(
                'id',
                widget!.requestid,
              ),
            );
          } else if ((_model.findrequest?.firstOrNull?.status ==
                  'Viewed by fleet manager') &&
              (_model.findrequest?.firstOrNull?.notificationSent == false)) {
            _model.findrequesterFirebase1 = await queryUsersRecordOnce(
              queryBuilder: (usersRecord) => usersRecord.where(
                'uid',
                isEqualTo: _model.findrequest?.firstOrNull?.requesterUid,
              ),
              singleRecord: true,
            ).then((s) => s.firstOrNull);
            triggerPushNotification(
              notificationTitle:
                  'Incident #${widget!.requestid?.toString()} status update',
              notificationText:
                  'Your fleet manager has viewed your incident request',
              notificationSound: 'default',
              userRefs: [_model.findrequesterFirebase1!.reference],
              initialPageName: 'dashboard',
              parameterData: {},
            );
            await RequestsTable().update(
              data: {
                'status': 'Viewed by fleet manager',
                'notification_sent': true,
              },
              matchingRows: (rows) => rows.eqOrNull(
                'id',
                widget!.requestid,
              ),
            );
          } else {
            return;
          }
        }),
        Future(() async {
          _model.instantTimer = InstantTimer.periodic(
            duration: Duration(milliseconds: 10000),
            callback: (timer) async {
              safeSetState(() => _model.requestCompleter = null);
              await _model.waitForRequestCompleted();
            },
            startImmediately: true,
          );
        }),
      ]);
    });

    animationsMap.addAll({
      'containerOnPageLoadAnimation1': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          FadeEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 600.0.ms,
            begin: 0.0,
            end: 1.0,
          ),
          MoveEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 600.0.ms,
            begin: Offset(0.0, 30.0),
            end: Offset(0.0, 0.0),
          ),
        ],
      ),
      'containerOnPageLoadAnimation2': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          FadeEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 600.0.ms,
            begin: 0.0,
            end: 1.0,
          ),
          MoveEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 600.0.ms,
            begin: Offset(0.0, 30.0),
            end: Offset(0.0, 0.0),
          ),
        ],
      ),
      'containerOnPageLoadAnimation3': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          FadeEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 600.0.ms,
            begin: 0.0,
            end: 1.0,
          ),
          MoveEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 600.0.ms,
            begin: Offset(0.0, 30.0),
            end: Offset(0.0, 0.0),
          ),
        ],
      ),
    });
    setupAnimations(
      animationsMap.values.where((anim) =>
          anim.trigger == AnimationTrigger.onActionTrigger ||
          !anim.applyInitialState),
      this,
    );

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<UsersRow>>(
      future: UsersTable().querySingleRow(
        queryFn: (q) => q.eqOrNull(
          'uid',
          currentUserUid,
        ),
      ),
      builder: (context, snapshot) {
        // Customize what your widget looks like when it's loading.
        if (!snapshot.hasData) {
          return Scaffold(
            backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
            body: Center(
              child: SizedBox(
                width: 50.0,
                height: 50.0,
                child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(
                    FlutterFlowTheme.of(context).primary,
                  ),
                ),
              ),
            ),
          );
        }
        List<UsersRow> incidentdetailsUsersRowList = snapshot.data!;

        final incidentdetailsUsersRow = incidentdetailsUsersRowList.isNotEmpty
            ? incidentdetailsUsersRowList.first
            : null;

        return GestureDetector(
          onTap: () {
            FocusScope.of(context).unfocus();
            FocusManager.instance.primaryFocus?.unfocus();
          },
          child: Scaffold(
            key: scaffoldKey,
            resizeToAvoidBottomInset: false,
            backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
            body: SafeArea(
              top: true,
              child: Container(
                decoration: BoxDecoration(),
                child: Padding(
                  padding:
                      EdgeInsetsDirectional.fromSTEB(24.0, 24.0, 24.0, 24.0),
                  child: FutureBuilder<List<RequestsRow>>(
                    future: (_model.requestCompleter ??=
                            Completer<List<RequestsRow>>()
                              ..complete(RequestsTable().querySingleRow(
                                queryFn: (q) => q.eqOrNull(
                                  'id',
                                  widget!.requestid,
                                ),
                              )))
                        .future,
                    builder: (context, snapshot) {
                      // Customize what your widget looks like when it's loading.
                      if (!snapshot.hasData) {
                        return Center(
                          child: SizedBox(
                            width: 50.0,
                            height: 50.0,
                            child: CircularProgressIndicator(
                              valueColor: AlwaysStoppedAnimation<Color>(
                                FlutterFlowTheme.of(context).primary,
                              ),
                            ),
                          ),
                        );
                      }
                      List<RequestsRow> incidentcolumnRequestsRowList =
                          snapshot.data!;

                      final incidentcolumnRequestsRow =
                          incidentcolumnRequestsRowList.isNotEmpty
                              ? incidentcolumnRequestsRowList.first
                              : null;

                      return Column(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          if (incidentdetailsUsersRow?.currentrole ==
                              'Fleet Manager')
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 0.0, 0.0, 24.0),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Expanded(
                                    child: Container(
                                      width: 100.0,
                                      height: 52.0,
                                      decoration: BoxDecoration(
                                        color: FlutterFlowTheme.of(context)
                                            .secondaryBackground,
                                        borderRadius:
                                            BorderRadius.circular(12.0),
                                      ),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          FlutterFlowIconButton(
                                            borderColor: Colors.transparent,
                                            borderRadius: 30.0,
                                            borderWidth: 1.0,
                                            buttonSize: 60.0,
                                            icon: Icon(
                                              Icons.arrow_back_rounded,
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .primaryText,
                                              size: 24.0,
                                            ),
                                            onPressed: () async {
                                              context.pushNamed(
                                                  FmDashboardWidget.routeName);
                                            },
                                          ),
                                          InkWell(
                                            splashColor: Colors.transparent,
                                            focusColor: Colors.transparent,
                                            hoverColor: Colors.transparent,
                                            highlightColor: Colors.transparent,
                                            onTap: () async {
                                              context.pushNamed(
                                                  FmDashboardWidget.routeName);
                                            },
                                            child: Text(
                                              'Incident Details',
                                              style:
                                                  FlutterFlowTheme.of(context)
                                                      .headlineMedium
                                                      .override(
                                                        font: GoogleFonts.lato(
                                                          fontWeight:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .headlineMedium
                                                                  .fontWeight,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .headlineMedium
                                                                  .fontStyle,
                                                        ),
                                                        color:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .primaryText,
                                                        fontSize: 20.0,
                                                        letterSpacing: 0.0,
                                                        fontWeight:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .headlineMedium
                                                                .fontWeight,
                                                        fontStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .headlineMedium
                                                                .fontStyle,
                                                      ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  if ((incidentcolumnRequestsRow?.status ==
                                          'Sent to service providers') &&
                                      (incidentdetailsUsersRow?.currentrole ==
                                          'Fleet Manager'))
                                    Align(
                                      alignment:
                                          AlignmentDirectional(0.0, -1.0),
                                      child: InkWell(
                                        splashColor: Colors.transparent,
                                        focusColor: Colors.transparent,
                                        hoverColor: Colors.transparent,
                                        highlightColor: Colors.transparent,
                                        onTap: () async {
                                          context.pop();
                                        },
                                        child: Container(
                                          width: 330.0,
                                          height: 52.0,
                                          decoration: BoxDecoration(
                                            color: Color(0xFF4B39EF),
                                            borderRadius:
                                                BorderRadius.circular(8.0),
                                            border: Border.all(
                                              color: Color(0xFF4B39EF),
                                              width: 2.0,
                                            ),
                                          ),
                                          child: Align(
                                            alignment:
                                                AlignmentDirectional(0.0, 0.0),
                                            child: Padding(
                                              padding: EdgeInsets.all(12.0),
                                              child: Text(
                                                'Incident sent to service providers',
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .bodyMedium
                                                        .override(
                                                          font:
                                                              GoogleFonts.lato(
                                                            fontWeight:
                                                                FontWeight.w600,
                                                            fontStyle:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyMedium
                                                                    .fontStyle,
                                                          ),
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .secondaryBackground,
                                                          letterSpacing: 0.0,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .bodyMedium
                                                                  .fontStyle,
                                                        ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  if (incidentcolumnRequestsRow?.status !=
                                      'Completed')
                                    FFButtonWidget(
                                      onPressed: () async {
                                        await showModalBottomSheet(
                                          isScrollControlled: true,
                                          backgroundColor: Colors.transparent,
                                          enableDrag: false,
                                          context: context,
                                          builder: (context) {
                                            return WebViewAware(
                                              child: GestureDetector(
                                                onTap: () {
                                                  FocusScope.of(context)
                                                      .unfocus();
                                                  FocusManager
                                                      .instance.primaryFocus
                                                      ?.unfocus();
                                                },
                                                child: Padding(
                                                  padding:
                                                      MediaQuery.viewInsetsOf(
                                                          context),
                                                  child: ManagerCancelWidget(
                                                    incident:
                                                        incidentcolumnRequestsRow!,
                                                    user:
                                                        incidentdetailsUsersRow!,
                                                    refresh: () async {
                                                      safeSetState(() => _model
                                                              .requestCompleter =
                                                          null);
                                                    },
                                                  ),
                                                ),
                                              ),
                                            );
                                          },
                                        ).then((value) => safeSetState(() {}));
                                      },
                                      text: 'Cancel/Withdraw',
                                      options: FFButtonOptions(
                                        height: 52.0,
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            16.0, 0.0, 16.0, 0.0),
                                        iconPadding:
                                            EdgeInsetsDirectional.fromSTEB(
                                                0.0, 0.0, 0.0, 0.0),
                                        color: FlutterFlowTheme.of(context)
                                            .primaryText,
                                        textStyle: FlutterFlowTheme.of(context)
                                            .titleSmall
                                            .override(
                                              font: GoogleFonts.lato(
                                                fontWeight:
                                                    FlutterFlowTheme.of(context)
                                                        .titleSmall
                                                        .fontWeight,
                                                fontStyle:
                                                    FlutterFlowTheme.of(context)
                                                        .titleSmall
                                                        .fontStyle,
                                              ),
                                              color: Colors.white,
                                              fontSize: 14.0,
                                              letterSpacing: 0.0,
                                              fontWeight:
                                                  FlutterFlowTheme.of(context)
                                                      .titleSmall
                                                      .fontWeight,
                                              fontStyle:
                                                  FlutterFlowTheme.of(context)
                                                      .titleSmall
                                                      .fontStyle,
                                            ),
                                        elevation: 2.0,
                                        borderRadius:
                                            BorderRadius.circular(8.0),
                                      ),
                                    ),
                                ].divide(SizedBox(width: 24.0)),
                              ),
                            ),
                          if (incidentdetailsUsersRow?.currentrole ==
                              'Service Provider')
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 0.0, 0.0, 24.0),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Expanded(
                                    child: Container(
                                      width: 100.0,
                                      height: 52.0,
                                      decoration: BoxDecoration(
                                        color: FlutterFlowTheme.of(context)
                                            .secondaryBackground,
                                        borderRadius:
                                            BorderRadius.circular(12.0),
                                      ),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          FlutterFlowIconButton(
                                            borderColor: Colors.transparent,
                                            borderRadius: 30.0,
                                            borderWidth: 1.0,
                                            buttonSize: 60.0,
                                            icon: Icon(
                                              Icons.arrow_back_rounded,
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .primaryText,
                                              size: 24.0,
                                            ),
                                            onPressed: () async {
                                              context.pushNamed(
                                                  SpDashWidget.routeName);
                                            },
                                          ),
                                          InkWell(
                                            splashColor: Colors.transparent,
                                            focusColor: Colors.transparent,
                                            hoverColor: Colors.transparent,
                                            highlightColor: Colors.transparent,
                                            onTap: () async {
                                              context.pushNamed(
                                                  SpDashWidget.routeName);
                                            },
                                            child: Text(
                                              'Incident Details',
                                              style:
                                                  FlutterFlowTheme.of(context)
                                                      .headlineMedium
                                                      .override(
                                                        font: GoogleFonts.lato(
                                                          fontWeight:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .headlineMedium
                                                                  .fontWeight,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .headlineMedium
                                                                  .fontStyle,
                                                        ),
                                                        color:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .primaryText,
                                                        fontSize: 20.0,
                                                        letterSpacing: 0.0,
                                                        fontWeight:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .headlineMedium
                                                                .fontWeight,
                                                        fontStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .headlineMedium
                                                                .fontStyle,
                                                      ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  if ((incidentcolumnRequestsRow
                                              ?.chosenprovider !=
                                          null) &&
                                      (incidentcolumnRequestsRow
                                              ?.chosenprovider ==
                                          incidentdetailsUsersRow
                                              ?.serviceProvider))
                                    Align(
                                      alignment:
                                          AlignmentDirectional(0.0, -1.0),
                                      child: InkWell(
                                        splashColor: Colors.transparent,
                                        focusColor: Colors.transparent,
                                        hoverColor: Colors.transparent,
                                        highlightColor: Colors.transparent,
                                        onTap: () async {
                                          context.pop();
                                        },
                                        child: Container(
                                          width: 330.0,
                                          height: 52.0,
                                          decoration: BoxDecoration(
                                            color: FlutterFlowTheme.of(context)
                                                .success,
                                            borderRadius:
                                                BorderRadius.circular(8.0),
                                            border: Border.all(
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .success,
                                              width: 2.0,
                                            ),
                                          ),
                                          child: Align(
                                            alignment:
                                                AlignmentDirectional(0.0, 0.0),
                                            child: Padding(
                                              padding: EdgeInsets.all(12.0),
                                              child: Text(
                                                'Fleet manager selected you for this incident',
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .bodyMedium
                                                        .override(
                                                          font:
                                                              GoogleFonts.lato(
                                                            fontWeight:
                                                                FontWeight.w600,
                                                            fontStyle:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyMedium
                                                                    .fontStyle,
                                                          ),
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .secondaryBackground,
                                                          letterSpacing: 0.0,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .bodyMedium
                                                                  .fontStyle,
                                                        ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  if ((incidentdetailsUsersRow?.currentrole ==
                                          'Service Provider') &&
                                      (incidentcolumnRequestsRow
                                                  ?.cancellationReason ==
                                              null ||
                                          incidentcolumnRequestsRow
                                                  ?.cancellationReason ==
                                              '') &&
                                      (incidentcolumnRequestsRow?.status !=
                                          'Completed') &&
                                      incidentcolumnRequestsRow!.bidsopen!)
                                    FutureBuilder<List<ServiceprovidersRow>>(
                                      future: ServiceprovidersTable()
                                          .querySingleRow(
                                        queryFn: (q) => q.eqOrNull(
                                          'id',
                                          incidentdetailsUsersRow
                                              ?.serviceProvider,
                                        ),
                                      ),
                                      builder: (context, snapshot) {
                                        // Customize what your widget looks like when it's loading.
                                        if (!snapshot.hasData) {
                                          return Center(
                                            child: SizedBox(
                                              width: 50.0,
                                              height: 50.0,
                                              child: CircularProgressIndicator(
                                                valueColor:
                                                    AlwaysStoppedAnimation<
                                                        Color>(
                                                  FlutterFlowTheme.of(context)
                                                      .primary,
                                                ),
                                              ),
                                            ),
                                          );
                                        }
                                        List<ServiceprovidersRow>
                                            rowServiceprovidersRowList =
                                            snapshot.data!;

                                        final rowServiceprovidersRow =
                                            rowServiceprovidersRowList
                                                    .isNotEmpty
                                                ? rowServiceprovidersRowList
                                                    .first
                                                : null;

                                        return Row(
                                          mainAxisSize: MainAxisSize.max,
                                          children: [
                                            if ((incidentcolumnRequestsRow
                                                        ?.providersTendered
                                                        ?.contains(
                                                            rowServiceprovidersRow
                                                                ?.id) ==
                                                    false) &&
                                                (incidentcolumnRequestsRow
                                                        ?.ignoredBy
                                                        ?.contains(
                                                            rowServiceprovidersRow
                                                                ?.id) ==
                                                    false))
                                              Expanded(
                                                child: FFButtonWidget(
                                                  onPressed: () async {
                                                    var _shouldSetState = false;
                                                    var confirmDialogResponse =
                                                        await showDialog<bool>(
                                                              context: context,
                                                              builder:
                                                                  (alertDialogContext) {
                                                                return WebViewAware(
                                                                  child:
                                                                      AlertDialog(
                                                                    title: Text(
                                                                        'Are you sure you want to accept this job?'),
                                                                    content: Text(
                                                                        '${incidentcolumnRequestsRow?.serviceRequested} (approx. ${formatNumber(
                                                                      functions.distance(
                                                                          functions.stringtocoordinates(incidentcolumnRequestsRow!
                                                                              .requesterLocation!),
                                                                          functions
                                                                              .stringtocoordinates(rowServiceprovidersRow!.coordinates!)),
                                                                      formatType:
                                                                          FormatType
                                                                              .custom,
                                                                      format:
                                                                          '0km',
                                                                      locale:
                                                                          '',
                                                                    )} away)'),
                                                                    actions: [
                                                                      TextButton(
                                                                        onPressed: () => Navigator.pop(
                                                                            alertDialogContext,
                                                                            false),
                                                                        child: Text(
                                                                            'Cancel'),
                                                                      ),
                                                                      TextButton(
                                                                        onPressed: () => Navigator.pop(
                                                                            alertDialogContext,
                                                                            true),
                                                                        child: Text(
                                                                            'Confirm'),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                );
                                                              },
                                                            ) ??
                                                            false;
                                                    if (confirmDialogResponse) {
                                                      await RequestsTable()
                                                          .update(
                                                        data: {
                                                          'providers_tendered':
                                                              functions.addintegertolist(
                                                                  rowServiceprovidersRow!
                                                                      .id,
                                                                  incidentcolumnRequestsRow!
                                                                      .providersTendered
                                                                      .toList()),
                                                        },
                                                        matchingRows: (rows) =>
                                                            rows.eqOrNull(
                                                          'id',
                                                          incidentcolumnRequestsRow
                                                              ?.id,
                                                        ),
                                                      );
                                                      _model.findfleetmanager =
                                                          await UsersTable()
                                                              .queryRows(
                                                        queryFn: (q) => q
                                                            .eqOrNull(
                                                              'transporter_id',
                                                              incidentcolumnRequestsRow
                                                                  ?.fleetcompanyId,
                                                            )
                                                            .eqOrNull(
                                                              'currentrole',
                                                              'Fleet Manager',
                                                            ),
                                                      );
                                                      _shouldSetState = true;
                                                      _model.findfmFb =
                                                          await queryUsersRecordOnce(
                                                        queryBuilder: (usersRecord) =>
                                                            usersRecord.whereIn(
                                                                'uid',
                                                                _model
                                                                    .findfleetmanager
                                                                    ?.map((e) =>
                                                                        e.uid)
                                                                    .withoutNulls
                                                                    .toList()),
                                                      );
                                                      _shouldSetState = true;
                                                      await Future.wait([
                                                        Future(() async {
                                                          triggerPushNotification(
                                                            notificationTitle:
                                                                'New Bid - Incident #${incidentcolumnRequestsRow?.id?.toString()}',
                                                            notificationText:
                                                                'A service provider is ready to assist your driver (${incidentcolumnRequestsRow?.requesterName}) who requested ${incidentcolumnRequestsRow?.serviceRequested} services at ${incidentcolumnRequestsRow?.address}',
                                                            notificationSound:
                                                                'default',
                                                            userRefs: _model
                                                                .findfmFb!
                                                                .map((e) =>
                                                                    e.reference)
                                                                .toList(),
                                                            initialPageName:
                                                                'request_details',
                                                            parameterData: {
                                                              'role':
                                                                  'Fleet Manager',
                                                              'requestid':
                                                                  incidentcolumnRequestsRow
                                                                      ?.id,
                                                              'completed':
                                                                  false,
                                                            },
                                                          );
                                                        }),
                                                        Future(() async {
                                                          await NotificationsTable()
                                                              .insert({
                                                            'title':
                                                                'New Bid - Incident #${incidentcolumnRequestsRow?.id?.toString()}',
                                                            'created_at':
                                                                supaSerialize<
                                                                        DateTime>(
                                                                    getCurrentTimestamp),
                                                            'message':
                                                                'A service provider is ready to assist your driver (${incidentcolumnRequestsRow?.requesterName}) who requested ${incidentcolumnRequestsRow?.serviceRequested} services at ${incidentcolumnRequestsRow?.address}',
                                                            'sent_by':
                                                                currentUserUid,
                                                            'sent_to': _model
                                                                .findfleetmanager
                                                                ?.map((e) =>
                                                                    e.uid)
                                                                .withoutNulls
                                                                .toList(),
                                                            'category':
                                                                'Incident',
                                                          });
                                                        }),
                                                      ]);
                                                      safeSetState(() => _model
                                                              .requestCompleter =
                                                          null);
                                                      await NewBidFromServiceProviderCall
                                                          .call(
                                                        fmPhone: _model
                                                            .findfleetmanager
                                                            ?.firstOrNull
                                                            ?.phone,
                                                        serviceProvider:
                                                            rowServiceprovidersRow
                                                                ?.companyName,
                                                        services:
                                                            incidentcolumnRequestsRow
                                                                ?.serviceRequested,
                                                        incident: widget!
                                                            .requestid
                                                            ?.toString(),
                                                        driverName:
                                                            incidentcolumnRequestsRow
                                                                ?.requesterName,
                                                        address:
                                                            incidentcolumnRequestsRow
                                                                ?.address,
                                                      );

                                                      await showDialog(
                                                        context: context,
                                                        builder:
                                                            (alertDialogContext) {
                                                          return WebViewAware(
                                                            child: AlertDialog(
                                                              title: Text(
                                                                  'Your bid for the job has been sent to the fleet manager'),
                                                              actions: [
                                                                TextButton(
                                                                  onPressed: () =>
                                                                      Navigator.pop(
                                                                          alertDialogContext),
                                                                  child: Text(
                                                                      'Ok'),
                                                                ),
                                                              ],
                                                            ),
                                                          );
                                                        },
                                                      );
                                                    } else {
                                                      if (_shouldSetState)
                                                        safeSetState(() {});
                                                      return;
                                                    }

                                                    if (_shouldSetState)
                                                      safeSetState(() {});
                                                  },
                                                  text: 'Accept',
                                                  options: FFButtonOptions(
                                                    width: 120.0,
                                                    height: 52.0,
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(16.0, 0.0,
                                                                16.0, 0.0),
                                                    iconPadding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(0.0, 0.0,
                                                                0.0, 0.0),
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .primary,
                                                    textStyle: FlutterFlowTheme
                                                            .of(context)
                                                        .titleSmall
                                                        .override(
                                                          font:
                                                              GoogleFonts.lato(
                                                            fontWeight:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .titleSmall
                                                                    .fontWeight,
                                                            fontStyle:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .titleSmall
                                                                    .fontStyle,
                                                          ),
                                                          color: Colors.white,
                                                          fontSize: 14.0,
                                                          letterSpacing: 0.0,
                                                          fontWeight:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .titleSmall
                                                                  .fontWeight,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .titleSmall
                                                                  .fontStyle,
                                                        ),
                                                    elevation: 2.0,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            8.0),
                                                  ),
                                                ),
                                              ),
                                            if ((incidentcolumnRequestsRow
                                                        ?.providersTendered
                                                        ?.contains(
                                                            rowServiceprovidersRow
                                                                ?.id) ==
                                                    false) &&
                                                (incidentcolumnRequestsRow
                                                        ?.ignoredBy
                                                        ?.contains(
                                                            rowServiceprovidersRow
                                                                ?.id) ==
                                                    false))
                                              Expanded(
                                                child: FFButtonWidget(
                                                  onPressed: () async {
                                                    var confirmDialogResponse =
                                                        await showDialog<bool>(
                                                              context: context,
                                                              builder:
                                                                  (alertDialogContext) {
                                                                return WebViewAware(
                                                                  child:
                                                                      AlertDialog(
                                                                    title: Text(
                                                                        'Are you sure you want to ignore this job?'),
                                                                    content: Text(
                                                                        '${incidentcolumnRequestsRow?.serviceRequested} (approx. ${formatNumber(
                                                                      functions.distance(
                                                                          functions.stringtocoordinates(incidentcolumnRequestsRow!
                                                                              .requesterLocation!),
                                                                          functions
                                                                              .stringtocoordinates(rowServiceprovidersRow!.coordinates!)),
                                                                      formatType:
                                                                          FormatType
                                                                              .custom,
                                                                      format:
                                                                          '0km',
                                                                      locale:
                                                                          '',
                                                                    )} away)'),
                                                                    actions: [
                                                                      TextButton(
                                                                        onPressed: () => Navigator.pop(
                                                                            alertDialogContext,
                                                                            false),
                                                                        child: Text(
                                                                            'Cancel'),
                                                                      ),
                                                                      TextButton(
                                                                        onPressed: () => Navigator.pop(
                                                                            alertDialogContext,
                                                                            true),
                                                                        child: Text(
                                                                            'Confirm'),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                );
                                                              },
                                                            ) ??
                                                            false;
                                                    if (confirmDialogResponse) {
                                                      await RequestsTable()
                                                          .update(
                                                        data: {
                                                          'ignored_by': functions
                                                              .addintegertolist(
                                                                  rowServiceprovidersRow!
                                                                      .id,
                                                                  incidentcolumnRequestsRow!
                                                                      .ignoredBy
                                                                      .toList()),
                                                        },
                                                        matchingRows: (rows) =>
                                                            rows.eqOrNull(
                                                          'id',
                                                          incidentcolumnRequestsRow
                                                              ?.id,
                                                        ),
                                                      );
                                                      safeSetState(() => _model
                                                              .requestCompleter =
                                                          null);
                                                      await showDialog(
                                                        context: context,
                                                        builder:
                                                            (alertDialogContext) {
                                                          return WebViewAware(
                                                            child: AlertDialog(
                                                              title: Text(
                                                                  'You have ignored this job'),
                                                              actions: [
                                                                TextButton(
                                                                  onPressed: () =>
                                                                      Navigator.pop(
                                                                          alertDialogContext),
                                                                  child: Text(
                                                                      'Ok'),
                                                                ),
                                                              ],
                                                            ),
                                                          );
                                                        },
                                                      );
                                                      context.pop();
                                                    } else {
                                                      return;
                                                    }
                                                  },
                                                  text: 'Ignore',
                                                  options: FFButtonOptions(
                                                    width: 120.0,
                                                    height: 52.0,
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(16.0, 0.0,
                                                                16.0, 0.0),
                                                    iconPadding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(0.0, 0.0,
                                                                0.0, 0.0),
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .primaryText,
                                                    textStyle: FlutterFlowTheme
                                                            .of(context)
                                                        .titleSmall
                                                        .override(
                                                          font:
                                                              GoogleFonts.lato(
                                                            fontWeight:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .titleSmall
                                                                    .fontWeight,
                                                            fontStyle:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .titleSmall
                                                                    .fontStyle,
                                                          ),
                                                          color: Colors.white,
                                                          fontSize: 14.0,
                                                          letterSpacing: 0.0,
                                                          fontWeight:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .titleSmall
                                                                  .fontWeight,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .titleSmall
                                                                  .fontStyle,
                                                        ),
                                                    elevation: 2.0,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            8.0),
                                                  ),
                                                ),
                                              ),
                                          ].divide(SizedBox(width: 24.0)),
                                        );
                                      },
                                    ),
                                  if ((incidentcolumnRequestsRow
                                              ?.chosenprovider !=
                                          null) &&
                                      (incidentcolumnRequestsRow
                                              ?.chosenprovider ==
                                          incidentdetailsUsersRow
                                              ?.serviceProvider) &&
                                      (incidentdetailsUsersRow?.currentrole ==
                                          'Service Provider') &&
                                      (incidentcolumnRequestsRow?.status !=
                                          'Completed'))
                                    FFButtonWidget(
                                      onPressed: () async {
                                        if ((_model.cancellation?.status ==
                                                'Successful') ||
                                            (incidentcolumnRequestsRow
                                                        ?.cancellationReason !=
                                                    null &&
                                                incidentcolumnRequestsRow
                                                        ?.cancellationReason !=
                                                    '')) {
                                          await showDialog(
                                            context: context,
                                            builder: (alertDialogContext) {
                                              return WebViewAware(
                                                child: AlertDialog(
                                                  title: Text(
                                                      'Action not permitted'),
                                                  content: Text(
                                                      'You cannot assign or re-assign this job because you have already withdrawn.'),
                                                  actions: [
                                                    TextButton(
                                                      onPressed: () =>
                                                          Navigator.pop(
                                                              alertDialogContext),
                                                      child: Text('Ok'),
                                                    ),
                                                  ],
                                                ),
                                              );
                                            },
                                          );
                                        } else {
                                          await showModalBottomSheet(
                                            isScrollControlled: true,
                                            backgroundColor: Colors.transparent,
                                            enableDrag: false,
                                            context: context,
                                            builder: (context) {
                                              return WebViewAware(
                                                child: GestureDetector(
                                                  onTap: () {
                                                    FocusScope.of(context)
                                                        .unfocus();
                                                    FocusManager
                                                        .instance.primaryFocus
                                                        ?.unfocus();
                                                  },
                                                  child: Padding(
                                                    padding:
                                                        MediaQuery.viewInsetsOf(
                                                            context),
                                                    child: AssignWidget(
                                                      serviceprovider:
                                                          incidentcolumnRequestsRow!
                                                              .chosenprovider!,
                                                      job:
                                                          incidentcolumnRequestsRow!,
                                                      assignee: 0,
                                                      refresh: () async {
                                                        safeSetState(() => _model
                                                                .requestCompleter =
                                                            null);
                                                        await _model
                                                            .waitForRequestCompleted();
                                                      },
                                                    ),
                                                  ),
                                                ),
                                              );
                                            },
                                          ).then(
                                              (value) => safeSetState(() {}));
                                        }
                                      },
                                      text: incidentcolumnRequestsRow
                                                  ?.technicianUserid !=
                                              null
                                          ? 'Re-assign Job'
                                          : 'Assign Job',
                                      options: FFButtonOptions(
                                        width: 120.0,
                                        height: 52.0,
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            16.0, 0.0, 16.0, 0.0),
                                        iconPadding:
                                            EdgeInsetsDirectional.fromSTEB(
                                                0.0, 0.0, 0.0, 0.0),
                                        color: FlutterFlowTheme.of(context)
                                            .primary,
                                        textStyle: FlutterFlowTheme.of(context)
                                            .titleSmall
                                            .override(
                                              font: GoogleFonts.lato(
                                                fontWeight:
                                                    FlutterFlowTheme.of(context)
                                                        .titleSmall
                                                        .fontWeight,
                                                fontStyle:
                                                    FlutterFlowTheme.of(context)
                                                        .titleSmall
                                                        .fontStyle,
                                              ),
                                              color: Colors.white,
                                              fontSize: 20.0,
                                              letterSpacing: 0.0,
                                              fontWeight:
                                                  FlutterFlowTheme.of(context)
                                                      .titleSmall
                                                      .fontWeight,
                                              fontStyle:
                                                  FlutterFlowTheme.of(context)
                                                      .titleSmall
                                                      .fontStyle,
                                            ),
                                        elevation: 2.0,
                                        borderRadius:
                                            BorderRadius.circular(8.0),
                                      ),
                                    ),
                                ].divide(SizedBox(width: 24.0)),
                              ),
                            ),
                          Expanded(
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  flex: 3,
                                  child: Container(
                                    decoration: BoxDecoration(),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Container(
                                          width: double.infinity,
                                          decoration: BoxDecoration(
                                            color: FlutterFlowTheme.of(context)
                                                .secondaryBackground,
                                            borderRadius:
                                                BorderRadius.circular(8.0),
                                            border: Border.all(
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .secondaryBackground,
                                              width: 2.0,
                                            ),
                                          ),
                                          child: Padding(
                                            padding: EdgeInsets.all(24.0),
                                            child: Column(
                                              mainAxisSize: MainAxisSize.max,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceEvenly,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Row(
                                                  mainAxisSize:
                                                      MainAxisSize.max,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    Text(
                                                      'Main Details',
                                                      style: FlutterFlowTheme
                                                              .of(context)
                                                          .bodyMedium
                                                          .override(
                                                            font: GoogleFonts
                                                                .lato(
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w600,
                                                              fontStyle:
                                                                  FlutterFlowTheme.of(
                                                                          context)
                                                                      .bodyMedium
                                                                      .fontStyle,
                                                            ),
                                                            fontSize: 20.0,
                                                            letterSpacing: 0.0,
                                                            fontWeight:
                                                                FontWeight.w600,
                                                            fontStyle:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyMedium
                                                                    .fontStyle,
                                                          ),
                                                    ),
                                                    if (incidentdetailsUsersRow
                                                            ?.currentrole ==
                                                        'Fleet Manager')
                                                      FlutterFlowIconButton(
                                                        buttonSize: 40.0,
                                                        icon: Icon(
                                                          Icons.edit_outlined,
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .secondaryText,
                                                          size: 24.0,
                                                        ),
                                                        onPressed: () async {
                                                          await showModalBottomSheet(
                                                            isScrollControlled:
                                                                true,
                                                            backgroundColor:
                                                                Colors
                                                                    .transparent,
                                                            enableDrag: false,
                                                            useSafeArea: true,
                                                            context: context,
                                                            builder: (context) {
                                                              return WebViewAware(
                                                                child:
                                                                    GestureDetector(
                                                                  onTap: () {
                                                                    FocusScope.of(
                                                                            context)
                                                                        .unfocus();
                                                                    FocusManager
                                                                        .instance
                                                                        .primaryFocus
                                                                        ?.unfocus();
                                                                  },
                                                                  child:
                                                                      Padding(
                                                                    padding: MediaQuery
                                                                        .viewInsetsOf(
                                                                            context),
                                                                    child:
                                                                        EditincidentWidget(
                                                                      incident:
                                                                          incidentcolumnRequestsRow!,
                                                                      refresh:
                                                                          () async {
                                                                        safeSetState(() =>
                                                                            _model.requestCompleter =
                                                                                null);
                                                                        await _model
                                                                            .waitForRequestCompleted();
                                                                      },
                                                                    ),
                                                                  ),
                                                                ),
                                                              );
                                                            },
                                                          ).then((value) =>
                                                              safeSetState(
                                                                  () {}));
                                                        },
                                                      ),
                                                  ],
                                                ),
                                                Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          0.0, 8.0, 0.0, 0.0),
                                                  child: Text(
                                                    'Incident number: #${widget!.requestid?.toString()}',
                                                    style: FlutterFlowTheme.of(
                                                            context)
                                                        .bodyMedium
                                                        .override(
                                                          font:
                                                              GoogleFonts.lato(
                                                            fontWeight:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyMedium
                                                                    .fontWeight,
                                                            fontStyle:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyMedium
                                                                    .fontStyle,
                                                          ),
                                                          letterSpacing: 0.0,
                                                          fontWeight:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .bodyMedium
                                                                  .fontWeight,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .bodyMedium
                                                                  .fontStyle,
                                                        ),
                                                  ),
                                                ),
                                                Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          0.0, 8.0, 0.0, 0.0),
                                                  child: Text(
                                                    'Time: ${dateTimeFormat("dd MMM y @ HH:mm", incidentcolumnRequestsRow?.createdAt)} (${dateTimeFormat("relative", incidentcolumnRequestsRow?.createdAt)})',
                                                    style: FlutterFlowTheme.of(
                                                            context)
                                                        .bodyMedium
                                                        .override(
                                                          font:
                                                              GoogleFonts.lato(
                                                            fontWeight:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyMedium
                                                                    .fontWeight,
                                                            fontStyle:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyMedium
                                                                    .fontStyle,
                                                          ),
                                                          letterSpacing: 0.0,
                                                          fontWeight:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .bodyMedium
                                                                  .fontWeight,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .bodyMedium
                                                                  .fontStyle,
                                                        ),
                                                  ),
                                                ),
                                                Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          0.0, 8.0, 0.0, 0.0),
                                                  child: Text(
                                                    'Vehicle VIN: ${incidentcolumnRequestsRow?.vehicleVin != null && incidentcolumnRequestsRow?.vehicleVin != '' ? incidentcolumnRequestsRow?.vehicleVin : (incidentdetailsUsersRow?.currentrole == 'Fleet Manager' ? 'Please enter' : 'Not specified')}',
                                                    style: FlutterFlowTheme.of(
                                                            context)
                                                        .bodyMedium
                                                        .override(
                                                          font:
                                                              GoogleFonts.lato(
                                                            fontWeight:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyMedium
                                                                    .fontWeight,
                                                            fontStyle:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyMedium
                                                                    .fontStyle,
                                                          ),
                                                          letterSpacing: 0.0,
                                                          fontWeight:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .bodyMedium
                                                                  .fontWeight,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .bodyMedium
                                                                  .fontStyle,
                                                        ),
                                                  ),
                                                ),
                                                Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          0.0, 8.0, 0.0, 0.0),
                                                  child: Text(
                                                    'Suspension: ${incidentcolumnRequestsRow?.suspension != null && incidentcolumnRequestsRow?.suspension != '' ? incidentcolumnRequestsRow?.suspension : (incidentdetailsUsersRow?.currentrole == 'Fleet Manager' ? 'Please enter' : 'Not specified')}',
                                                    style: FlutterFlowTheme.of(
                                                            context)
                                                        .bodyMedium
                                                        .override(
                                                          font:
                                                              GoogleFonts.lato(
                                                            fontWeight:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyMedium
                                                                    .fontWeight,
                                                            fontStyle:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyMedium
                                                                    .fontStyle,
                                                          ),
                                                          letterSpacing: 0.0,
                                                          fontWeight:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .bodyMedium
                                                                  .fontWeight,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .bodyMedium
                                                                  .fontStyle,
                                                        ),
                                                  ),
                                                ),
                                                Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          0.0, 8.0, 0.0, 0.0),
                                                  child: Text(
                                                    'Service type: ${incidentcolumnRequestsRow?.type}',
                                                    style: FlutterFlowTheme.of(
                                                            context)
                                                        .bodyMedium
                                                        .override(
                                                          font:
                                                              GoogleFonts.lato(
                                                            fontWeight:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyMedium
                                                                    .fontWeight,
                                                            fontStyle:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyMedium
                                                                    .fontStyle,
                                                          ),
                                                          letterSpacing: 0.0,
                                                          fontWeight:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .bodyMedium
                                                                  .fontWeight,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .bodyMedium
                                                                  .fontStyle,
                                                        ),
                                                  ),
                                                ),
                                                Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(
                                                          0.0, 8.0, 0.0, 20.0),
                                                  child: Text(
                                                    'Primary service requested: ${incidentcolumnRequestsRow?.serviceRequested}',
                                                    style: FlutterFlowTheme.of(
                                                            context)
                                                        .bodyMedium
                                                        .override(
                                                          font:
                                                              GoogleFonts.lato(
                                                            fontWeight:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyMedium
                                                                    .fontWeight,
                                                            fontStyle:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .bodyMedium
                                                                    .fontStyle,
                                                          ),
                                                          letterSpacing: 0.0,
                                                          fontWeight:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .bodyMedium
                                                                  .fontWeight,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .bodyMedium
                                                                  .fontStyle,
                                                        ),
                                                  ),
                                                ),
                                                FFButtonWidget(
                                                  onPressed: () async {
                                                    if (incidentdetailsUsersRow
                                                            ?.currentrole ==
                                                        'Fleet Manager') {
                                                      await showModalBottomSheet(
                                                        isScrollControlled:
                                                            true,
                                                        backgroundColor:
                                                            Colors.transparent,
                                                        useSafeArea: true,
                                                        context: context,
                                                        builder: (context) {
                                                          return WebViewAware(
                                                            child:
                                                                GestureDetector(
                                                              onTap: () {
                                                                FocusScope.of(
                                                                        context)
                                                                    .unfocus();
                                                                FocusManager
                                                                    .instance
                                                                    .primaryFocus
                                                                    ?.unfocus();
                                                              },
                                                              child: Padding(
                                                                padding: MediaQuery
                                                                    .viewInsetsOf(
                                                                        context),
                                                                child:
                                                                    EditdetailsWidget(
                                                                  incident:
                                                                      incidentcolumnRequestsRow,
                                                                  refresh:
                                                                      () async {
                                                                    safeSetState(() =>
                                                                        _model.requestCompleter =
                                                                            null);
                                                                  },
                                                                ),
                                                              ),
                                                            ),
                                                          );
                                                        },
                                                      ).then((value) =>
                                                          safeSetState(() {}));
                                                    } else if (incidentdetailsUsersRow
                                                            ?.currentrole ==
                                                        'Service Provider') {
                                                      await showModalBottomSheet(
                                                        isScrollControlled:
                                                            true,
                                                        backgroundColor:
                                                            Colors.transparent,
                                                        enableDrag: false,
                                                        context: context,
                                                        builder: (context) {
                                                          return WebViewAware(
                                                            child:
                                                                GestureDetector(
                                                              onTap: () {
                                                                FocusScope.of(
                                                                        context)
                                                                    .unfocus();
                                                                FocusManager
                                                                    .instance
                                                                    .primaryFocus
                                                                    ?.unfocus();
                                                              },
                                                              child: Padding(
                                                                padding: MediaQuery
                                                                    .viewInsetsOf(
                                                                        context),
                                                                child:
                                                                    ViewDetailsWidget(
                                                                  incident:
                                                                      incidentcolumnRequestsRow,
                                                                  refresh:
                                                                      () async {
                                                                    safeSetState(() =>
                                                                        _model.requestCompleter =
                                                                            null);
                                                                  },
                                                                ),
                                                              ),
                                                            ),
                                                          );
                                                        },
                                                      ).then((value) =>
                                                          safeSetState(() {}));
                                                    } else {
                                                      return;
                                                    }
                                                  },
                                                  text:
                                                      'View additional details',
                                                  options: FFButtonOptions(
                                                    width: double.infinity,
                                                    height: 52.0,
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(16.0, 0.0,
                                                                16.0, 0.0),
                                                    iconPadding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(0.0, 0.0,
                                                                0.0, 0.0),
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .secondary,
                                                    textStyle: FlutterFlowTheme
                                                            .of(context)
                                                        .titleSmall
                                                        .override(
                                                          font:
                                                              GoogleFonts.lato(
                                                            fontWeight:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .titleSmall
                                                                    .fontWeight,
                                                            fontStyle:
                                                                FlutterFlowTheme.of(
                                                                        context)
                                                                    .titleSmall
                                                                    .fontStyle,
                                                          ),
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .secondaryBackground,
                                                          fontSize: 14.0,
                                                          letterSpacing: 0.0,
                                                          fontWeight:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .titleSmall
                                                                  .fontWeight,
                                                          fontStyle:
                                                              FlutterFlowTheme.of(
                                                                      context)
                                                                  .titleSmall
                                                                  .fontStyle,
                                                        ),
                                                    elevation: 2.0,
                                                    borderSide: BorderSide(
                                                      color:
                                                          FlutterFlowTheme.of(
                                                                  context)
                                                              .secondary,
                                                      width: 2.0,
                                                    ),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            8.0),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Expanded(
                                          flex: 3,
                                          child: ClipRRect(
                                            borderRadius:
                                                BorderRadius.circular(8.0),
                                            child: Container(
                                              width: double.infinity,
                                              height: 490.0,
                                              decoration: BoxDecoration(
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .secondaryBackground,
                                                borderRadius:
                                                    BorderRadius.circular(8.0),
                                                border: Border.all(
                                                  color: FlutterFlowTheme.of(
                                                          context)
                                                      .secondaryBackground,
                                                  width: 2.0,
                                                ),
                                              ),
                                              child:
                                                  Builder(builder: (context) {
                                                final _googleMapMarker =
                                                    functions
                                                        .stringtocoordinates(
                                                            widget!.location!);
                                                return FlutterFlowGoogleMap(
                                                  controller: _model
                                                      .googleMapsController,
                                                  onCameraIdle: (latLng) =>
                                                      _model.googleMapsCenter =
                                                          latLng,
                                                  initialLocation: _model
                                                          .googleMapsCenter ??=
                                                      functions
                                                          .stringtocoordinates(
                                                              widget!
                                                                  .location!),
                                                  markers: [
                                                    FlutterFlowMarker(
                                                      _googleMapMarker
                                                          .serialize(),
                                                      _googleMapMarker,
                                                    ),
                                                  ],
                                                  markerColor:
                                                      GoogleMarkerColor.red,
                                                  mapType: MapType.satellite,
                                                  style:
                                                      GoogleMapStyle.standard,
                                                  initialZoom: 14.0,
                                                  allowInteraction: true,
                                                  allowZoom: true,
                                                  showZoomControls: true,
                                                  showLocation: true,
                                                  showCompass: false,
                                                  showMapToolbar: false,
                                                  showTraffic: false,
                                                  centerMapOnMarkerTap: true,
                                                  mapTakesGesturePreference:
                                                      false,
                                                );
                                              }),
                                            ),
                                          ),
                                        ),
                                      ].divide(SizedBox(height: 24.0)),
                                    ),
                                  ),
                                ),
                                Expanded(
                                  flex: 3,
                                  child: Container(
                                    decoration: BoxDecoration(),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Expanded(
                                          flex: 9,
                                          child: Container(
                                            width: double.infinity,
                                            decoration: BoxDecoration(
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .secondaryBackground,
                                              borderRadius:
                                                  BorderRadius.circular(8.0),
                                              border: Border.all(
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .secondaryBackground,
                                                width: 2.0,
                                              ),
                                            ),
                                            child: Row(
                                              mainAxisSize: MainAxisSize.max,
                                              children: [
                                                Expanded(
                                                  flex: 4,
                                                  child: Padding(
                                                    padding:
                                                        EdgeInsets.all(20.0),
                                                    child: Column(
                                                      mainAxisSize:
                                                          MainAxisSize.max,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceEvenly,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        Row(
                                                          mainAxisSize:
                                                              MainAxisSize.max,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceBetween,
                                                          children: [
                                                            Text(
                                                              'Information from the scene',
                                                              style: FlutterFlowTheme
                                                                      .of(context)
                                                                  .bodyMedium
                                                                  .override(
                                                                    font: GoogleFonts
                                                                        .lato(
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w600,
                                                                      fontStyle: FlutterFlowTheme.of(
                                                                              context)
                                                                          .bodyMedium
                                                                          .fontStyle,
                                                                    ),
                                                                    fontSize:
                                                                        20.0,
                                                                    letterSpacing:
                                                                        0.0,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w600,
                                                                    fontStyle: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .fontStyle,
                                                                  ),
                                                            ),
                                                          ],
                                                        ),
                                                        Padding(
                                                          padding:
                                                              EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      0.0,
                                                                      8.0,
                                                                      0.0,
                                                                      0.0),
                                                          child: Text(
                                                            'Requested by: ${(incidentdetailsUsersRow?.currentrole == 'Service Provider') && (incidentcolumnRequestsRow?.paid == false) && (incidentcolumnRequestsRow?.chosenprovider == incidentdetailsUsersRow?.serviceProvider) ? '**********' : incidentcolumnRequestsRow?.requesterName}',
                                                            style: FlutterFlowTheme
                                                                    .of(context)
                                                                .bodyMedium
                                                                .override(
                                                                  font:
                                                                      GoogleFonts
                                                                          .lato(
                                                                    fontWeight: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .fontWeight,
                                                                    fontStyle: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .fontStyle,
                                                                  ),
                                                                  letterSpacing:
                                                                      0.0,
                                                                  fontWeight: FlutterFlowTheme.of(
                                                                          context)
                                                                      .bodyMedium
                                                                      .fontWeight,
                                                                  fontStyle: FlutterFlowTheme.of(
                                                                          context)
                                                                      .bodyMedium
                                                                      .fontStyle,
                                                                ),
                                                          ),
                                                        ),
                                                        Padding(
                                                          padding:
                                                              EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      0.0,
                                                                      8.0,
                                                                      0.0,
                                                                      0.0),
                                                          child: Text(
                                                            'Transporter: ${(incidentdetailsUsersRow?.currentrole == 'Service Provider') && (incidentcolumnRequestsRow?.chosenprovider != incidentdetailsUsersRow?.serviceProvider) ? '**********' : incidentcolumnRequestsRow?.fleetcompanyName}',
                                                            style: FlutterFlowTheme
                                                                    .of(context)
                                                                .bodyMedium
                                                                .override(
                                                                  font:
                                                                      GoogleFonts
                                                                          .lato(
                                                                    fontWeight: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .fontWeight,
                                                                    fontStyle: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .fontStyle,
                                                                  ),
                                                                  letterSpacing:
                                                                      0.0,
                                                                  fontWeight: FlutterFlowTheme.of(
                                                                          context)
                                                                      .bodyMedium
                                                                      .fontWeight,
                                                                  fontStyle: FlutterFlowTheme.of(
                                                                          context)
                                                                      .bodyMedium
                                                                      .fontStyle,
                                                                ),
                                                          ),
                                                        ),
                                                        Padding(
                                                          padding:
                                                              EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      0.0,
                                                                      8.0,
                                                                      0.0,
                                                                      0.0),
                                                          child: Text(
                                                            'Phone number: ${(incidentdetailsUsersRow?.currentrole == 'Service Provider') && (incidentcolumnRequestsRow?.chosenprovider != incidentdetailsUsersRow?.serviceProvider) ? '**********' : incidentcolumnRequestsRow?.requesterPhone}',
                                                            style: FlutterFlowTheme
                                                                    .of(context)
                                                                .bodyMedium
                                                                .override(
                                                                  font:
                                                                      GoogleFonts
                                                                          .lato(
                                                                    fontWeight: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .fontWeight,
                                                                    fontStyle: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .fontStyle,
                                                                  ),
                                                                  letterSpacing:
                                                                      0.0,
                                                                  fontWeight: FlutterFlowTheme.of(
                                                                          context)
                                                                      .bodyMedium
                                                                      .fontWeight,
                                                                  fontStyle: FlutterFlowTheme.of(
                                                                          context)
                                                                      .bodyMedium
                                                                      .fontStyle,
                                                                ),
                                                          ),
                                                        ),
                                                        Padding(
                                                          padding:
                                                              EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      0.0,
                                                                      8.0,
                                                                      0.0,
                                                                      0.0),
                                                          child: Text(
                                                            valueOrDefault<
                                                                String>(
                                                              'Details: ${valueOrDefault<String>(
                                                                incidentcolumnRequestsRow
                                                                    ?.requestDetails,
                                                                '-',
                                                              )}',
                                                              'Details: -',
                                                            ),
                                                            style: FlutterFlowTheme
                                                                    .of(context)
                                                                .bodyMedium
                                                                .override(
                                                                  font:
                                                                      GoogleFonts
                                                                          .lato(
                                                                    fontWeight: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .fontWeight,
                                                                    fontStyle: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .fontStyle,
                                                                  ),
                                                                  letterSpacing:
                                                                      0.0,
                                                                  fontWeight: FlutterFlowTheme.of(
                                                                          context)
                                                                      .bodyMedium
                                                                      .fontWeight,
                                                                  fontStyle: FlutterFlowTheme.of(
                                                                          context)
                                                                      .bodyMedium
                                                                      .fontStyle,
                                                                ),
                                                          ),
                                                        ),
                                                        Padding(
                                                          padding:
                                                              EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      0.0,
                                                                      8.0,
                                                                      0.0,
                                                                      0.0),
                                                          child: Text(
                                                            valueOrDefault<
                                                                String>(
                                                              'Address: ${(incidentdetailsUsersRow?.currentrole == 'Service Provider') && (incidentcolumnRequestsRow?.chosenprovider != incidentdetailsUsersRow?.serviceProvider) ? '**********' : incidentcolumnRequestsRow?.address}',
                                                              'Details: -',
                                                            ),
                                                            style: FlutterFlowTheme
                                                                    .of(context)
                                                                .bodyMedium
                                                                .override(
                                                                  font:
                                                                      GoogleFonts
                                                                          .lato(
                                                                    fontWeight: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .fontWeight,
                                                                    fontStyle: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .fontStyle,
                                                                  ),
                                                                  letterSpacing:
                                                                      0.0,
                                                                  fontWeight: FlutterFlowTheme.of(
                                                                          context)
                                                                      .bodyMedium
                                                                      .fontWeight,
                                                                  fontStyle: FlutterFlowTheme.of(
                                                                          context)
                                                                      .bodyMedium
                                                                      .fontStyle,
                                                                ),
                                                          ),
                                                        ),
                                                        Padding(
                                                          padding:
                                                              EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      0.0,
                                                                      8.0,
                                                                      0.0,
                                                                      0.0),
                                                          child: Text(
                                                            valueOrDefault<
                                                                String>(
                                                              'Coordinates: ${(incidentdetailsUsersRow?.currentrole == 'Service Provider') && (incidentcolumnRequestsRow?.chosenprovider != incidentdetailsUsersRow?.serviceProvider) ? '**********' : incidentcolumnRequestsRow?.requesterLocation}',
                                                              'Details: -',
                                                            ),
                                                            style: FlutterFlowTheme
                                                                    .of(context)
                                                                .bodyMedium
                                                                .override(
                                                                  font:
                                                                      GoogleFonts
                                                                          .lato(
                                                                    fontWeight: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .fontWeight,
                                                                    fontStyle: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .fontStyle,
                                                                  ),
                                                                  letterSpacing:
                                                                      0.0,
                                                                  fontWeight: FlutterFlowTheme.of(
                                                                          context)
                                                                      .bodyMedium
                                                                      .fontWeight,
                                                                  fontStyle: FlutterFlowTheme.of(
                                                                          context)
                                                                      .bodyMedium
                                                                      .fontStyle,
                                                                ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                                Expanded(
                                                  flex: 3,
                                                  child: Padding(
                                                    padding:
                                                        EdgeInsets.all(20.0),
                                                    child: Builder(
                                                      builder: (context) {
                                                        final scenepics =
                                                            incidentcolumnRequestsRow
                                                                    ?.images
                                                                    ?.toList() ??
                                                                [];
                                                        if (scenepics.isEmpty) {
                                                          return EmptyimagesWidget();
                                                        }

                                                        return GridView.builder(
                                                          padding:
                                                              EdgeInsets.zero,
                                                          gridDelegate:
                                                              SliverGridDelegateWithFixedCrossAxisCount(
                                                            crossAxisCount: 3,
                                                            crossAxisSpacing:
                                                                10.0,
                                                            mainAxisSpacing:
                                                                10.0,
                                                            childAspectRatio:
                                                                1.0,
                                                          ),
                                                          scrollDirection:
                                                              Axis.vertical,
                                                          itemCount:
                                                              scenepics.length,
                                                          itemBuilder: (context,
                                                              scenepicsIndex) {
                                                            final scenepicsItem =
                                                                scenepics[
                                                                    scenepicsIndex];
                                                            return InkWell(
                                                              splashColor: Colors
                                                                  .transparent,
                                                              focusColor: Colors
                                                                  .transparent,
                                                              hoverColor: Colors
                                                                  .transparent,
                                                              highlightColor:
                                                                  Colors
                                                                      .transparent,
                                                              onTap: () async {
                                                                await Navigator
                                                                    .push(
                                                                  context,
                                                                  PageTransition(
                                                                    type: PageTransitionType
                                                                        .fade,
                                                                    child:
                                                                        FlutterFlowExpandedImageView(
                                                                      image:
                                                                          OctoImage(
                                                                        placeholderBuilder:
                                                                            (_) =>
                                                                                SizedBox.expand(
                                                                          child:
                                                                              Image(
                                                                            image:
                                                                                BlurHashImage('LBS~q=-;?^-;?Hj[S3fQ?^j[DOay'),
                                                                            fit:
                                                                                BoxFit.cover,
                                                                          ),
                                                                        ),
                                                                        image:
                                                                            NetworkImage(
                                                                          getCORSProxyUrl(
                                                                            valueOrDefault<String>(
                                                                              scenepicsItem,
                                                                              'https://hkltjfqbbpmdboobsonx.supabase.co/storage/v1/object/public/files//Gova%20logo.png',
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        fit: BoxFit
                                                                            .contain,
                                                                      ),
                                                                      allowRotation:
                                                                          false,
                                                                      tag: valueOrDefault<
                                                                          String>(
                                                                        scenepicsItem,
                                                                        'https://hkltjfqbbpmdboobsonx.supabase.co/storage/v1/object/public/files//Gova%20logo.png' +
                                                                            '$scenepicsIndex',
                                                                      ),
                                                                      useHeroAnimation:
                                                                          true,
                                                                    ),
                                                                  ),
                                                                );
                                                              },
                                                              child: Hero(
                                                                tag:
                                                                    valueOrDefault<
                                                                        String>(
                                                                  scenepicsItem,
                                                                  'https://hkltjfqbbpmdboobsonx.supabase.co/storage/v1/object/public/files//Gova%20logo.png' +
                                                                      '$scenepicsIndex',
                                                                ),
                                                                transitionOnUserGestures:
                                                                    true,
                                                                child:
                                                                    ClipRRect(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              8.0),
                                                                  child:
                                                                      OctoImage(
                                                                    placeholderBuilder: (_) =>
                                                                        SizedBox
                                                                            .expand(
                                                                      child:
                                                                          Image(
                                                                        image: BlurHashImage(
                                                                            'LBS~q=-;?^-;?Hj[S3fQ?^j[DOay'),
                                                                        fit: BoxFit
                                                                            .cover,
                                                                      ),
                                                                    ),
                                                                    image:
                                                                        NetworkImage(
                                                                      getCORSProxyUrl(
                                                                        valueOrDefault<
                                                                            String>(
                                                                          scenepicsItem,
                                                                          'https://hkltjfqbbpmdboobsonx.supabase.co/storage/v1/object/public/files//Gova%20logo.png',
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    width: 52.0,
                                                                    height:
                                                                        52.0,
                                                                    fit: BoxFit
                                                                        .cover,
                                                                  ),
                                                                ),
                                                              ),
                                                            );
                                                          },
                                                        );
                                                      },
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Expanded(
                                          flex: 14,
                                          child: Container(
                                            width: double.infinity,
                                            decoration: BoxDecoration(
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .secondaryBackground,
                                              borderRadius:
                                                  BorderRadius.circular(12.0),
                                            ),
                                            child: Stack(
                                              children: [
                                                if (incidentdetailsUsersRow
                                                        ?.currentrole ==
                                                    'Fleet Manager')
                                                  Padding(
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(
                                                                20.0,
                                                                20.0,
                                                                20.0,
                                                                0.0),
                                                    child:
                                                        SingleChildScrollView(
                                                      primary: false,
                                                      child: Column(
                                                        mainAxisSize:
                                                            MainAxisSize.max,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          Row(
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .max,
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .spaceBetween,
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            children: [
                                                              Flexible(
                                                                child: Column(
                                                                  mainAxisSize:
                                                                      MainAxisSize
                                                                          .max,
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    Text(
                                                                      'Service Provider Details',
                                                                      style: FlutterFlowTheme.of(
                                                                              context)
                                                                          .bodyMedium
                                                                          .override(
                                                                            font:
                                                                                GoogleFonts.lato(
                                                                              fontWeight: FontWeight.w600,
                                                                              fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                            ),
                                                                            fontSize:
                                                                                20.0,
                                                                            letterSpacing:
                                                                                0.0,
                                                                            fontWeight:
                                                                                FontWeight.w600,
                                                                            fontStyle:
                                                                                FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                          ),
                                                                    ),
                                                                    if ((incidentdetailsUsersRow?.currentrole ==
                                                                            'Fleet Manager') &&
                                                                        ((incidentcolumnRequestsRow?.status ==
                                                                                'Sent to fleet manager') ||
                                                                            (incidentcolumnRequestsRow?.status ==
                                                                                'Viewed by fleet manager')))
                                                                      Text(
                                                                        'Below are the available service providers in the area',
                                                                        style: FlutterFlowTheme.of(context)
                                                                            .bodyMedium
                                                                            .override(
                                                                              font: GoogleFonts.lato(
                                                                                fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                                fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                              ),
                                                                              fontSize: 14.0,
                                                                              letterSpacing: 0.0,
                                                                              fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                              fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                            ),
                                                                      ),
                                                                    if ((incidentcolumnRequestsRow?.status ==
                                                                            'Sent to service providers') ||
                                                                        (incidentcolumnRequestsRow?.status ==
                                                                            'New service provider needed'))
                                                                      Text(
                                                                        valueOrDefault<
                                                                            String>(
                                                                          incidentcolumnRequestsRow?.status == 'Sent to service providers'
                                                                              ? 'This incident has been sent out to the nearby service providers.'
                                                                              : 'This incident has been sent out to the nearby service providers.',
                                                                          'This incident has been sent out to the nearby service providers.',
                                                                        ),
                                                                        style: FlutterFlowTheme.of(context)
                                                                            .bodyMedium
                                                                            .override(
                                                                              font: GoogleFonts.lato(
                                                                                fontWeight: FontWeight.w600,
                                                                                fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                              ),
                                                                              color: FlutterFlowTheme.of(context).secondary,
                                                                              fontSize: 14.0,
                                                                              letterSpacing: 0.0,
                                                                              fontWeight: FontWeight.w600,
                                                                              fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                            ),
                                                                      ),
                                                                  ].divide(SizedBox(
                                                                      height:
                                                                          4.0)),
                                                                ),
                                                              ),
                                                              if (((_model
                                                                              .cancellation
                                                                              ?.id !=
                                                                          null) &&
                                                                      (_model.cancellation
                                                                              ?.status !=
                                                                          'Successful') &&
                                                                      (incidentcolumnRequestsRow
                                                                              ?.cancelled ==
                                                                          null)) ||
                                                                  ((_model.cancellation
                                                                              ?.id ==
                                                                          null) &&
                                                                      (incidentcolumnRequestsRow
                                                                              ?.cancelled ==
                                                                          null)))
                                                                FFButtonWidget(
                                                                  onPressed:
                                                                      () async {
                                                                    await showModalBottomSheet(
                                                                      isScrollControlled:
                                                                          true,
                                                                      backgroundColor:
                                                                          Colors
                                                                              .transparent,
                                                                      enableDrag:
                                                                          false,
                                                                      context:
                                                                          context,
                                                                      builder:
                                                                          (context) {
                                                                        return WebViewAware(
                                                                          child:
                                                                              GestureDetector(
                                                                            onTap:
                                                                                () {
                                                                              FocusScope.of(context).unfocus();
                                                                              FocusManager.instance.primaryFocus?.unfocus();
                                                                            },
                                                                            child:
                                                                                Padding(
                                                                              padding: MediaQuery.viewInsetsOf(context),
                                                                              child: IncidentbiddersWidget(
                                                                                incident: incidentcolumnRequestsRow!,
                                                                                refresh: () async {
                                                                                  await IncidentSentToProvidersCall.call(
                                                                                    driverPhone: incidentcolumnRequestsRow?.requesterPhone,
                                                                                  );

                                                                                  safeSetState(() => _model.requestCompleter = null);
                                                                                },
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        );
                                                                      },
                                                                    ).then((value) =>
                                                                        safeSetState(
                                                                            () {}));
                                                                  },
                                                                  text:
                                                                      'View all providers',
                                                                  options:
                                                                      FFButtonOptions(
                                                                    width:
                                                                        200.0,
                                                                    height:
                                                                        52.0,
                                                                    padding: EdgeInsetsDirectional
                                                                        .fromSTEB(
                                                                            16.0,
                                                                            0.0,
                                                                            16.0,
                                                                            0.0),
                                                                    iconPadding:
                                                                        EdgeInsetsDirectional.fromSTEB(
                                                                            0.0,
                                                                            0.0,
                                                                            0.0,
                                                                            0.0),
                                                                    color: FlutterFlowTheme.of(
                                                                            context)
                                                                        .primaryText,
                                                                    textStyle: FlutterFlowTheme.of(
                                                                            context)
                                                                        .titleSmall
                                                                        .override(
                                                                          font:
                                                                              GoogleFonts.lato(
                                                                            fontWeight:
                                                                                FlutterFlowTheme.of(context).titleSmall.fontWeight,
                                                                            fontStyle:
                                                                                FlutterFlowTheme.of(context).titleSmall.fontStyle,
                                                                          ),
                                                                          color:
                                                                              FlutterFlowTheme.of(context).secondaryBackground,
                                                                          fontSize:
                                                                              14.0,
                                                                          letterSpacing:
                                                                              0.0,
                                                                          fontWeight: FlutterFlowTheme.of(context)
                                                                              .titleSmall
                                                                              .fontWeight,
                                                                          fontStyle: FlutterFlowTheme.of(context)
                                                                              .titleSmall
                                                                              .fontStyle,
                                                                        ),
                                                                    elevation:
                                                                        2.0,
                                                                    borderSide:
                                                                        BorderSide(
                                                                      color: FlutterFlowTheme.of(
                                                                              context)
                                                                          .primaryText,
                                                                      width:
                                                                          3.0,
                                                                    ),
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            8.0),
                                                                  ),
                                                                ),
                                                            ].divide(SizedBox(
                                                                width: 8.0)),
                                                          ),
                                                          Column(
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .max,
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            children: [
                                                              Stack(
                                                                children: [
                                                                  if (incidentcolumnRequestsRow
                                                                          ?.paid ==
                                                                      false)
                                                                    FFButtonWidget(
                                                                      onPressed:
                                                                          () async {
                                                                        if ((incidentcolumnRequestsRow?.vehicleVin != null && incidentcolumnRequestsRow?.vehicleVin != '') &&
                                                                            (incidentcolumnRequestsRow?.vehicleVin !=
                                                                                'N/A')) {
                                                                          if (((_model.cancellation?.id != null) && (_model.cancellation?.status != 'Successful')) ||
                                                                              (_model.cancellation?.id == null)) {
                                                                            _model.findfleetcompany =
                                                                                await TransportersTable().queryRows(
                                                                              queryFn: (q) => q.eqOrNull(
                                                                                'id',
                                                                                incidentdetailsUsersRow?.transporterId,
                                                                              ),
                                                                            );
                                                                            _model.initiatetransaction =
                                                                                await InitiateCall.call(
                                                                              amount: 15000,
                                                                              ref: 'GOVA${dateTimeFormat("ddMMyHHmmss", getCurrentTimestamp)}',
                                                                              userEmail: incidentdetailsUsersRow?.email,
                                                                            );

                                                                            if ((_model.initiatetransaction?.succeeded ??
                                                                                true)) {
                                                                              await showModalBottomSheet(
                                                                                isScrollControlled: true,
                                                                                backgroundColor: Colors.transparent,
                                                                                enableDrag: false,
                                                                                context: context,
                                                                                builder: (context) {
                                                                                  return WebViewAware(
                                                                                    child: GestureDetector(
                                                                                      onTap: () {
                                                                                        FocusScope.of(context).unfocus();
                                                                                        FocusManager.instance.primaryFocus?.unfocus();
                                                                                      },
                                                                                      child: Padding(
                                                                                        padding: MediaQuery.viewInsetsOf(context),
                                                                                        child: CardPmtWidget(
                                                                                          link: InitiateCall.url(
                                                                                            (_model.initiatetransaction?.jsonBody ?? ''),
                                                                                          )!,
                                                                                          ref: InitiateCall.ref(
                                                                                            (_model.initiatetransaction?.jsonBody ?? ''),
                                                                                          )!,
                                                                                          accesscode: InitiateCall.accesscode(
                                                                                            (_model.initiatetransaction?.jsonBody ?? ''),
                                                                                          )!,
                                                                                          fleetcompany: incidentcolumnRequestsRow!.fleetcompanyId!,
                                                                                          refresh: () async {
                                                                                            _model.findallserviceproviders = await ServiceprovidersTable().queryRows(
                                                                                              queryFn: (q) => q.or("truck_categories.cs.{${incidentcolumnRequestsRow?.serviceRequested}}, trailer_categories.cs.{${incidentcolumnRequestsRow?.serviceRequested}}"),
                                                                                            );
                                                                                            if (_model.findallserviceproviders!.where((e) => functions.distance(functions.stringtocoordinates(incidentcolumnRequestsRow!.requesterLocation!), functions.stringtocoordinates(e.coordinates!)) < 80000).toList().isNotEmpty) {
                                                                                              await Future.wait([
                                                                                                Future(() async {
                                                                                                  _model.findsuperadminsnearby = await UsersTable().queryRows(
                                                                                                    queryFn: (q) => q
                                                                                                        .eqOrNull(
                                                                                                          'currentrole',
                                                                                                          'Service Provider',
                                                                                                        )
                                                                                                        .inFilterOrNull(
                                                                                                          'service_provider',
                                                                                                          _model.findallserviceproviders?.where((e) => functions.distance(functions.stringtocoordinates(incidentcolumnRequestsRow!.requesterLocation!), functions.stringtocoordinates(e.coordinates!)) < 80000).toList()?.map((e) => e.id).toList(),
                                                                                                        ),
                                                                                                  );
                                                                                                  _model.findsuperadminsFb1 = await queryUsersRecordOnce(
                                                                                                    queryBuilder: (usersRecord) => usersRecord.whereIn('uid', _model.findsuperadminsnearby?.map((e) => e.uid).withoutNulls.toList()),
                                                                                                  );
                                                                                                  triggerPushNotification(
                                                                                                    notificationTitle: 'New incident nearby!',
                                                                                                    notificationText: '${incidentcolumnRequestsRow?.serviceRequested} services have been requested by ${incidentcolumnRequestsRow?.fleetcompanyName} within 100km of your main location.',
                                                                                                    notificationImageUrl: incidentcolumnRequestsRow?.images?.firstOrNull,
                                                                                                    notificationSound: 'default',
                                                                                                    userRefs: _model.findsuperadminsFb1!.map((e) => e.reference).toList(),
                                                                                                    initialPageName: 'dashboard',
                                                                                                    parameterData: {},
                                                                                                  );
                                                                                                }),
                                                                                                Future(() async {
                                                                                                  _model.finddriver1 = await queryUsersRecordOnce(
                                                                                                    queryBuilder: (usersRecord) => usersRecord.where(
                                                                                                      'uid',
                                                                                                      isEqualTo: incidentcolumnRequestsRow?.requesterUid,
                                                                                                    ),
                                                                                                    singleRecord: true,
                                                                                                  ).then((s) => s.firstOrNull);
                                                                                                  triggerPushNotification(
                                                                                                    notificationTitle: 'Incident Update',
                                                                                                    notificationText: 'Your fleet manager has sent your incident request to service providers nearby. You will be notified when a service provider is selected and a technician is assigned.',
                                                                                                    notificationSound: 'default',
                                                                                                    userRefs: [
                                                                                                      _model.finddriver1!.reference
                                                                                                    ],
                                                                                                    initialPageName: 'request_details',
                                                                                                    parameterData: {
                                                                                                      'role': 'Driver',
                                                                                                      'requestid': widget!.requestid,
                                                                                                      'completed': false,
                                                                                                    },
                                                                                                  );
                                                                                                }),
                                                                                              ]);
                                                                                              await IncidentSentToProvidersCall.call(
                                                                                                driverPhone: incidentcolumnRequestsRow?.requesterPhone,
                                                                                              );

                                                                                              await RequestsTable().update(
                                                                                                data: {
                                                                                                  'status': 'Sent to service providers',
                                                                                                  'provider_sentto': _model.findallserviceproviders?.where((e) => functions.distance(functions.stringtocoordinates(incidentcolumnRequestsRow!.requesterLocation!), functions.stringtocoordinates(e.coordinates!)) < 80000).toList()?.map((e) => e.id).toList(),
                                                                                                  'bidsopen': true,
                                                                                                  'paid': true,
                                                                                                },
                                                                                                matchingRows: (rows) => rows.eqOrNull(
                                                                                                  'id',
                                                                                                  incidentcolumnRequestsRow?.id,
                                                                                                ),
                                                                                              );
                                                                                              _model.selectedproviders = [];
                                                                                              _model.selectedproviderids = [];
                                                                                              safeSetState(() {});
                                                                                              safeSetState(() => _model.requestCompleter = null);
                                                                                              await showDialog(
                                                                                                context: context,
                                                                                                builder: (alertDialogContext) {
                                                                                                  return WebViewAware(
                                                                                                    child: AlertDialog(
                                                                                                      title: Text('Thank you for your payment  ✅'),
                                                                                                      content: Text('Thank you for your payment. Your job has been shared with local service providers who will now place their bids.'),
                                                                                                      actions: [
                                                                                                        TextButton(
                                                                                                          onPressed: () => Navigator.pop(alertDialogContext),
                                                                                                          child: Text('Ok'),
                                                                                                        ),
                                                                                                      ],
                                                                                                    ),
                                                                                                  );
                                                                                                },
                                                                                              );
                                                                                            } else {
                                                                                              await showDialog(
                                                                                                context: context,
                                                                                                builder: (alertDialogContext) {
                                                                                                  return WebViewAware(
                                                                                                    child: AlertDialog(
                                                                                                      title: Text('There are no service providers in the area'),
                                                                                                      actions: [
                                                                                                        TextButton(
                                                                                                          onPressed: () => Navigator.pop(alertDialogContext),
                                                                                                          child: Text('Ok'),
                                                                                                        ),
                                                                                                      ],
                                                                                                    ),
                                                                                                  );
                                                                                                },
                                                                                              );
                                                                                            }
                                                                                          },
                                                                                        ),
                                                                                      ),
                                                                                    ),
                                                                                  );
                                                                                },
                                                                              ).then((value) => safeSetState(() {}));
                                                                            } else {
                                                                              await showDialog(
                                                                                context: context,
                                                                                builder: (alertDialogContext) {
                                                                                  return WebViewAware(
                                                                                    child: AlertDialog(
                                                                                      title: Text('Payment failed.'),
                                                                                      content: Text('Please try again or contact GOVA support.'),
                                                                                      actions: [
                                                                                        TextButton(
                                                                                          onPressed: () => Navigator.pop(alertDialogContext),
                                                                                          child: Text('Ok'),
                                                                                        ),
                                                                                      ],
                                                                                    ),
                                                                                  );
                                                                                },
                                                                              );
                                                                            }
                                                                          } else {
                                                                            await showDialog(
                                                                              context: context,
                                                                              builder: (alertDialogContext) {
                                                                                return WebViewAware(
                                                                                  child: AlertDialog(
                                                                                    title: Text('Action not permitted'),
                                                                                    content: Text('This incident has been cancelled'),
                                                                                    actions: [
                                                                                      TextButton(
                                                                                        onPressed: () => Navigator.pop(alertDialogContext),
                                                                                        child: Text('Ok'),
                                                                                      ),
                                                                                    ],
                                                                                  ),
                                                                                );
                                                                              },
                                                                            );
                                                                          }
                                                                        } else {
                                                                          await showModalBottomSheet(
                                                                            isScrollControlled:
                                                                                true,
                                                                            backgroundColor:
                                                                                Colors.transparent,
                                                                            enableDrag:
                                                                                false,
                                                                            context:
                                                                                context,
                                                                            builder:
                                                                                (context) {
                                                                              return WebViewAware(
                                                                                child: GestureDetector(
                                                                                  onTap: () {
                                                                                    FocusScope.of(context).unfocus();
                                                                                    FocusManager.instance.primaryFocus?.unfocus();
                                                                                  },
                                                                                  child: Padding(
                                                                                    padding: MediaQuery.viewInsetsOf(context),
                                                                                    child: AddDetailsWidget(
                                                                                      incident: widget!.requestid,
                                                                                      refresh: () async {
                                                                                        safeSetState(() => _model.requestCompleter = null);
                                                                                      },
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              );
                                                                            },
                                                                          ).then((value) =>
                                                                              safeSetState(() {}));
                                                                        }

                                                                        safeSetState(
                                                                            () {});
                                                                      },
                                                                      text:
                                                                          'Send to nearby service providers',
                                                                      icon:
                                                                          Icon(
                                                                        Icons
                                                                            .send_sharp,
                                                                        size:
                                                                            20.0,
                                                                      ),
                                                                      options:
                                                                          FFButtonOptions(
                                                                        width: double
                                                                            .infinity,
                                                                        height:
                                                                            52.0,
                                                                        padding: EdgeInsetsDirectional.fromSTEB(
                                                                            16.0,
                                                                            0.0,
                                                                            16.0,
                                                                            0.0),
                                                                        iconPadding: EdgeInsetsDirectional.fromSTEB(
                                                                            0.0,
                                                                            0.0,
                                                                            0.0,
                                                                            0.0),
                                                                        color: FlutterFlowTheme.of(context)
                                                                            .primary,
                                                                        textStyle: FlutterFlowTheme.of(context)
                                                                            .titleSmall
                                                                            .override(
                                                                              font: GoogleFonts.lato(
                                                                                fontWeight: FlutterFlowTheme.of(context).titleSmall.fontWeight,
                                                                                fontStyle: FlutterFlowTheme.of(context).titleSmall.fontStyle,
                                                                              ),
                                                                              color: Colors.white,
                                                                              fontSize: 14.0,
                                                                              letterSpacing: 0.0,
                                                                              fontWeight: FlutterFlowTheme.of(context).titleSmall.fontWeight,
                                                                              fontStyle: FlutterFlowTheme.of(context).titleSmall.fontStyle,
                                                                            ),
                                                                        elevation:
                                                                            2.0,
                                                                        borderRadius:
                                                                            BorderRadius.circular(8.0),
                                                                      ),
                                                                    ),
                                                                  if ((incidentcolumnRequestsRow
                                                                              ?.chosenprovider !=
                                                                          null) &&
                                                                      (incidentcolumnRequestsRow
                                                                              ?.status !=
                                                                          'Completed'))
                                                                    Align(
                                                                      alignment: AlignmentDirectional(
                                                                          -0.14,
                                                                          0.37),
                                                                      child:
                                                                          FFButtonWidget(
                                                                        onPressed:
                                                                            () async {
                                                                          if (((_model.cancellation?.id != null) && (_model.cancellation?.status != 'Successful')) ||
                                                                              (_model.cancellation?.id == null)) {
                                                                            await showModalBottomSheet(
                                                                              isScrollControlled: true,
                                                                              backgroundColor: Colors.transparent,
                                                                              enableDrag: false,
                                                                              context: context,
                                                                              builder: (context) {
                                                                                return WebViewAware(
                                                                                  child: GestureDetector(
                                                                                    onTap: () {
                                                                                      FocusScope.of(context).unfocus();
                                                                                      FocusManager.instance.primaryFocus?.unfocus();
                                                                                    },
                                                                                    child: Padding(
                                                                                      padding: MediaQuery.viewInsetsOf(context),
                                                                                      child: IncidentbiddersWidget(
                                                                                        incident: incidentcolumnRequestsRow!,
                                                                                        refresh: () async {
                                                                                          safeSetState(() => _model.requestCompleter = null);
                                                                                          await _model.waitForRequestCompleted();
                                                                                        },
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                );
                                                                              },
                                                                            ).then((value) =>
                                                                                safeSetState(() {}));
                                                                          } else {
                                                                            await showDialog(
                                                                              context: context,
                                                                              builder: (alertDialogContext) {
                                                                                return WebViewAware(
                                                                                  child: AlertDialog(
                                                                                    title: Text('Action not permitted'),
                                                                                    content: Text('This incident was cancelled.'),
                                                                                    actions: [
                                                                                      TextButton(
                                                                                        onPressed: () => Navigator.pop(alertDialogContext),
                                                                                        child: Text('Ok'),
                                                                                      ),
                                                                                    ],
                                                                                  ),
                                                                                );
                                                                              },
                                                                            );
                                                                          }
                                                                        },
                                                                        text:
                                                                            'Change provider',
                                                                        options:
                                                                            FFButtonOptions(
                                                                          width:
                                                                              double.infinity,
                                                                          height:
                                                                              52.0,
                                                                          padding: EdgeInsetsDirectional.fromSTEB(
                                                                              16.0,
                                                                              0.0,
                                                                              16.0,
                                                                              0.0),
                                                                          iconPadding: EdgeInsetsDirectional.fromSTEB(
                                                                              0.0,
                                                                              0.0,
                                                                              0.0,
                                                                              0.0),
                                                                          color:
                                                                              FlutterFlowTheme.of(context).primary,
                                                                          textStyle: FlutterFlowTheme.of(context)
                                                                              .titleSmall
                                                                              .override(
                                                                                font: GoogleFonts.lato(
                                                                                  fontWeight: FlutterFlowTheme.of(context).titleSmall.fontWeight,
                                                                                  fontStyle: FlutterFlowTheme.of(context).titleSmall.fontStyle,
                                                                                ),
                                                                                color: Colors.white,
                                                                                fontSize: 14.0,
                                                                                letterSpacing: 0.0,
                                                                                fontWeight: FlutterFlowTheme.of(context).titleSmall.fontWeight,
                                                                                fontStyle: FlutterFlowTheme.of(context).titleSmall.fontStyle,
                                                                              ),
                                                                          elevation:
                                                                              2.0,
                                                                          borderRadius:
                                                                              BorderRadius.circular(8.0),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                ],
                                                              ),
                                                              if (incidentcolumnRequestsRow
                                                                      ?.paid ==
                                                                  false)
                                                                Padding(
                                                                  padding: EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          8.0,
                                                                          0.0,
                                                                          0.0),
                                                                  child: Text(
                                                                    'Click the button above to send this incident to nearby service providers. You will be charged a fee of R150.00 ',
                                                                    style: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .override(
                                                                          font:
                                                                              GoogleFonts.lato(
                                                                            fontWeight:
                                                                                FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                            fontStyle:
                                                                                FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                          ),
                                                                          color:
                                                                              Color(0xFF737E83),
                                                                          fontSize:
                                                                              12.0,
                                                                          letterSpacing:
                                                                              0.0,
                                                                          fontWeight: FlutterFlowTheme.of(context)
                                                                              .bodyMedium
                                                                              .fontWeight,
                                                                          fontStyle: FlutterFlowTheme.of(context)
                                                                              .bodyMedium
                                                                              .fontStyle,
                                                                        ),
                                                                  ),
                                                                ),
                                                            ],
                                                          ),
                                                          Stack(
                                                            children: [
                                                              if ((incidentcolumnRequestsRow!
                                                                      .providersTendered
                                                                      .isNotEmpty) &&
                                                                  (incidentcolumnRequestsRow
                                                                          ?.chosenprovider ==
                                                                      null) &&
                                                                  (incidentdetailsUsersRow
                                                                          ?.currentrole ==
                                                                      'Fleet Manager'))
                                                                Container(
                                                                  decoration:
                                                                      BoxDecoration(),
                                                                  child: FutureBuilder<
                                                                      List<
                                                                          ServiceprovidersRow>>(
                                                                    future: ServiceprovidersTable()
                                                                        .queryRows(
                                                                      queryFn:
                                                                          (q) =>
                                                                              q.inFilterOrNull(
                                                                        'id',
                                                                        incidentcolumnRequestsRow
                                                                            ?.providersTendered,
                                                                      ),
                                                                    ),
                                                                    builder:
                                                                        (context,
                                                                            snapshot) {
                                                                      // Customize what your widget looks like when it's loading.
                                                                      if (!snapshot
                                                                          .hasData) {
                                                                        return Center(
                                                                          child:
                                                                              SizedBox(
                                                                            width:
                                                                                50.0,
                                                                            height:
                                                                                50.0,
                                                                            child:
                                                                                CircularProgressIndicator(
                                                                              valueColor: AlwaysStoppedAnimation<Color>(
                                                                                FlutterFlowTheme.of(context).primary,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        );
                                                                      }
                                                                      List<ServiceprovidersRow>
                                                                          rowServiceprovidersRowList =
                                                                          snapshot
                                                                              .data!;

                                                                      return SingleChildScrollView(
                                                                        scrollDirection:
                                                                            Axis.horizontal,
                                                                        child:
                                                                            Row(
                                                                          mainAxisSize:
                                                                              MainAxisSize.max,
                                                                          children: List.generate(
                                                                              rowServiceprovidersRowList.length,
                                                                              (rowIndex) {
                                                                            final rowServiceprovidersRow =
                                                                                rowServiceprovidersRowList[rowIndex];
                                                                            return Padding(
                                                                              padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 4.0),
                                                                              child: Container(
                                                                                width: 280.0,
                                                                                decoration: BoxDecoration(
                                                                                  color: Colors.white,
                                                                                  boxShadow: [
                                                                                    BoxShadow(
                                                                                      color: Color(0xFFF1F4F8),
                                                                                      offset: Offset(
                                                                                        0.0,
                                                                                        1.0,
                                                                                      ),
                                                                                    )
                                                                                  ],
                                                                                  borderRadius: BorderRadius.circular(8.0),
                                                                                  border: Border.all(
                                                                                    color: FlutterFlowTheme.of(context).primaryBackground,
                                                                                    width: 2.0,
                                                                                  ),
                                                                                ),
                                                                                child: Padding(
                                                                                  padding: EdgeInsets.all(16.0),
                                                                                  child: Column(
                                                                                    mainAxisSize: MainAxisSize.max,
                                                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                                                    children: [
                                                                                      ClipRRect(
                                                                                        borderRadius: BorderRadius.circular(8.0),
                                                                                        child: OctoImage(
                                                                                          placeholderBuilder: (_) => SizedBox.expand(
                                                                                            child: Image(
                                                                                              image: BlurHashImage('LBS~q=-;?^-;?Hj[S3fQ?^j[DOay'),
                                                                                              fit: BoxFit.cover,
                                                                                            ),
                                                                                          ),
                                                                                          image: NetworkImage(
                                                                                            getCORSProxyUrl(
                                                                                              valueOrDefault<String>(
                                                                                                rowServiceprovidersRow.logo,
                                                                                                'https://hkltjfqbbpmdboobsonx.supabase.co/storage/v1/object/public/files//Gova%20logo.png',
                                                                                              ),
                                                                                            ),
                                                                                          ),
                                                                                          width: 44.0,
                                                                                          height: 44.0,
                                                                                          fit: BoxFit.cover,
                                                                                        ),
                                                                                      ),
                                                                                      Padding(
                                                                                        padding: EdgeInsetsDirectional.fromSTEB(0.0, 12.0, 0.0, 0.0),
                                                                                        child: Text(
                                                                                          valueOrDefault<String>(
                                                                                            incidentcolumnRequestsRow!.paid! ? rowServiceprovidersRow.companyName : '**********',
                                                                                            'N/A',
                                                                                          ),
                                                                                          textAlign: TextAlign.center,
                                                                                          style: FlutterFlowTheme.of(context).headlineSmall.override(
                                                                                                font: GoogleFonts.lato(
                                                                                                  fontWeight: FontWeight.w600,
                                                                                                  fontStyle: FlutterFlowTheme.of(context).headlineSmall.fontStyle,
                                                                                                ),
                                                                                                color: Color(0xFF14181B),
                                                                                                fontSize: 16.0,
                                                                                                letterSpacing: 0.0,
                                                                                                fontWeight: FontWeight.w600,
                                                                                                fontStyle: FlutterFlowTheme.of(context).headlineSmall.fontStyle,
                                                                                              ),
                                                                                        ),
                                                                                      ),
                                                                                      Padding(
                                                                                        padding: EdgeInsetsDirectional.fromSTEB(0.0, 4.0, 0.0, 4.0),
                                                                                        child: Text(
                                                                                          'Distance from incident: ~${formatNumber(
                                                                                            functions.distance(functions.stringtocoordinates(incidentcolumnRequestsRow!.requesterLocation!), functions.stringtocoordinates(rowServiceprovidersRow.coordinates!)),
                                                                                            formatType: FormatType.custom,
                                                                                            format: '0 km',
                                                                                            locale: '',
                                                                                          )}',
                                                                                          textAlign: TextAlign.center,
                                                                                          style: FlutterFlowTheme.of(context).labelMedium.override(
                                                                                                font: GoogleFonts.lato(
                                                                                                  fontWeight: FontWeight.w600,
                                                                                                  fontStyle: FlutterFlowTheme.of(context).labelMedium.fontStyle,
                                                                                                ),
                                                                                                color: Color(0xFF4B39EF),
                                                                                                fontSize: 14.0,
                                                                                                letterSpacing: 0.0,
                                                                                                fontWeight: FontWeight.w600,
                                                                                                fontStyle: FlutterFlowTheme.of(context).labelMedium.fontStyle,
                                                                                              ),
                                                                                        ),
                                                                                      ),
                                                                                      if (incidentcolumnRequestsRow?.paid ?? true)
                                                                                        Padding(
                                                                                          padding: EdgeInsetsDirectional.fromSTEB(0.0, 8.0, 0.0, 8.0),
                                                                                          child: Row(
                                                                                            mainAxisSize: MainAxisSize.max,
                                                                                            children: [
                                                                                              Expanded(
                                                                                                child: FFButtonWidget(
                                                                                                  onPressed: () async {
                                                                                                    _model.getallreviews = await ReviewsServiceprovidersTable().queryRows(
                                                                                                      queryFn: (q) => q.eqOrNull(
                                                                                                        'service_provider',
                                                                                                        rowServiceprovidersRow.id,
                                                                                                      ),
                                                                                                    );
                                                                                                    await showModalBottomSheet(
                                                                                                      isScrollControlled: true,
                                                                                                      backgroundColor: Colors.transparent,
                                                                                                      enableDrag: false,
                                                                                                      context: context,
                                                                                                      builder: (context) {
                                                                                                        return WebViewAware(
                                                                                                          child: GestureDetector(
                                                                                                            onTap: () {
                                                                                                              FocusScope.of(context).unfocus();
                                                                                                              FocusManager.instance.primaryFocus?.unfocus();
                                                                                                            },
                                                                                                            child: Padding(
                                                                                                              padding: MediaQuery.viewInsetsOf(context),
                                                                                                              child: VendorProfileWidget(
                                                                                                                serviceprovider: rowServiceprovidersRow,
                                                                                                                reviews: _model.getallreviews,
                                                                                                              ),
                                                                                                            ),
                                                                                                          ),
                                                                                                        );
                                                                                                      },
                                                                                                    ).then((value) => safeSetState(() {}));

                                                                                                    safeSetState(() {});
                                                                                                  },
                                                                                                  text: 'View Profile',
                                                                                                  options: FFButtonOptions(
                                                                                                    width: double.infinity,
                                                                                                    height: 44.0,
                                                                                                    padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                                                                                                    iconPadding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                                                                                                    color: FlutterFlowTheme.of(context).primaryText,
                                                                                                    textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                                                                                                          font: GoogleFonts.lato(
                                                                                                            fontWeight: FlutterFlowTheme.of(context).titleSmall.fontWeight,
                                                                                                            fontStyle: FlutterFlowTheme.of(context).titleSmall.fontStyle,
                                                                                                          ),
                                                                                                          color: Colors.white,
                                                                                                          fontSize: 12.0,
                                                                                                          letterSpacing: 0.0,
                                                                                                          fontWeight: FlutterFlowTheme.of(context).titleSmall.fontWeight,
                                                                                                          fontStyle: FlutterFlowTheme.of(context).titleSmall.fontStyle,
                                                                                                        ),
                                                                                                    elevation: 2.0,
                                                                                                    borderRadius: BorderRadius.circular(8.0),
                                                                                                  ),
                                                                                                ),
                                                                                              ),
                                                                                              Expanded(
                                                                                                child: FFButtonWidget(
                                                                                                  onPressed: () async {
                                                                                                    var _shouldSetState = false;
                                                                                                    var confirmDialogResponse = await showDialog<bool>(
                                                                                                          context: context,
                                                                                                          builder: (alertDialogContext) {
                                                                                                            return WebViewAware(
                                                                                                              child: AlertDialog(
                                                                                                                title: Text('Are you sure you want to confirm the job with this service provider?'),
                                                                                                                content: Text('Service Provider: ${rowServiceprovidersRow.companyName}'),
                                                                                                                actions: [
                                                                                                                  TextButton(
                                                                                                                    onPressed: () => Navigator.pop(alertDialogContext, false),
                                                                                                                    child: Text('Cancel'),
                                                                                                                  ),
                                                                                                                  TextButton(
                                                                                                                    onPressed: () => Navigator.pop(alertDialogContext, true),
                                                                                                                    child: Text('Confirm'),
                                                                                                                  ),
                                                                                                                ],
                                                                                                              ),
                                                                                                            );
                                                                                                          },
                                                                                                        ) ??
                                                                                                        false;
                                                                                                    if (confirmDialogResponse) {
                                                                                                      _model.findfleetcompanyB = await TransportersTable().queryRows(
                                                                                                        queryFn: (q) => q.eqOrNull(
                                                                                                          'id',
                                                                                                          incidentcolumnRequestsRow?.fleetcompanyId,
                                                                                                        ),
                                                                                                      );
                                                                                                      _shouldSetState = true;
                                                                                                      await RequestsTable().update(
                                                                                                        data: {
                                                                                                          'status': 'Accepted by service provider',
                                                                                                          'match_time': supaSerialize<DateTime>(getCurrentTimestamp),
                                                                                                          'chosen_providers': rowServiceprovidersRow.companyName,
                                                                                                          'chosenprovider': rowServiceprovidersRow.id,
                                                                                                          'selectedprovider_image': rowServiceprovidersRow.logo,
                                                                                                          'provider_number': rowServiceprovidersRow.phone,
                                                                                                        },
                                                                                                        matchingRows: (rows) => rows.eqOrNull(
                                                                                                          'id',
                                                                                                          widget!.requestid,
                                                                                                        ),
                                                                                                      );
                                                                                                      await Future.wait([
                                                                                                        Future(() async {
                                                                                                          _model.findspadmins = await UsersTable().queryRows(
                                                                                                            queryFn: (q) => q
                                                                                                                .eqOrNull(
                                                                                                                  'service_provider',
                                                                                                                  rowServiceprovidersRow.id,
                                                                                                                )
                                                                                                                .eqOrNull(
                                                                                                                  'currentrole',
                                                                                                                  'Service Provider',
                                                                                                                ),
                                                                                                          );
                                                                                                          _shouldSetState = true;
                                                                                                          _model.findspadminsFb = await queryUsersRecordOnce(
                                                                                                            queryBuilder: (usersRecord) => usersRecord.whereIn('uid', _model.findspadmins?.map((e) => e.uid).withoutNulls.toList()),
                                                                                                          );
                                                                                                          _shouldSetState = true;
                                                                                                          await Future.wait([
                                                                                                            Future(() async {
                                                                                                              triggerPushNotification(
                                                                                                                notificationTitle: 'New Job (${incidentcolumnRequestsRow?.serviceRequested})',
                                                                                                                notificationText: '${incidentcolumnRequestsRow?.fleetcompanyName} has selected you to assist their driver (${incidentcolumnRequestsRow?.requesterName}) with ${incidentcolumnRequestsRow?.serviceRequested} services at ${incidentcolumnRequestsRow?.address}',
                                                                                                                notificationSound: 'default',
                                                                                                                userRefs: _model.findspadminsFb!.map((e) => e.reference).toList(),
                                                                                                                initialPageName: 'request_details',
                                                                                                                parameterData: {
                                                                                                                  'role': 'Service Provider',
                                                                                                                  'requestid': widget!.requestid,
                                                                                                                  'completed': false,
                                                                                                                },
                                                                                                              );
                                                                                                            }),
                                                                                                            Future(() async {
                                                                                                              await NotificationsTable().insert({
                                                                                                                'created_at': supaSerialize<DateTime>(getCurrentTimestamp),
                                                                                                                'title': 'New Job (${incidentcolumnRequestsRow?.serviceRequested})',
                                                                                                                'message': '${incidentcolumnRequestsRow?.fleetcompanyName} has selected you to assist their driver (${incidentcolumnRequestsRow?.requesterName}) with ${incidentcolumnRequestsRow?.serviceRequested} services at ${incidentcolumnRequestsRow?.address}',
                                                                                                                'sent_by': currentUserUid,
                                                                                                                'sent_to': _model.findspadmins?.map((e) => e.uid).withoutNulls.toList(),
                                                                                                                'category': 'Incident',
                                                                                                              });
                                                                                                            }),
                                                                                                          ]);
                                                                                                        }),
                                                                                                        Future(() async {
                                                                                                          _model.finddriverfb = await queryUsersRecordOnce(
                                                                                                            queryBuilder: (usersRecord) => usersRecord.where(
                                                                                                              'uid',
                                                                                                              isEqualTo: incidentcolumnRequestsRow?.requesterUid,
                                                                                                            ),
                                                                                                            singleRecord: true,
                                                                                                          ).then((s) => s.firstOrNull);
                                                                                                          _shouldSetState = true;
                                                                                                          await Future.wait([
                                                                                                            Future(() async {
                                                                                                              triggerPushNotification(
                                                                                                                notificationTitle: 'Service Provider Found 🛠️✅',
                                                                                                                notificationText: '${rowServiceprovidersRow.companyName} has been selected by your fleet manager to assist you with ${incidentcolumnRequestsRow?.serviceRequested} services.',
                                                                                                                notificationSound: 'default',
                                                                                                                userRefs: [_model.finddriverfb!.reference],
                                                                                                                initialPageName: 'request_details',
                                                                                                                parameterData: {
                                                                                                                  'role': 'Driver',
                                                                                                                  'requestid': widget!.requestid,
                                                                                                                  'completed': false,
                                                                                                                },
                                                                                                              );
                                                                                                            }),
                                                                                                            Future(() async {
                                                                                                              await NotificationsTable().insert({
                                                                                                                'created_at': supaSerialize<DateTime>(getCurrentTimestamp),
                                                                                                                'title': 'Service Provider Found 🛠️✅',
                                                                                                                'message': '${rowServiceprovidersRow.companyName} has been selected by your fleet manager to assist you with ${incidentcolumnRequestsRow?.serviceRequested} services.',
                                                                                                                'sent_by': currentUserUid,
                                                                                                                'sent_to': functions.stringtosinglevaluearray(incidentcolumnRequestsRow!.requesterUid!),
                                                                                                                'category': 'Incident',
                                                                                                              });
                                                                                                            }),
                                                                                                          ]);
                                                                                                        }),
                                                                                                      ]);
                                                                                                      await ServiceProviderSelectedCall.call(
                                                                                                        spPhone: _model.findspadmins?.firstOrNull?.phone,
                                                                                                        driverPhone: incidentcolumnRequestsRow?.requesterPhone,
                                                                                                        spName: rowServiceprovidersRow.companyName,
                                                                                                        driverName: incidentcolumnRequestsRow?.requesterName,
                                                                                                        services: incidentcolumnRequestsRow?.serviceRequested,
                                                                                                        transporter: incidentdetailsUsersRow?.transporterName,
                                                                                                        address: incidentcolumnRequestsRow?.address,
                                                                                                        incidentNumber: incidentcolumnRequestsRow?.id?.toString(),
                                                                                                        vin: incidentcolumnRequestsRow?.vehicleVin,
                                                                                                        transporterPhone: '${_model.findfleetcompanyB?.firstOrNull?.phone} or ${incidentdetailsUsersRow?.phone}',
                                                                                                        details: incidentcolumnRequestsRow?.requestDetails,
                                                                                                      );

                                                                                                      await showDialog(
                                                                                                        context: context,
                                                                                                        builder: (alertDialogContext) {
                                                                                                          return WebViewAware(
                                                                                                            child: AlertDialog(
                                                                                                              title: Text('${rowServiceprovidersRow.companyName} has been selected for this incident.'),
                                                                                                              content: Text('All parties have been notified.'),
                                                                                                              actions: [
                                                                                                                TextButton(
                                                                                                                  onPressed: () => Navigator.pop(alertDialogContext),
                                                                                                                  child: Text('Ok'),
                                                                                                                ),
                                                                                                              ],
                                                                                                            ),
                                                                                                          );
                                                                                                        },
                                                                                                      );
                                                                                                      safeSetState(() => _model.requestCompleter = null);
                                                                                                      await _model.waitForRequestCompleted();
                                                                                                    } else {
                                                                                                      if (_shouldSetState) safeSetState(() {});
                                                                                                      return;
                                                                                                    }

                                                                                                    if (_shouldSetState) safeSetState(() {});
                                                                                                  },
                                                                                                  text: 'Confirm',
                                                                                                  options: FFButtonOptions(
                                                                                                    width: double.infinity,
                                                                                                    height: 44.0,
                                                                                                    padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                                                                                                    iconPadding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                                                                                                    color: FlutterFlowTheme.of(context).primary,
                                                                                                    textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                                                                                                          font: GoogleFonts.lato(
                                                                                                            fontWeight: FlutterFlowTheme.of(context).titleSmall.fontWeight,
                                                                                                            fontStyle: FlutterFlowTheme.of(context).titleSmall.fontStyle,
                                                                                                          ),
                                                                                                          color: Colors.white,
                                                                                                          fontSize: 12.0,
                                                                                                          letterSpacing: 0.0,
                                                                                                          fontWeight: FlutterFlowTheme.of(context).titleSmall.fontWeight,
                                                                                                          fontStyle: FlutterFlowTheme.of(context).titleSmall.fontStyle,
                                                                                                        ),
                                                                                                    elevation: 2.0,
                                                                                                    borderRadius: BorderRadius.circular(8.0),
                                                                                                  ),
                                                                                                ),
                                                                                              ),
                                                                                            ].divide(SizedBox(width: 12.0)),
                                                                                          ),
                                                                                        ),
                                                                                      Padding(
                                                                                        padding: EdgeInsetsDirectional.fromSTEB(0.0, 4.0, 0.0, 0.0),
                                                                                        child: Text(
                                                                                          'Click for all details and services offered',
                                                                                          textAlign: TextAlign.center,
                                                                                          maxLines: 1,
                                                                                          style: FlutterFlowTheme.of(context).labelMedium.override(
                                                                                                font: GoogleFonts.lato(
                                                                                                  fontWeight: FontWeight.w500,
                                                                                                  fontStyle: FlutterFlowTheme.of(context).labelMedium.fontStyle,
                                                                                                ),
                                                                                                color: Color(0xFF57636C),
                                                                                                fontSize: 12.0,
                                                                                                letterSpacing: 0.0,
                                                                                                fontWeight: FontWeight.w500,
                                                                                                fontStyle: FlutterFlowTheme.of(context).labelMedium.fontStyle,
                                                                                              ),
                                                                                        ),
                                                                                      ),
                                                                                      if (incidentcolumnRequestsRow?.paid == false)
                                                                                        Padding(
                                                                                          padding: EdgeInsetsDirectional.fromSTEB(0.0, 12.0, 0.0, 0.0),
                                                                                          child: Container(
                                                                                            width: double.infinity,
                                                                                            height: 52.0,
                                                                                            decoration: BoxDecoration(
                                                                                              color: FlutterFlowTheme.of(context).secondaryBackground,
                                                                                              borderRadius: BorderRadius.circular(4.0),
                                                                                              border: Border.all(
                                                                                                color: FlutterFlowTheme.of(context).primaryBackground,
                                                                                                width: 2.0,
                                                                                              ),
                                                                                            ),
                                                                                            child: Row(
                                                                                              mainAxisSize: MainAxisSize.max,
                                                                                              mainAxisAlignment: MainAxisAlignment.center,
                                                                                              children: [
                                                                                                Icon(
                                                                                                  Icons.lock,
                                                                                                  color: FlutterFlowTheme.of(context).primaryText,
                                                                                                  size: 20.0,
                                                                                                ),
                                                                                                Padding(
                                                                                                  padding: EdgeInsetsDirectional.fromSTEB(4.0, 0.0, 0.0, 0.0),
                                                                                                  child: Text(
                                                                                                    'Pay to view',
                                                                                                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                          font: GoogleFonts.lato(
                                                                                                            fontWeight: FontWeight.w600,
                                                                                                            fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                                                          ),
                                                                                                          letterSpacing: 0.0,
                                                                                                          fontWeight: FontWeight.w600,
                                                                                                          fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                                                        ),
                                                                                                  ),
                                                                                                ),
                                                                                              ],
                                                                                            ),
                                                                                          ),
                                                                                        ),
                                                                                    ],
                                                                                  ),
                                                                                ),
                                                                              ).animateOnPageLoad(animationsMap['containerOnPageLoadAnimation1']!),
                                                                            );
                                                                          }).divide(
                                                                              SizedBox(width: 20.0)),
                                                                        ),
                                                                      );
                                                                    },
                                                                  ),
                                                                ),
                                                              if (((incidentcolumnRequestsRow?.providersTendered !=
                                                                              null &&
                                                                          (incidentcolumnRequestsRow?.providersTendered)!
                                                                              .isNotEmpty) ==
                                                                      false) &&
                                                                  (incidentdetailsUsersRow
                                                                          ?.currentrole ==
                                                                      'Fleet Manager'))
                                                                FutureBuilder<
                                                                    List<
                                                                        ServiceprovidersRow>>(
                                                                  future: ServiceprovidersTable()
                                                                      .queryRows(
                                                                    queryFn: (q) =>
                                                                        q.or(
                                                                            "truck_categories.cs.{${incidentcolumnRequestsRow?.serviceRequested}}, trailer_categories.cs.{${incidentcolumnRequestsRow?.serviceRequested}}"),
                                                                  ),
                                                                  builder: (context,
                                                                      snapshot) {
                                                                    // Customize what your widget looks like when it's loading.
                                                                    if (!snapshot
                                                                        .hasData) {
                                                                      return Center(
                                                                        child:
                                                                            SizedBox(
                                                                          width:
                                                                              50.0,
                                                                          height:
                                                                              50.0,
                                                                          child:
                                                                              CircularProgressIndicator(
                                                                            valueColor:
                                                                                AlwaysStoppedAnimation<Color>(
                                                                              FlutterFlowTheme.of(context).primary,
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      );
                                                                    }
                                                                    List<ServiceprovidersRow>
                                                                        containerServiceprovidersRowList =
                                                                        snapshot
                                                                            .data!;

                                                                    return Container(
                                                                      decoration:
                                                                          BoxDecoration(),
                                                                      child:
                                                                          Column(
                                                                        mainAxisSize:
                                                                            MainAxisSize.max,
                                                                        crossAxisAlignment:
                                                                            CrossAxisAlignment.start,
                                                                        children: [
                                                                          Text(
                                                                            valueOrDefault<String>(
                                                                              containerServiceprovidersRowList.isNotEmpty
                                                                                  ? () {
                                                                                      if (containerServiceprovidersRowList.length > 1) {
                                                                                        return 'There are ${containerServiceprovidersRowList.length.toString()}service providers available for this request. The nearest service provider is ${formatNumber(
                                                                                          functions.distance(functions.stringtocoordinates(incidentcolumnRequestsRow!.requesterLocation!), functions.stringtocoordinates(containerServiceprovidersRowList.sortedList(keyOf: (e) => functions.distance(functions.stringtocoordinates(incidentcolumnRequestsRow!.requesterLocation!), functions.stringtocoordinates(e.coordinates!)), desc: false).firstOrNull!.coordinates!)),
                                                                                          formatType: FormatType.custom,
                                                                                          format: '0.0 km away',
                                                                                          locale: '',
                                                                                        )}.';
                                                                                      } else if (containerServiceprovidersRowList.length == 1) {
                                                                                        return 'There is 1 service provider for this request. The service provider is ${formatNumber(
                                                                                          functions.distance(functions.stringtocoordinates(incidentcolumnRequestsRow!.requesterLocation!), functions.stringtocoordinates(containerServiceprovidersRowList.sortedList(keyOf: (e) => functions.distance(functions.stringtocoordinates(incidentcolumnRequestsRow!.requesterLocation!), functions.stringtocoordinates(e.coordinates!)), desc: false).firstOrNull!.coordinates!)),
                                                                                          formatType: FormatType.custom,
                                                                                          format: '0.0 km away',
                                                                                          locale: '',
                                                                                        )}.';
                                                                                      } else {
                                                                                        return 'There are no service providers nearby';
                                                                                      }
                                                                                    }()
                                                                                  : 'There are no service providers nearby.',
                                                                              'There are no service providers for this request',
                                                                            ),
                                                                            style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                  font: GoogleFonts.lato(
                                                                                    fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                                    fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                                  ),
                                                                                  letterSpacing: 0.0,
                                                                                  fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                                  fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                                ),
                                                                          ),
                                                                          Padding(
                                                                            padding: EdgeInsetsDirectional.fromSTEB(
                                                                                0.0,
                                                                                12.0,
                                                                                0.0,
                                                                                0.0),
                                                                            child:
                                                                                Builder(
                                                                              builder: (context) {
                                                                                final allproviders = containerServiceprovidersRowList.where((e) => (functions.distance(functions.stringtocoordinates(e.coordinates!), functions.stringtocoordinates(incidentcolumnRequestsRow!.requesterLocation!)) < 800000) && (incidentcolumnRequestsRow?.incompletedBy?.contains(e.id) == false)).toList().sortedList(keyOf: (e) => functions.distance(functions.stringtocoordinates(e.coordinates!), functions.stringtocoordinates(incidentcolumnRequestsRow!.requesterLocation!)), desc: false).toList();

                                                                                return SingleChildScrollView(
                                                                                  scrollDirection: Axis.horizontal,
                                                                                  child: Row(
                                                                                    mainAxisSize: MainAxisSize.max,
                                                                                    children: List.generate(allproviders.length, (allprovidersIndex) {
                                                                                      final allprovidersItem = allproviders[allprovidersIndex];
                                                                                      return Padding(
                                                                                        padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 1.0),
                                                                                        child: Container(
                                                                                          width: 240.0,
                                                                                          decoration: BoxDecoration(
                                                                                            color: Colors.white,
                                                                                            boxShadow: [
                                                                                              BoxShadow(
                                                                                                color: Color(0xFFF1F4F8),
                                                                                                offset: Offset(
                                                                                                  0.0,
                                                                                                  1.0,
                                                                                                ),
                                                                                              )
                                                                                            ],
                                                                                            borderRadius: BorderRadius.circular(8.0),
                                                                                            border: Border.all(
                                                                                              color: FlutterFlowTheme.of(context).primaryBackground,
                                                                                              width: 2.0,
                                                                                            ),
                                                                                          ),
                                                                                          child: Padding(
                                                                                            padding: EdgeInsets.all(16.0),
                                                                                            child: Column(
                                                                                              mainAxisSize: MainAxisSize.max,
                                                                                              crossAxisAlignment: CrossAxisAlignment.center,
                                                                                              children: [
                                                                                                ClipRRect(
                                                                                                  borderRadius: BorderRadius.circular(8.0),
                                                                                                  child: OctoImage(
                                                                                                    placeholderBuilder: (_) => SizedBox.expand(
                                                                                                      child: Image(
                                                                                                        image: BlurHashImage('LBS~q=-;?^-;?Hj[S3fQ?^j[DOay'),
                                                                                                        fit: BoxFit.cover,
                                                                                                      ),
                                                                                                    ),
                                                                                                    image: NetworkImage(
                                                                                                      getCORSProxyUrl(
                                                                                                        incidentcolumnRequestsRow!.paid! ? allprovidersItem.logo! : 'https://hkltjfqbbpmdboobsonx.supabase.co/storage/v1/object/public/files//Gova%20logo.png',
                                                                                                      ),
                                                                                                    ),
                                                                                                    width: 52.0,
                                                                                                    height: 52.0,
                                                                                                    fit: BoxFit.cover,
                                                                                                  ),
                                                                                                ),
                                                                                                Padding(
                                                                                                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 8.0, 0.0, 0.0),
                                                                                                  child: Text(
                                                                                                    valueOrDefault<String>(
                                                                                                      incidentcolumnRequestsRow!.paid! ? allprovidersItem.companyName : '**********',
                                                                                                      'N/A',
                                                                                                    ),
                                                                                                    maxLines: 1,
                                                                                                    style: FlutterFlowTheme.of(context).headlineSmall.override(
                                                                                                          font: GoogleFonts.lato(
                                                                                                            fontWeight: FontWeight.w600,
                                                                                                            fontStyle: FlutterFlowTheme.of(context).headlineSmall.fontStyle,
                                                                                                          ),
                                                                                                          color: Color(0xFF14181B),
                                                                                                          fontSize: 14.0,
                                                                                                          letterSpacing: 0.0,
                                                                                                          fontWeight: FontWeight.w600,
                                                                                                          fontStyle: FlutterFlowTheme.of(context).headlineSmall.fontStyle,
                                                                                                        ),
                                                                                                  ),
                                                                                                ),
                                                                                                Padding(
                                                                                                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 4.0, 0.0, 0.0),
                                                                                                  child: Text(
                                                                                                    valueOrDefault<String>(
                                                                                                      'Phone: ${valueOrDefault<String>(
                                                                                                        incidentcolumnRequestsRow!.paid! ? allprovidersItem.phone : '**********',
                                                                                                        'N/A',
                                                                                                      )}',
                                                                                                      'Phone: N/A',
                                                                                                    ),
                                                                                                    maxLines: 1,
                                                                                                    style: FlutterFlowTheme.of(context).bodySmall.override(
                                                                                                          font: GoogleFonts.lato(
                                                                                                            fontWeight: FontWeight.w500,
                                                                                                            fontStyle: FlutterFlowTheme.of(context).bodySmall.fontStyle,
                                                                                                          ),
                                                                                                          color: Color(0xFF4B39EF),
                                                                                                          fontSize: 12.0,
                                                                                                          letterSpacing: 0.0,
                                                                                                          fontWeight: FontWeight.w500,
                                                                                                          fontStyle: FlutterFlowTheme.of(context).bodySmall.fontStyle,
                                                                                                        ),
                                                                                                  ),
                                                                                                ),
                                                                                                Padding(
                                                                                                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 4.0, 0.0, 0.0),
                                                                                                  child: Text(
                                                                                                    'Distance from incident: ~${formatNumber(
                                                                                                      functions.distance(functions.stringtocoordinates(incidentcolumnRequestsRow!.requesterLocation!), functions.stringtocoordinates(allprovidersItem.coordinates!)),
                                                                                                      formatType: FormatType.custom,
                                                                                                      format: '0',
                                                                                                      locale: '',
                                                                                                    )}km',
                                                                                                    maxLines: 1,
                                                                                                    style: FlutterFlowTheme.of(context).labelMedium.override(
                                                                                                          font: GoogleFonts.lato(
                                                                                                            fontWeight: FontWeight.w500,
                                                                                                            fontStyle: FlutterFlowTheme.of(context).labelMedium.fontStyle,
                                                                                                          ),
                                                                                                          color: Color(0xFF4B39EF),
                                                                                                          fontSize: 12.0,
                                                                                                          letterSpacing: 0.0,
                                                                                                          fontWeight: FontWeight.w500,
                                                                                                          fontStyle: FlutterFlowTheme.of(context).labelMedium.fontStyle,
                                                                                                        ),
                                                                                                  ),
                                                                                                ),
                                                                                                Padding(
                                                                                                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 4.0, 0.0, 0.0),
                                                                                                  child: Text(
                                                                                                    incidentcolumnRequestsRow!.paid! ? 'Click for all details and services offered' : 'Provider details revealed after payment',
                                                                                                    textAlign: TextAlign.center,
                                                                                                    maxLines: 1,
                                                                                                    style: FlutterFlowTheme.of(context).labelMedium.override(
                                                                                                          font: GoogleFonts.lato(
                                                                                                            fontWeight: FontWeight.w500,
                                                                                                            fontStyle: FlutterFlowTheme.of(context).labelMedium.fontStyle,
                                                                                                          ),
                                                                                                          color: Color(0xFF57636C),
                                                                                                          fontSize: 12.0,
                                                                                                          letterSpacing: 0.0,
                                                                                                          fontWeight: FontWeight.w500,
                                                                                                          fontStyle: FlutterFlowTheme.of(context).labelMedium.fontStyle,
                                                                                                        ),
                                                                                                  ),
                                                                                                ),
                                                                                              ],
                                                                                            ),
                                                                                          ),
                                                                                        ).animateOnPageLoad(animationsMap['containerOnPageLoadAnimation2']!),
                                                                                      );
                                                                                    }).divide(SizedBox(width: 16.0)),
                                                                                  ),
                                                                                );
                                                                              },
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    );
                                                                  },
                                                                ),
                                                              if (incidentcolumnRequestsRow
                                                                      ?.chosenprovider !=
                                                                  null)
                                                                Row(
                                                                  mainAxisSize:
                                                                      MainAxisSize
                                                                          .max,
                                                                  children: [
                                                                    Expanded(
                                                                      child:
                                                                          Padding(
                                                                        padding: EdgeInsetsDirectional.fromSTEB(
                                                                            0.0,
                                                                            2.0,
                                                                            0.0,
                                                                            0.0),
                                                                        child: FutureBuilder<
                                                                            List<ServiceprovidersRow>>(
                                                                          future:
                                                                              ServiceprovidersTable().querySingleRow(
                                                                            queryFn: (q) =>
                                                                                q.eqOrNull(
                                                                              'id',
                                                                              incidentcolumnRequestsRow?.chosenprovider,
                                                                            ),
                                                                          ),
                                                                          builder:
                                                                              (context, snapshot) {
                                                                            // Customize what your widget looks like when it's loading.
                                                                            if (!snapshot.hasData) {
                                                                              return Center(
                                                                                child: SizedBox(
                                                                                  width: 50.0,
                                                                                  height: 50.0,
                                                                                  child: CircularProgressIndicator(
                                                                                    valueColor: AlwaysStoppedAnimation<Color>(
                                                                                      FlutterFlowTheme.of(context).primary,
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              );
                                                                            }
                                                                            List<ServiceprovidersRow>
                                                                                selectedproviderServiceprovidersRowList =
                                                                                snapshot.data!;

                                                                            final selectedproviderServiceprovidersRow = selectedproviderServiceprovidersRowList.isNotEmpty
                                                                                ? selectedproviderServiceprovidersRowList.first
                                                                                : null;

                                                                            return Container(
                                                                              width: double.infinity,
                                                                              decoration: BoxDecoration(
                                                                                color: Colors.white,
                                                                                borderRadius: BorderRadius.circular(0.0),
                                                                                border: Border.all(
                                                                                  color: Colors.white,
                                                                                  width: 0.0,
                                                                                ),
                                                                              ),
                                                                              child: Row(
                                                                                mainAxisSize: MainAxisSize.max,
                                                                                children: [
                                                                                  ClipRRect(
                                                                                    borderRadius: BorderRadius.circular(8.0),
                                                                                    child: OctoImage(
                                                                                      placeholderBuilder: (_) => SizedBox.expand(
                                                                                        child: Image(
                                                                                          image: BlurHashImage('LBS~q=-;?^-;?Hj[S3fQ?^j[DOay'),
                                                                                          fit: BoxFit.cover,
                                                                                        ),
                                                                                      ),
                                                                                      image: NetworkImage(
                                                                                        getCORSProxyUrl(
                                                                                          valueOrDefault<String>(
                                                                                            selectedproviderServiceprovidersRow?.logo,
                                                                                            'https://hkltjfqbbpmdboobsonx.supabase.co/storage/v1/object/public/files//Gova%20logo.png',
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                      width: 85.0,
                                                                                      height: 85.0,
                                                                                      fit: BoxFit.cover,
                                                                                    ),
                                                                                  ),
                                                                                  Expanded(
                                                                                    child: Padding(
                                                                                      padding: EdgeInsetsDirectional.fromSTEB(12.0, 0.0, 12.0, 0.0),
                                                                                      child: Column(
                                                                                        mainAxisSize: MainAxisSize.max,
                                                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                                                        children: [
                                                                                          Text(
                                                                                            valueOrDefault<String>(
                                                                                              selectedproviderServiceprovidersRow?.companyName,
                                                                                              '-',
                                                                                            ),
                                                                                            style: FlutterFlowTheme.of(context).headlineSmall.override(
                                                                                                  font: GoogleFonts.lato(
                                                                                                    fontWeight: FontWeight.w600,
                                                                                                    fontStyle: FlutterFlowTheme.of(context).headlineSmall.fontStyle,
                                                                                                  ),
                                                                                                  color: Color(0xFF14181B),
                                                                                                  fontSize: 14.0,
                                                                                                  letterSpacing: 0.0,
                                                                                                  fontWeight: FontWeight.w600,
                                                                                                  fontStyle: FlutterFlowTheme.of(context).headlineSmall.fontStyle,
                                                                                                ),
                                                                                          ),
                                                                                          Padding(
                                                                                            padding: EdgeInsetsDirectional.fromSTEB(0.0, 4.0, 0.0, 0.0),
                                                                                            child: Text(
                                                                                              'Distance from incident: ~${formatNumber(
                                                                                                functions.distance(functions.stringtocoordinates(incidentcolumnRequestsRow!.requesterLocation!), functions.stringtocoordinates(selectedproviderServiceprovidersRow!.coordinates!)),
                                                                                                formatType: FormatType.custom,
                                                                                                format: '0',
                                                                                                locale: '',
                                                                                              )}km',
                                                                                              style: FlutterFlowTheme.of(context).labelMedium.override(
                                                                                                    font: GoogleFonts.lato(
                                                                                                      fontWeight: FontWeight.w500,
                                                                                                      fontStyle: FlutterFlowTheme.of(context).labelMedium.fontStyle,
                                                                                                    ),
                                                                                                    color: Color(0xFF4B39EF),
                                                                                                    fontSize: 14.0,
                                                                                                    letterSpacing: 0.0,
                                                                                                    fontWeight: FontWeight.w500,
                                                                                                    fontStyle: FlutterFlowTheme.of(context).labelMedium.fontStyle,
                                                                                                  ),
                                                                                            ),
                                                                                          ),
                                                                                          Padding(
                                                                                            padding: EdgeInsetsDirectional.fromSTEB(0.0, 4.0, 0.0, 0.0),
                                                                                            child: Text(
                                                                                              'Click for more details',
                                                                                              style: FlutterFlowTheme.of(context).labelMedium.override(
                                                                                                    font: GoogleFonts.lato(
                                                                                                      fontWeight: FontWeight.w500,
                                                                                                      fontStyle: FlutterFlowTheme.of(context).labelMedium.fontStyle,
                                                                                                    ),
                                                                                                    color: Color(0xFF57636C),
                                                                                                    fontSize: 12.0,
                                                                                                    letterSpacing: 0.0,
                                                                                                    fontWeight: FontWeight.w500,
                                                                                                    fontStyle: FlutterFlowTheme.of(context).labelMedium.fontStyle,
                                                                                                  ),
                                                                                            ),
                                                                                          ),
                                                                                        ],
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ).animateOnPageLoad(animationsMap['containerOnPageLoadAnimation3']!);
                                                                          },
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    if (incidentcolumnRequestsRow
                                                                            ?.technicianStaffid !=
                                                                        null)
                                                                      Expanded(
                                                                        child:
                                                                            Align(
                                                                          alignment: AlignmentDirectional(
                                                                              0.0,
                                                                              -1.0),
                                                                          child:
                                                                              FutureBuilder<List<ServiceproviderStaffRow>>(
                                                                            future:
                                                                                ServiceproviderStaffTable().querySingleRow(
                                                                              queryFn: (q) => q.eqOrNull(
                                                                                'id',
                                                                                incidentcolumnRequestsRow?.technicianStaffid,
                                                                              ),
                                                                            ),
                                                                            builder:
                                                                                (context, snapshot) {
                                                                              // Customize what your widget looks like when it's loading.
                                                                              if (!snapshot.hasData) {
                                                                                return Center(
                                                                                  child: SizedBox(
                                                                                    width: 50.0,
                                                                                    height: 50.0,
                                                                                    child: CircularProgressIndicator(
                                                                                      valueColor: AlwaysStoppedAnimation<Color>(
                                                                                        FlutterFlowTheme.of(context).primary,
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                );
                                                                              }
                                                                              List<ServiceproviderStaffRow> containerServiceproviderStaffRowList = snapshot.data!;

                                                                              final containerServiceproviderStaffRow = containerServiceproviderStaffRowList.isNotEmpty ? containerServiceproviderStaffRowList.first : null;

                                                                              return InkWell(
                                                                                splashColor: Colors.transparent,
                                                                                focusColor: Colors.transparent,
                                                                                hoverColor: Colors.transparent,
                                                                                highlightColor: Colors.transparent,
                                                                                onTap: () async {
                                                                                  await showModalBottomSheet(
                                                                                    isScrollControlled: true,
                                                                                    backgroundColor: Colors.transparent,
                                                                                    enableDrag: false,
                                                                                    context: context,
                                                                                    builder: (context) {
                                                                                      return WebViewAware(
                                                                                        child: GestureDetector(
                                                                                          onTap: () {
                                                                                            FocusScope.of(context).unfocus();
                                                                                            FocusManager.instance.primaryFocus?.unfocus();
                                                                                          },
                                                                                          child: Padding(
                                                                                            padding: MediaQuery.viewInsetsOf(context),
                                                                                            child: AssignedtechnicianWidget(
                                                                                              job: incidentcolumnRequestsRow!,
                                                                                            ),
                                                                                          ),
                                                                                        ),
                                                                                      );
                                                                                    },
                                                                                  ).then((value) => safeSetState(() {}));
                                                                                },
                                                                                child: Container(
                                                                                  decoration: BoxDecoration(
                                                                                    color: FlutterFlowTheme.of(context).secondaryBackground,
                                                                                    borderRadius: BorderRadius.circular(8.0),
                                                                                    border: Border.all(
                                                                                      color: FlutterFlowTheme.of(context).secondaryBackground,
                                                                                      width: 2.0,
                                                                                    ),
                                                                                  ),
                                                                                  child: Row(
                                                                                    mainAxisSize: MainAxisSize.max,
                                                                                    children: [
                                                                                      ClipRRect(
                                                                                        borderRadius: BorderRadius.circular(8.0),
                                                                                        child: Image.network(
                                                                                          getCORSProxyUrl(
                                                                                            valueOrDefault<String>(
                                                                                              containerServiceproviderStaffRow?.image,
                                                                                              'https://hkltjfqbbpmdboobsonx.supabase.co/storage/v1/object/public/files//Gova%20logo.png',
                                                                                            ),
                                                                                          ),
                                                                                          width: 80.0,
                                                                                          height: 80.0,
                                                                                          fit: BoxFit.cover,
                                                                                        ),
                                                                                      ),
                                                                                      Flexible(
                                                                                        child: Padding(
                                                                                          padding: EdgeInsetsDirectional.fromSTEB(12.0, 0.0, 0.0, 0.0),
                                                                                          child: Column(
                                                                                            mainAxisSize: MainAxisSize.max,
                                                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                                                            children: [
                                                                                              Align(
                                                                                                alignment: AlignmentDirectional(-1.0, 0.0),
                                                                                                child: Text(
                                                                                                  'Job assigned to ${containerServiceproviderStaffRow?.firstName} ${containerServiceproviderStaffRow?.lastName} (${containerServiceproviderStaffRow?.phone})',
                                                                                                  maxLines: 2,
                                                                                                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                        font: GoogleFonts.lato(
                                                                                                          fontWeight: FontWeight.w600,
                                                                                                          fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                                                        ),
                                                                                                        color: FlutterFlowTheme.of(context).primaryText,
                                                                                                        letterSpacing: 0.0,
                                                                                                        fontWeight: FontWeight.w600,
                                                                                                        fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                                                      ),
                                                                                                ),
                                                                                              ),
                                                                                              Padding(
                                                                                                padding: EdgeInsetsDirectional.fromSTEB(0.0, 4.0, 0.0, 0.0),
                                                                                                child: RichText(
                                                                                                  textScaler: MediaQuery.of(context).textScaler,
                                                                                                  text: TextSpan(
                                                                                                    children: [
                                                                                                      TextSpan(
                                                                                                        text: 'Vehicle: ',
                                                                                                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                              font: GoogleFonts.lato(
                                                                                                                fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                                                                fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                                                              ),
                                                                                                              letterSpacing: 0.0,
                                                                                                              fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                                                              fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                                                            ),
                                                                                                      ),
                                                                                                      TextSpan(
                                                                                                        text: valueOrDefault<String>(
                                                                                                          incidentcolumnRequestsRow?.technicialVehicle,
                                                                                                          'N/A',
                                                                                                        ),
                                                                                                        style: GoogleFonts.splineSans(
                                                                                                          color: Color(0xFF4B39EF),
                                                                                                          fontWeight: FontWeight.w600,
                                                                                                          fontSize: 14.0,
                                                                                                          decoration: TextDecoration.underline,
                                                                                                        ),
                                                                                                      )
                                                                                                    ],
                                                                                                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                          font: GoogleFonts.lato(
                                                                                                            fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                                                            fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                                                          ),
                                                                                                          letterSpacing: 0.0,
                                                                                                          fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                                                          fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                                                        ),
                                                                                                  ),
                                                                                                ),
                                                                                              ),
                                                                                              Padding(
                                                                                                padding: EdgeInsetsDirectional.fromSTEB(0.0, 4.0, 0.0, 0.0),
                                                                                                child: RichText(
                                                                                                  textScaler: MediaQuery.of(context).textScaler,
                                                                                                  text: TextSpan(
                                                                                                    children: [
                                                                                                      TextSpan(
                                                                                                        text: 'Number plate:',
                                                                                                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                              font: GoogleFonts.lato(
                                                                                                                fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                                                                fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                                                              ),
                                                                                                              letterSpacing: 0.0,
                                                                                                              fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                                                              fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                                                            ),
                                                                                                      ),
                                                                                                      TextSpan(
                                                                                                        text: valueOrDefault<String>(
                                                                                                          incidentcolumnRequestsRow?.technicianNumberplate,
                                                                                                          'N/A',
                                                                                                        ),
                                                                                                        style: GoogleFonts.splineSans(
                                                                                                          color: Color(0xFF4B39EF),
                                                                                                          fontWeight: FontWeight.w600,
                                                                                                          fontSize: 14.0,
                                                                                                          decoration: TextDecoration.underline,
                                                                                                        ),
                                                                                                      )
                                                                                                    ],
                                                                                                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                                          font: GoogleFonts.lato(
                                                                                                            fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                                                            fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                                                          ),
                                                                                                          letterSpacing: 0.0,
                                                                                                          fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                                                          fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                                                        ),
                                                                                                  ),
                                                                                                ),
                                                                                              ),
                                                                                            ],
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                    ],
                                                                                  ),
                                                                                ),
                                                                              );
                                                                            },
                                                                          ),
                                                                        ),
                                                                      ),
                                                                  ],
                                                                ),
                                                            ],
                                                          ),
                                                        ].divide(SizedBox(
                                                            height: 16.0)),
                                                      ),
                                                    ),
                                                  ),
                                                if ((incidentdetailsUsersRow
                                                            ?.currentrole ==
                                                        'Service Provider') &&
                                                    (incidentcolumnRequestsRow
                                                            ?.chosenprovider ==
                                                        incidentdetailsUsersRow
                                                            ?.serviceProvider) &&
                                                    (incidentcolumnRequestsRow
                                                                ?.technician ==
                                                            null ||
                                                        incidentcolumnRequestsRow
                                                                ?.technician ==
                                                            ''))
                                                  Align(
                                                    alignment:
                                                        AlignmentDirectional(
                                                            -1.0, 0.0),
                                                    child: Padding(
                                                      padding:
                                                          EdgeInsets.all(24.0),
                                                      child: Column(
                                                        mainAxisSize:
                                                            MainAxisSize.max,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          Padding(
                                                            padding:
                                                                EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        0.0,
                                                                        0.0,
                                                                        0.0,
                                                                        20.0),
                                                            child: Row(
                                                              mainAxisSize:
                                                                  MainAxisSize
                                                                      .max,
                                                              children: [
                                                                Padding(
                                                                  padding: EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          4.0),
                                                                  child: Text(
                                                                    'Assign this job to a technician/staff member',
                                                                    style: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .override(
                                                                          font:
                                                                              GoogleFonts.lato(
                                                                            fontWeight:
                                                                                FontWeight.w600,
                                                                            fontStyle:
                                                                                FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                          ),
                                                                          fontSize:
                                                                              20.0,
                                                                          letterSpacing:
                                                                              0.0,
                                                                          fontWeight:
                                                                              FontWeight.w600,
                                                                          fontStyle: FlutterFlowTheme.of(context)
                                                                              .bodyMedium
                                                                              .fontStyle,
                                                                        ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Expanded(
                                                            child: FutureBuilder<
                                                                List<
                                                                    ServiceproviderStaffRow>>(
                                                              future:
                                                                  ServiceproviderStaffTable()
                                                                      .queryRows(
                                                                queryFn: (q) =>
                                                                    q.eqOrNull(
                                                                  'service_provider',
                                                                  incidentdetailsUsersRow
                                                                      ?.serviceProvider,
                                                                ),
                                                              ),
                                                              builder: (context,
                                                                  snapshot) {
                                                                // Customize what your widget looks like when it's loading.
                                                                if (!snapshot
                                                                    .hasData) {
                                                                  return Center(
                                                                    child:
                                                                        SizedBox(
                                                                      width:
                                                                          50.0,
                                                                      height:
                                                                          50.0,
                                                                      child:
                                                                          CircularProgressIndicator(
                                                                        valueColor:
                                                                            AlwaysStoppedAnimation<Color>(
                                                                          FlutterFlowTheme.of(context)
                                                                              .primary,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  );
                                                                }
                                                                List<ServiceproviderStaffRow>
                                                                    gridViewServiceproviderStaffRowList =
                                                                    snapshot
                                                                        .data!;

                                                                return GridView
                                                                    .builder(
                                                                  padding:
                                                                      EdgeInsets
                                                                          .zero,
                                                                  gridDelegate:
                                                                      SliverGridDelegateWithFixedCrossAxisCount(
                                                                    crossAxisCount:
                                                                        3,
                                                                    crossAxisSpacing:
                                                                        16.0,
                                                                    mainAxisSpacing:
                                                                        16.0,
                                                                    childAspectRatio:
                                                                        1.9,
                                                                  ),
                                                                  scrollDirection:
                                                                      Axis.vertical,
                                                                  itemCount:
                                                                      gridViewServiceproviderStaffRowList
                                                                          .length,
                                                                  itemBuilder:
                                                                      (context,
                                                                          gridViewIndex) {
                                                                    final gridViewServiceproviderStaffRow =
                                                                        gridViewServiceproviderStaffRowList[
                                                                            gridViewIndex];
                                                                    return Column(
                                                                      mainAxisSize:
                                                                          MainAxisSize
                                                                              .max,
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .spaceBetween,
                                                                      children: [
                                                                        Row(
                                                                          mainAxisSize:
                                                                              MainAxisSize.max,
                                                                          crossAxisAlignment:
                                                                              CrossAxisAlignment.center,
                                                                          children: [
                                                                            Container(
                                                                              width: 52.0,
                                                                              height: 52.0,
                                                                              clipBehavior: Clip.antiAlias,
                                                                              decoration: BoxDecoration(
                                                                                shape: BoxShape.circle,
                                                                              ),
                                                                              child: Image.network(
                                                                                getCORSProxyUrl(
                                                                                  valueOrDefault<String>(
                                                                                    gridViewServiceproviderStaffRow.image,
                                                                                    'https://hkltjfqbbpmdboobsonx.supabase.co/storage/v1/object/public/files//Gova%20logo.png',
                                                                                  ),
                                                                                ),
                                                                                fit: BoxFit.cover,
                                                                              ),
                                                                            ),
                                                                            Flexible(
                                                                              child: Padding(
                                                                                padding: EdgeInsetsDirectional.fromSTEB(8.0, 0.0, 0.0, 0.0),
                                                                                child: Column(
                                                                                  mainAxisSize: MainAxisSize.min,
                                                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                                                  children: [
                                                                                    Text(
                                                                                      valueOrDefault<String>(
                                                                                        '${gridViewServiceproviderStaffRow.firstName} ${gridViewServiceproviderStaffRow.lastName}',
                                                                                        'Nhlakanipho Nsundwane',
                                                                                      ),
                                                                                      maxLines: 2,
                                                                                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                            font: GoogleFonts.lato(
                                                                                              fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                                              fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                                            ),
                                                                                            letterSpacing: 0.0,
                                                                                            fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                                            fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                                          ),
                                                                                    ),
                                                                                    Text(
                                                                                      valueOrDefault<String>(
                                                                                        gridViewServiceproviderStaffRow.phone,
                                                                                        '-',
                                                                                      ),
                                                                                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                            font: GoogleFonts.lato(
                                                                                              fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                                              fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                                            ),
                                                                                            letterSpacing: 0.0,
                                                                                            fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                                            fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                                          ),
                                                                                    ),
                                                                                  ].divide(SizedBox(height: 8.0)),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                        FFButtonWidget(
                                                                          onPressed:
                                                                              () async {
                                                                            await showModalBottomSheet(
                                                                              isScrollControlled: true,
                                                                              backgroundColor: Colors.transparent,
                                                                              enableDrag: false,
                                                                              context: context,
                                                                              builder: (context) {
                                                                                return WebViewAware(
                                                                                  child: GestureDetector(
                                                                                    onTap: () {
                                                                                      FocusScope.of(context).unfocus();
                                                                                      FocusManager.instance.primaryFocus?.unfocus();
                                                                                    },
                                                                                    child: Padding(
                                                                                      padding: MediaQuery.viewInsetsOf(context),
                                                                                      child: AssignWidget(
                                                                                        serviceprovider: incidentdetailsUsersRow!.serviceProvider!,
                                                                                        job: incidentcolumnRequestsRow!,
                                                                                        assignee: gridViewServiceproviderStaffRow.id,
                                                                                        refresh: () async {
                                                                                          safeSetState(() => _model.requestCompleter = null);
                                                                                        },
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                );
                                                                              },
                                                                            ).then((value) =>
                                                                                safeSetState(() {}));
                                                                          },
                                                                          text:
                                                                              'Assign',
                                                                          options:
                                                                              FFButtonOptions(
                                                                            width:
                                                                                double.infinity,
                                                                            height:
                                                                                40.0,
                                                                            padding: EdgeInsetsDirectional.fromSTEB(
                                                                                16.0,
                                                                                0.0,
                                                                                16.0,
                                                                                0.0),
                                                                            iconPadding: EdgeInsetsDirectional.fromSTEB(
                                                                                0.0,
                                                                                0.0,
                                                                                0.0,
                                                                                0.0),
                                                                            color:
                                                                                FlutterFlowTheme.of(context).primary,
                                                                            textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                                                                                  font: GoogleFonts.lato(
                                                                                    fontWeight: FontWeight.w500,
                                                                                    fontStyle: FlutterFlowTheme.of(context).titleSmall.fontStyle,
                                                                                  ),
                                                                                  color: Colors.white,
                                                                                  fontSize: 14.0,
                                                                                  letterSpacing: 0.0,
                                                                                  fontWeight: FontWeight.w500,
                                                                                  fontStyle: FlutterFlowTheme.of(context).titleSmall.fontStyle,
                                                                                ),
                                                                            elevation:
                                                                                2.0,
                                                                            borderRadius:
                                                                                BorderRadius.circular(8.0),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    );
                                                                  },
                                                                );
                                                              },
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                if ((incidentdetailsUsersRow
                                                            ?.currentrole ==
                                                        'Service Provider') &&
                                                    (incidentcolumnRequestsRow
                                                            ?.chosenprovider ==
                                                        null) &&
                                                    incidentcolumnRequestsRow!
                                                        .providersTendered
                                                        .contains(
                                                            incidentdetailsUsersRow
                                                                ?.serviceProvider))
                                                  Align(
                                                    alignment:
                                                        AlignmentDirectional(
                                                            0.0, 0.0),
                                                    child: Padding(
                                                      padding:
                                                          EdgeInsets.all(24.0),
                                                      child: Column(
                                                        mainAxisSize:
                                                            MainAxisSize.max,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .center,
                                                        children: [
                                                          Icon(
                                                            Icons
                                                                .hourglass_empty,
                                                            color: FlutterFlowTheme
                                                                    .of(context)
                                                                .secondaryText,
                                                            size: 120.0,
                                                          ),
                                                          Padding(
                                                            padding:
                                                                EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        0.0,
                                                                        0.0,
                                                                        0.0,
                                                                        9.0),
                                                            child: Text(
                                                              'Bid pending - awaiting outcome',
                                                              style: FlutterFlowTheme
                                                                      .of(context)
                                                                  .bodyMedium
                                                                  .override(
                                                                    font: GoogleFonts
                                                                        .lato(
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w600,
                                                                      fontStyle: FlutterFlowTheme.of(
                                                                              context)
                                                                          .bodyMedium
                                                                          .fontStyle,
                                                                    ),
                                                                    fontSize:
                                                                        28.0,
                                                                    letterSpacing:
                                                                        0.0,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w600,
                                                                    fontStyle: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .fontStyle,
                                                                  ),
                                                            ),
                                                          ),
                                                          Text(
                                                            'You have sent a bid for this job to the fleet manager and are awaiting an outcome.\nIf your bid is successful, you will be notified and then \nyou will need to assign a technician to complete the job.',
                                                            textAlign: TextAlign
                                                                .center,
                                                            style: FlutterFlowTheme
                                                                    .of(context)
                                                                .bodyMedium
                                                                .override(
                                                                  font:
                                                                      GoogleFonts
                                                                          .lato(
                                                                    fontWeight: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .fontWeight,
                                                                    fontStyle: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .fontStyle,
                                                                  ),
                                                                  color: FlutterFlowTheme.of(
                                                                          context)
                                                                      .secondaryText,
                                                                  letterSpacing:
                                                                      0.0,
                                                                  fontWeight: FlutterFlowTheme.of(
                                                                          context)
                                                                      .bodyMedium
                                                                      .fontWeight,
                                                                  fontStyle: FlutterFlowTheme.of(
                                                                          context)
                                                                      .bodyMedium
                                                                      .fontStyle,
                                                                ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                if ((incidentdetailsUsersRow
                                                            ?.currentrole ==
                                                        'Service Provider') &&
                                                    (incidentcolumnRequestsRow
                                                            ?.chosenprovider ==
                                                        incidentdetailsUsersRow
                                                            ?.serviceProvider) &&
                                                    (incidentcolumnRequestsRow
                                                                ?.technician !=
                                                            null &&
                                                        incidentcolumnRequestsRow
                                                                ?.technician !=
                                                            ''))
                                                  Align(
                                                    alignment:
                                                        AlignmentDirectional(
                                                            -1.0, 0.0),
                                                    child: Padding(
                                                      padding:
                                                          EdgeInsets.all(24.0),
                                                      child: Column(
                                                        mainAxisSize:
                                                            MainAxisSize.max,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          Row(
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .max,
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            children: [
                                                              Expanded(
                                                                child: Column(
                                                                  mainAxisSize:
                                                                      MainAxisSize
                                                                          .max,
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    Padding(
                                                                      padding: EdgeInsetsDirectional.fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          16.0),
                                                                      child:
                                                                          Text(
                                                                        'Selected technician',
                                                                        style: FlutterFlowTheme.of(context)
                                                                            .bodyMedium
                                                                            .override(
                                                                              font: GoogleFonts.lato(
                                                                                fontWeight: FontWeight.w600,
                                                                                fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                              ),
                                                                              fontSize: 16.0,
                                                                              letterSpacing: 0.0,
                                                                              fontWeight: FontWeight.w600,
                                                                              fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                            ),
                                                                      ),
                                                                    ),
                                                                    Padding(
                                                                      padding: EdgeInsetsDirectional.fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          16.0),
                                                                      child:
                                                                          Container(
                                                                        width:
                                                                            100.0,
                                                                        height:
                                                                            100.0,
                                                                        clipBehavior:
                                                                            Clip.antiAlias,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          shape:
                                                                              BoxShape.circle,
                                                                        ),
                                                                        child: Image
                                                                            .network(
                                                                          getCORSProxyUrl(
                                                                            valueOrDefault<String>(
                                                                              incidentcolumnRequestsRow?.technicianImage,
                                                                              'https://hkltjfqbbpmdboobsonx.supabase.co/storage/v1/object/public/files//Gova%20logo.png',
                                                                            ),
                                                                          ),
                                                                          fit: BoxFit
                                                                              .cover,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    Padding(
                                                                      padding: EdgeInsetsDirectional.fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          4.0),
                                                                      child:
                                                                          Text(
                                                                        valueOrDefault<
                                                                            String>(
                                                                          incidentcolumnRequestsRow
                                                                              ?.technician,
                                                                          '-',
                                                                        ),
                                                                        style: FlutterFlowTheme.of(context)
                                                                            .bodyMedium
                                                                            .override(
                                                                              font: GoogleFonts.lato(
                                                                                fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                                fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                              ),
                                                                              letterSpacing: 0.0,
                                                                              fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                              fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                            ),
                                                                      ),
                                                                    ),
                                                                    Padding(
                                                                      padding: EdgeInsetsDirectional.fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          20.0),
                                                                      child:
                                                                          Text(
                                                                        valueOrDefault<
                                                                            String>(
                                                                          incidentcolumnRequestsRow
                                                                              ?.technicianPhone,
                                                                          '-',
                                                                        ),
                                                                        style: FlutterFlowTheme.of(context)
                                                                            .bodyMedium
                                                                            .override(
                                                                              font: GoogleFonts.lato(
                                                                                fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                                fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                              ),
                                                                              letterSpacing: 0.0,
                                                                              fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                              fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                            ),
                                                                      ),
                                                                    ),
                                                                    Padding(
                                                                      padding: EdgeInsetsDirectional.fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          20.0),
                                                                      child:
                                                                          FFButtonWidget(
                                                                        onPressed:
                                                                            () async {
                                                                          await showModalBottomSheet(
                                                                            isScrollControlled:
                                                                                true,
                                                                            backgroundColor:
                                                                                Colors.transparent,
                                                                            enableDrag:
                                                                                false,
                                                                            context:
                                                                                context,
                                                                            builder:
                                                                                (context) {
                                                                              return WebViewAware(
                                                                                child: GestureDetector(
                                                                                  onTap: () {
                                                                                    FocusScope.of(context).unfocus();
                                                                                    FocusManager.instance.primaryFocus?.unfocus();
                                                                                  },
                                                                                  child: Padding(
                                                                                    padding: MediaQuery.viewInsetsOf(context),
                                                                                    child: AssignWidget(
                                                                                      serviceprovider: incidentcolumnRequestsRow!.chosenprovider!,
                                                                                      job: incidentcolumnRequestsRow!,
                                                                                      assignee: 0,
                                                                                      refresh: () async {
                                                                                        safeSetState(() => _model.requestCompleter = null);
                                                                                        await _model.waitForRequestCompleted();
                                                                                      },
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              );
                                                                            },
                                                                          ).then((value) =>
                                                                              safeSetState(() {}));
                                                                        },
                                                                        text:
                                                                            'Re-assign',
                                                                        options:
                                                                            FFButtonOptions(
                                                                          width:
                                                                              198.17,
                                                                          height:
                                                                              52.0,
                                                                          padding: EdgeInsetsDirectional.fromSTEB(
                                                                              16.0,
                                                                              0.0,
                                                                              16.0,
                                                                              0.0),
                                                                          iconPadding: EdgeInsetsDirectional.fromSTEB(
                                                                              0.0,
                                                                              0.0,
                                                                              0.0,
                                                                              0.0),
                                                                          color:
                                                                              FlutterFlowTheme.of(context).primary,
                                                                          textStyle: FlutterFlowTheme.of(context)
                                                                              .titleSmall
                                                                              .override(
                                                                                font: GoogleFonts.lato(
                                                                                  fontWeight: FlutterFlowTheme.of(context).titleSmall.fontWeight,
                                                                                  fontStyle: FlutterFlowTheme.of(context).titleSmall.fontStyle,
                                                                                ),
                                                                                color: Colors.white,
                                                                                fontSize: 14.0,
                                                                                letterSpacing: 0.0,
                                                                                fontWeight: FlutterFlowTheme.of(context).titleSmall.fontWeight,
                                                                                fontStyle: FlutterFlowTheme.of(context).titleSmall.fontStyle,
                                                                              ),
                                                                          elevation:
                                                                              2.0,
                                                                          borderRadius:
                                                                              BorderRadius.circular(8.0),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    FFButtonWidget(
                                                                      onPressed:
                                                                          () async {
                                                                        await showModalBottomSheet(
                                                                          isScrollControlled:
                                                                              true,
                                                                          backgroundColor:
                                                                              Colors.transparent,
                                                                          enableDrag:
                                                                              false,
                                                                          context:
                                                                              context,
                                                                          builder:
                                                                              (context) {
                                                                            return WebViewAware(
                                                                              child: GestureDetector(
                                                                                onTap: () {
                                                                                  FocusScope.of(context).unfocus();
                                                                                  FocusManager.instance.primaryFocus?.unfocus();
                                                                                },
                                                                                child: Padding(
                                                                                  padding: MediaQuery.viewInsetsOf(context),
                                                                                  child: ProviderCancelWidget(
                                                                                    incident: incidentcolumnRequestsRow!,
                                                                                    user: incidentdetailsUsersRow!,
                                                                                    refresh: () async {
                                                                                      safeSetState(() => _model.requestCompleter = null);
                                                                                      await _model.waitForRequestCompleted();
                                                                                    },
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            );
                                                                          },
                                                                        ).then((value) =>
                                                                            safeSetState(() {}));
                                                                      },
                                                                      text:
                                                                          'Cancel/Withdraw',
                                                                      options:
                                                                          FFButtonOptions(
                                                                        width:
                                                                            198.2,
                                                                        height:
                                                                            52.0,
                                                                        padding: EdgeInsetsDirectional.fromSTEB(
                                                                            16.0,
                                                                            0.0,
                                                                            16.0,
                                                                            0.0),
                                                                        iconPadding: EdgeInsetsDirectional.fromSTEB(
                                                                            0.0,
                                                                            0.0,
                                                                            0.0,
                                                                            0.0),
                                                                        color: FlutterFlowTheme.of(context)
                                                                            .primaryText,
                                                                        textStyle: FlutterFlowTheme.of(context)
                                                                            .titleSmall
                                                                            .override(
                                                                              font: GoogleFonts.lato(
                                                                                fontWeight: FlutterFlowTheme.of(context).titleSmall.fontWeight,
                                                                                fontStyle: FlutterFlowTheme.of(context).titleSmall.fontStyle,
                                                                              ),
                                                                              color: Colors.white,
                                                                              fontSize: 14.0,
                                                                              letterSpacing: 0.0,
                                                                              fontWeight: FlutterFlowTheme.of(context).titleSmall.fontWeight,
                                                                              fontStyle: FlutterFlowTheme.of(context).titleSmall.fontStyle,
                                                                            ),
                                                                        elevation:
                                                                            2.0,
                                                                        borderRadius:
                                                                            BorderRadius.circular(8.0),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                              Expanded(
                                                                child: FutureBuilder<
                                                                    List<
                                                                        TransportersRow>>(
                                                                  future: TransportersTable()
                                                                      .querySingleRow(
                                                                    queryFn: (q) =>
                                                                        q.eqOrNull(
                                                                      'id',
                                                                      incidentcolumnRequestsRow
                                                                          ?.fleetcompanyId,
                                                                    ),
                                                                  ),
                                                                  builder: (context,
                                                                      snapshot) {
                                                                    // Customize what your widget looks like when it's loading.
                                                                    if (!snapshot
                                                                        .hasData) {
                                                                      return Center(
                                                                        child:
                                                                            SizedBox(
                                                                          width:
                                                                              50.0,
                                                                          height:
                                                                              50.0,
                                                                          child:
                                                                              CircularProgressIndicator(
                                                                            valueColor:
                                                                                AlwaysStoppedAnimation<Color>(
                                                                              FlutterFlowTheme.of(context).primary,
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      );
                                                                    }
                                                                    List<TransportersRow>
                                                                        columnTransportersRowList =
                                                                        snapshot
                                                                            .data!;

                                                                    final columnTransportersRow = columnTransportersRowList
                                                                            .isNotEmpty
                                                                        ? columnTransportersRowList
                                                                            .first
                                                                        : null;

                                                                    return Column(
                                                                      mainAxisSize:
                                                                          MainAxisSize
                                                                              .max,
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .spaceBetween,
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .start,
                                                                      children: [
                                                                        Padding(
                                                                          padding: EdgeInsetsDirectional.fromSTEB(
                                                                              0.0,
                                                                              0.0,
                                                                              0.0,
                                                                              16.0),
                                                                          child:
                                                                              Text(
                                                                            'Transporter details',
                                                                            style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                  font: GoogleFonts.lato(
                                                                                    fontWeight: FontWeight.w600,
                                                                                    fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                                  ),
                                                                                  fontSize: 16.0,
                                                                                  letterSpacing: 0.0,
                                                                                  fontWeight: FontWeight.w600,
                                                                                  fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                                ),
                                                                          ),
                                                                        ),
                                                                        ClipRRect(
                                                                          borderRadius:
                                                                              BorderRadius.circular(800.0),
                                                                          child:
                                                                              Image.network(
                                                                            getCORSProxyUrl(
                                                                              valueOrDefault<String>(
                                                                                columnTransportersRow?.logo,
                                                                                'https://hkltjfqbbpmdboobsonx.supabase.co/storage/v1/object/public/files//Gova%20logo.png',
                                                                              ),
                                                                            ),
                                                                            width:
                                                                                100.0,
                                                                            height:
                                                                                100.0,
                                                                            fit:
                                                                                BoxFit.cover,
                                                                          ),
                                                                        ),
                                                                        Padding(
                                                                          padding: EdgeInsetsDirectional.fromSTEB(
                                                                              0.0,
                                                                              0.0,
                                                                              0.0,
                                                                              8.0),
                                                                          child:
                                                                              Text(
                                                                            valueOrDefault<String>(
                                                                              columnTransportersRow?.name,
                                                                              '-',
                                                                            ),
                                                                            style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                  font: GoogleFonts.lato(
                                                                                    fontWeight: FontWeight.normal,
                                                                                    fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                                  ),
                                                                                  color: FlutterFlowTheme.of(context).primaryText,
                                                                                  fontSize: 16.0,
                                                                                  letterSpacing: 0.0,
                                                                                  fontWeight: FontWeight.normal,
                                                                                  fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                                ),
                                                                          ),
                                                                        ),
                                                                        Padding(
                                                                          padding: EdgeInsetsDirectional.fromSTEB(
                                                                              0.0,
                                                                              0.0,
                                                                              0.0,
                                                                              12.0),
                                                                          child:
                                                                              RatingBar.builder(
                                                                            onRatingUpdate: (newValue) =>
                                                                                safeSetState(() => _model.ratingBarValue = newValue),
                                                                            itemBuilder: (context, index) =>
                                                                                Icon(
                                                                              Icons.star_rounded,
                                                                              color: Color(0xFFFFB900),
                                                                            ),
                                                                            direction:
                                                                                Axis.horizontal,
                                                                            initialRating: _model.ratingBarValue ??=
                                                                                3.0,
                                                                            unratedColor:
                                                                                Color(0xFFA1ACB9),
                                                                            itemCount:
                                                                                5,
                                                                            itemSize:
                                                                                24.0,
                                                                            glowColor:
                                                                                Color(0xFFFFB900),
                                                                          ),
                                                                        ),
                                                                        Padding(
                                                                          padding: EdgeInsetsDirectional.fromSTEB(
                                                                              0.0,
                                                                              0.0,
                                                                              0.0,
                                                                              6.0),
                                                                          child:
                                                                              Row(
                                                                            mainAxisSize:
                                                                                MainAxisSize.max,
                                                                            mainAxisAlignment:
                                                                                MainAxisAlignment.start,
                                                                            children: [
                                                                              Icon(
                                                                                Icons.store_rounded,
                                                                                color: FlutterFlowTheme.of(context).primaryText,
                                                                                size: 28.0,
                                                                              ),
                                                                              Flexible(
                                                                                child: Padding(
                                                                                  padding: EdgeInsetsDirectional.fromSTEB(4.0, 0.0, 0.0, 0.0),
                                                                                  child: Text(
                                                                                    valueOrDefault<String>(
                                                                                      columnTransportersRow?.address,
                                                                                      '-',
                                                                                    ),
                                                                                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                          font: GoogleFonts.lato(
                                                                                            fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                                            fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                                          ),
                                                                                          color: FlutterFlowTheme.of(context).primaryText,
                                                                                          fontSize: 14.0,
                                                                                          letterSpacing: 0.0,
                                                                                          fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                                          fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                                        ),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                        Padding(
                                                                          padding: EdgeInsetsDirectional.fromSTEB(
                                                                              0.0,
                                                                              0.0,
                                                                              0.0,
                                                                              6.0),
                                                                          child:
                                                                              Row(
                                                                            mainAxisSize:
                                                                                MainAxisSize.max,
                                                                            mainAxisAlignment:
                                                                                MainAxisAlignment.start,
                                                                            children: [
                                                                              Icon(
                                                                                Icons.phone,
                                                                                color: FlutterFlowTheme.of(context).primaryText,
                                                                                size: 28.0,
                                                                              ),
                                                                              Flexible(
                                                                                child: Padding(
                                                                                  padding: EdgeInsetsDirectional.fromSTEB(4.0, 0.0, 0.0, 0.0),
                                                                                  child: Text(
                                                                                    valueOrDefault<String>(
                                                                                      columnTransportersRow?.phone,
                                                                                      '-',
                                                                                    ),
                                                                                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                          font: GoogleFonts.lato(
                                                                                            fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                                            fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                                          ),
                                                                                          color: FlutterFlowTheme.of(context).primaryText,
                                                                                          fontSize: 14.0,
                                                                                          letterSpacing: 0.0,
                                                                                          fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                                          fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                                        ),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                        Padding(
                                                                          padding: EdgeInsetsDirectional.fromSTEB(
                                                                              0.0,
                                                                              0.0,
                                                                              0.0,
                                                                              6.0),
                                                                          child:
                                                                              Row(
                                                                            mainAxisSize:
                                                                                MainAxisSize.max,
                                                                            mainAxisAlignment:
                                                                                MainAxisAlignment.start,
                                                                            children: [
                                                                              Icon(
                                                                                Icons.email,
                                                                                color: FlutterFlowTheme.of(context).primaryText,
                                                                                size: 28.0,
                                                                              ),
                                                                              Flexible(
                                                                                child: Padding(
                                                                                  padding: EdgeInsetsDirectional.fromSTEB(4.0, 0.0, 0.0, 0.0),
                                                                                  child: Text(
                                                                                    valueOrDefault<String>(
                                                                                      columnTransportersRow?.email,
                                                                                      '-',
                                                                                    ),
                                                                                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                          font: GoogleFonts.lato(
                                                                                            fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                                            fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                                          ),
                                                                                          color: FlutterFlowTheme.of(context).primaryText,
                                                                                          fontSize: 14.0,
                                                                                          letterSpacing: 0.0,
                                                                                          fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                                          fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                                        ),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                        Padding(
                                                                          padding: EdgeInsetsDirectional.fromSTEB(
                                                                              0.0,
                                                                              0.0,
                                                                              0.0,
                                                                              6.0),
                                                                          child:
                                                                              Row(
                                                                            mainAxisSize:
                                                                                MainAxisSize.max,
                                                                            mainAxisAlignment:
                                                                                MainAxisAlignment.start,
                                                                            children: [
                                                                              Icon(
                                                                                Icons.calendar_month,
                                                                                color: FlutterFlowTheme.of(context).primaryText,
                                                                                size: 28.0,
                                                                              ),
                                                                              Flexible(
                                                                                child: Padding(
                                                                                  padding: EdgeInsetsDirectional.fromSTEB(4.0, 0.0, 0.0, 0.0),
                                                                                  child: Text(
                                                                                    'Member since: ${dateTimeFormat("dd MMMM y", columnTransportersRow?.createdAt)} (${dateTimeFormat("relative", columnTransportersRow?.createdAt)})',
                                                                                    maxLines: 2,
                                                                                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                                                                                          font: GoogleFonts.lato(
                                                                                            fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                                            fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                                          ),
                                                                                          color: FlutterFlowTheme.of(context).primaryText,
                                                                                          fontSize: 14.0,
                                                                                          letterSpacing: 0.0,
                                                                                          fontWeight: FlutterFlowTheme.of(context).bodyMedium.fontWeight,
                                                                                          fontStyle: FlutterFlowTheme.of(context).bodyMedium.fontStyle,
                                                                                        ),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    );
                                                                  },
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                if ((incidentdetailsUsersRow
                                                            ?.currentrole ==
                                                        'Service Provider') &&
                                                    (incidentcolumnRequestsRow
                                                            ?.chosenprovider ==
                                                        null) &&
                                                    (incidentcolumnRequestsRow
                                                            ?.providersTendered
                                                            ?.contains(
                                                                incidentdetailsUsersRow
                                                                    ?.serviceProvider) ==
                                                        false))
                                                  Align(
                                                    alignment:
                                                        AlignmentDirectional(
                                                            0.0, 0.0),
                                                    child: Padding(
                                                      padding:
                                                          EdgeInsets.all(24.0),
                                                      child: Column(
                                                        mainAxisSize:
                                                            MainAxisSize.max,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .center,
                                                        children: [
                                                          Icon(
                                                            Icons
                                                                .local_shipping_outlined,
                                                            color: FlutterFlowTheme
                                                                    .of(context)
                                                                .secondaryText,
                                                            size: 120.0,
                                                          ),
                                                          Padding(
                                                            padding:
                                                                EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        0.0,
                                                                        0.0,
                                                                        0.0,
                                                                        9.0),
                                                            child: Text(
                                                              'New Incident',
                                                              style: FlutterFlowTheme
                                                                      .of(context)
                                                                  .bodyMedium
                                                                  .override(
                                                                    font: GoogleFonts
                                                                        .lato(
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w600,
                                                                      fontStyle: FlutterFlowTheme.of(
                                                                              context)
                                                                          .bodyMedium
                                                                          .fontStyle,
                                                                    ),
                                                                    fontSize:
                                                                        28.0,
                                                                    letterSpacing:
                                                                        0.0,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w600,
                                                                    fontStyle: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .fontStyle,
                                                                  ),
                                                            ),
                                                          ),
                                                          Padding(
                                                            padding:
                                                                EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        0.0,
                                                                        0.0,
                                                                        0.0,
                                                                        16.0),
                                                            child: Text(
                                                              'This incident was just logged by a transporter in your area/region. \nYou can bid by clicking the accept button below',
                                                              textAlign:
                                                                  TextAlign
                                                                      .center,
                                                              style: FlutterFlowTheme
                                                                      .of(context)
                                                                  .bodyMedium
                                                                  .override(
                                                                    font: GoogleFonts
                                                                        .lato(
                                                                      fontWeight: FlutterFlowTheme.of(
                                                                              context)
                                                                          .bodyMedium
                                                                          .fontWeight,
                                                                      fontStyle: FlutterFlowTheme.of(
                                                                              context)
                                                                          .bodyMedium
                                                                          .fontStyle,
                                                                    ),
                                                                    color: FlutterFlowTheme.of(
                                                                            context)
                                                                        .secondaryText,
                                                                    letterSpacing:
                                                                        0.0,
                                                                    fontWeight: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .fontWeight,
                                                                    fontStyle: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .fontStyle,
                                                                  ),
                                                            ),
                                                          ),
                                                          if ((incidentdetailsUsersRow?.currentrole == 'Service Provider') &&
                                                              (incidentcolumnRequestsRow
                                                                          ?.cancellationReason ==
                                                                      null ||
                                                                  incidentcolumnRequestsRow
                                                                          ?.cancellationReason ==
                                                                      '') &&
                                                              (incidentcolumnRequestsRow
                                                                      ?.status !=
                                                                  'Completed') &&
                                                              incidentcolumnRequestsRow!
                                                                  .bidsopen!)
                                                            FutureBuilder<
                                                                List<
                                                                    ServiceprovidersRow>>(
                                                              future: ServiceprovidersTable()
                                                                  .querySingleRow(
                                                                queryFn: (q) =>
                                                                    q.eqOrNull(
                                                                  'id',
                                                                  incidentdetailsUsersRow
                                                                      ?.serviceProvider,
                                                                ),
                                                              ),
                                                              builder: (context,
                                                                  snapshot) {
                                                                // Customize what your widget looks like when it's loading.
                                                                if (!snapshot
                                                                    .hasData) {
                                                                  return Center(
                                                                    child:
                                                                        SizedBox(
                                                                      width:
                                                                          50.0,
                                                                      height:
                                                                          50.0,
                                                                      child:
                                                                          CircularProgressIndicator(
                                                                        valueColor:
                                                                            AlwaysStoppedAnimation<Color>(
                                                                          FlutterFlowTheme.of(context)
                                                                              .primary,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  );
                                                                }
                                                                List<ServiceprovidersRow>
                                                                    buttonServiceprovidersRowList =
                                                                    snapshot
                                                                        .data!;

                                                                final buttonServiceprovidersRow =
                                                                    buttonServiceprovidersRowList
                                                                            .isNotEmpty
                                                                        ? buttonServiceprovidersRowList
                                                                            .first
                                                                        : null;

                                                                return FFButtonWidget(
                                                                  onPressed:
                                                                      () async {
                                                                    var _shouldSetState =
                                                                        false;
                                                                    var confirmDialogResponse =
                                                                        await showDialog<bool>(
                                                                              context: context,
                                                                              builder: (alertDialogContext) {
                                                                                return WebViewAware(
                                                                                  child: AlertDialog(
                                                                                    title: Text('Are you sure you want to accept this job?'),
                                                                                    content: Text('${incidentcolumnRequestsRow?.serviceRequested} (approx. ${formatNumber(
                                                                                      functions.distance(functions.stringtocoordinates(incidentcolumnRequestsRow!.requesterLocation!), functions.stringtocoordinates(buttonServiceprovidersRow!.coordinates!)),
                                                                                      formatType: FormatType.custom,
                                                                                      format: '0km',
                                                                                      locale: '',
                                                                                    )} away)'),
                                                                                    actions: [
                                                                                      TextButton(
                                                                                        onPressed: () => Navigator.pop(alertDialogContext, false),
                                                                                        child: Text('Cancel'),
                                                                                      ),
                                                                                      TextButton(
                                                                                        onPressed: () => Navigator.pop(alertDialogContext, true),
                                                                                        child: Text('Confirm'),
                                                                                      ),
                                                                                    ],
                                                                                  ),
                                                                                );
                                                                              },
                                                                            ) ??
                                                                            false;
                                                                    if (confirmDialogResponse) {
                                                                      await RequestsTable()
                                                                          .update(
                                                                        data: {
                                                                          'providers_tendered': functions.addintegertolist(
                                                                              buttonServiceprovidersRow!.id,
                                                                              incidentcolumnRequestsRow!.providersTendered.toList()),
                                                                        },
                                                                        matchingRows:
                                                                            (rows) =>
                                                                                rows.eqOrNull(
                                                                          'id',
                                                                          incidentcolumnRequestsRow
                                                                              ?.id,
                                                                        ),
                                                                      );
                                                                      _model.findfleetmanagerA =
                                                                          await UsersTable()
                                                                              .queryRows(
                                                                        queryFn: (q) => q
                                                                            .eqOrNull(
                                                                              'transporter_id',
                                                                              incidentcolumnRequestsRow?.fleetcompanyId,
                                                                            )
                                                                            .eqOrNull(
                                                                              'currentrole',
                                                                              'Fleet Manager',
                                                                            ),
                                                                      );
                                                                      _shouldSetState =
                                                                          true;
                                                                      _model.findfmFbA =
                                                                          await queryUsersRecordOnce(
                                                                        queryBuilder: (usersRecord) => usersRecord.whereIn(
                                                                            'uid',
                                                                            _model.findfleetmanagerA?.map((e) => e.uid).withoutNulls.toList()),
                                                                      );
                                                                      _shouldSetState =
                                                                          true;
                                                                      await Future
                                                                          .wait([
                                                                        Future(
                                                                            () async {
                                                                          triggerPushNotification(
                                                                            notificationTitle:
                                                                                'New Bid - Incident #${incidentcolumnRequestsRow?.id?.toString()}',
                                                                            notificationText:
                                                                                'A service provider is ready to assist your driver (${incidentcolumnRequestsRow?.requesterName}) who requested ${incidentcolumnRequestsRow?.serviceRequested} services at ${incidentcolumnRequestsRow?.address}',
                                                                            notificationSound:
                                                                                'default',
                                                                            userRefs:
                                                                                _model.findfmFbA!.map((e) => e.reference).toList(),
                                                                            initialPageName:
                                                                                'request_details',
                                                                            parameterData: {
                                                                              'role': 'Fleet Manager',
                                                                              'requestid': incidentcolumnRequestsRow?.id,
                                                                              'completed': false,
                                                                            },
                                                                          );
                                                                        }),
                                                                        Future(
                                                                            () async {
                                                                          await NotificationsTable()
                                                                              .insert({
                                                                            'title':
                                                                                'New Bid - Incident #${incidentcolumnRequestsRow?.id?.toString()}',
                                                                            'created_at':
                                                                                supaSerialize<DateTime>(getCurrentTimestamp),
                                                                            'message':
                                                                                'A service provider is ready to assist your driver (${incidentcolumnRequestsRow?.requesterName}) who requested ${incidentcolumnRequestsRow?.serviceRequested} services at ${incidentcolumnRequestsRow?.address}',
                                                                            'sent_by':
                                                                                currentUserUid,
                                                                            'sent_to':
                                                                                _model.findfleetmanagerA?.map((e) => e.uid).withoutNulls.toList(),
                                                                            'category':
                                                                                'Incident',
                                                                          });
                                                                        }),
                                                                      ]);
                                                                      await NewBidFromServiceProviderCall
                                                                          .call(
                                                                        fmPhone: _model
                                                                            .findfleetmanager
                                                                            ?.firstOrNull
                                                                            ?.phone,
                                                                        serviceProvider:
                                                                            buttonServiceprovidersRow?.companyName,
                                                                        services:
                                                                            incidentcolumnRequestsRow?.serviceRequested,
                                                                        incident: widget!
                                                                            .requestid
                                                                            ?.toString(),
                                                                        driverName:
                                                                            incidentcolumnRequestsRow?.requesterName,
                                                                        address:
                                                                            incidentcolumnRequestsRow?.address,
                                                                      );

                                                                      safeSetState(() =>
                                                                          _model.requestCompleter =
                                                                              null);
                                                                      await showDialog(
                                                                        context:
                                                                            context,
                                                                        builder:
                                                                            (alertDialogContext) {
                                                                          return WebViewAware(
                                                                            child:
                                                                                AlertDialog(
                                                                              title: Text('Your bid for the job has been sent to the fleet manager'),
                                                                              actions: [
                                                                                TextButton(
                                                                                  onPressed: () => Navigator.pop(alertDialogContext),
                                                                                  child: Text('Ok'),
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          );
                                                                        },
                                                                      );
                                                                    } else {
                                                                      if (_shouldSetState)
                                                                        safeSetState(
                                                                            () {});
                                                                      return;
                                                                    }

                                                                    if (_shouldSetState)
                                                                      safeSetState(
                                                                          () {});
                                                                  },
                                                                  text:
                                                                      'Accept',
                                                                  options:
                                                                      FFButtonOptions(
                                                                    width:
                                                                        120.0,
                                                                    height:
                                                                        60.0,
                                                                    padding: EdgeInsetsDirectional
                                                                        .fromSTEB(
                                                                            16.0,
                                                                            0.0,
                                                                            16.0,
                                                                            0.0),
                                                                    iconPadding:
                                                                        EdgeInsetsDirectional.fromSTEB(
                                                                            0.0,
                                                                            0.0,
                                                                            0.0,
                                                                            0.0),
                                                                    color: FlutterFlowTheme.of(
                                                                            context)
                                                                        .primary,
                                                                    textStyle: FlutterFlowTheme.of(
                                                                            context)
                                                                        .titleSmall
                                                                        .override(
                                                                          font:
                                                                              GoogleFonts.lato(
                                                                            fontWeight:
                                                                                FlutterFlowTheme.of(context).titleSmall.fontWeight,
                                                                            fontStyle:
                                                                                FlutterFlowTheme.of(context).titleSmall.fontStyle,
                                                                          ),
                                                                          color:
                                                                              Colors.white,
                                                                          fontSize:
                                                                              14.0,
                                                                          letterSpacing:
                                                                              0.0,
                                                                          fontWeight: FlutterFlowTheme.of(context)
                                                                              .titleSmall
                                                                              .fontWeight,
                                                                          fontStyle: FlutterFlowTheme.of(context)
                                                                              .titleSmall
                                                                              .fontStyle,
                                                                        ),
                                                                    elevation:
                                                                        2.0,
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            8.0),
                                                                  ),
                                                                );
                                                              },
                                                            ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ].divide(SizedBox(height: 24.0)),
                                    ),
                                  ),
                                ),
                              ].divide(SizedBox(width: 24.0)),
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

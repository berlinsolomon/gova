import '/auth/firebase_auth/auth_util.dart';
import '/backend/supabase/supabase.dart';
import '/components/add_driver/add_driver_widget.dart';
import '/components/addtruck/addtruck_widget.dart';
import '/components/assigndriver/assigndriver_widget.dart';
import '/components/driverstatus/driverstatus_widget.dart';
import '/components/edit_truck/edit_truck_widget.dart';
import '/components/editdriver/editdriver_widget.dart';
import '/components/emptyactiveincidents/emptyactiveincidents_widget.dart';
import '/components/emptydrivers/emptydrivers_widget.dart';
import '/components/emptynotifs/emptynotifs_widget.dart';
import '/components/emptyreviews2/emptyreviews2_widget.dart';
import '/components/emptyserviceproviders/emptyserviceproviders_widget.dart';
import '/components/emptyvehicles/emptyvehicles_widget.dart';
import '/components/newincidentalert/newincidentalert_widget.dart';
import '/components/respond_fm/respond_fm_widget.dart';
import '/components/vehiclestatus/vehiclestatus_widget.dart';
import '/components/vendor_profile/vendor_profile_widget.dart';
import '/flutter_flow/flutter_flow_choice_chips.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_expanded_image_view.dart';
import '/flutter_flow/flutter_flow_google_map.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_pdf_viewer.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/flutter_flow/instant_timer.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'dart:async';
import 'fm_dashboard_widget.dart' show FmDashboardWidget;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_blurhash/flutter_blurhash.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:octo_image/octo_image.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';

class FmDashboardModel extends FlutterFlowModel<FmDashboardWidget> {
  ///  Local state fields for this page.

  DateTime? lastupdated;

  List<TransporterStaffRow> drivers = [];
  void addToDrivers(TransporterStaffRow item) => drivers.add(item);
  void removeFromDrivers(TransporterStaffRow item) => drivers.remove(item);
  void removeAtIndexFromDrivers(int index) => drivers.removeAt(index);
  void insertAtIndexInDrivers(int index, TransporterStaffRow item) =>
      drivers.insert(index, item);
  void updateDriversAtIndex(
          int index, Function(TransporterStaffRow) updateFn) =>
      drivers[index] = updateFn(drivers[index]);

  List<FleetRow> vehicles = [];
  void addToVehicles(FleetRow item) => vehicles.add(item);
  void removeFromVehicles(FleetRow item) => vehicles.remove(item);
  void removeAtIndexFromVehicles(int index) => vehicles.removeAt(index);
  void insertAtIndexInVehicles(int index, FleetRow item) =>
      vehicles.insert(index, item);
  void updateVehiclesAtIndex(int index, Function(FleetRow) updateFn) =>
      vehicles[index] = updateFn(vehicles[index]);

  List<FleetRow> vehiclesearch = [];
  void addToVehiclesearch(FleetRow item) => vehiclesearch.add(item);
  void removeFromVehiclesearch(FleetRow item) => vehiclesearch.remove(item);
  void removeAtIndexFromVehiclesearch(int index) =>
      vehiclesearch.removeAt(index);
  void insertAtIndexInVehiclesearch(int index, FleetRow item) =>
      vehiclesearch.insert(index, item);
  void updateVehiclesearchAtIndex(int index, Function(FleetRow) updateFn) =>
      vehiclesearch[index] = updateFn(vehiclesearch[index]);

  List<TransporterStaffRow> driversearch = [];
  void addToDriversearch(TransporterStaffRow item) => driversearch.add(item);
  void removeFromDriversearch(TransporterStaffRow item) =>
      driversearch.remove(item);
  void removeAtIndexFromDriversearch(int index) => driversearch.removeAt(index);
  void insertAtIndexInDriversearch(int index, TransporterStaffRow item) =>
      driversearch.insert(index, item);
  void updateDriversearchAtIndex(
          int index, Function(TransporterStaffRow) updateFn) =>
      driversearch[index] = updateFn(driversearch[index]);

  String? profilepic;

  bool changesmadeProfile = false;

  bool changesmadeCompany = false;

  String? logo;

  List<String> companyreg = [];
  void addToCompanyreg(String item) => companyreg.add(item);
  void removeFromCompanyreg(String item) => companyreg.remove(item);
  void removeAtIndexFromCompanyreg(int index) => companyreg.removeAt(index);
  void insertAtIndexInCompanyreg(int index, String item) =>
      companyreg.insert(index, item);
  void updateCompanyregAtIndex(int index, Function(String) updateFn) =>
      companyreg[index] = updateFn(companyreg[index]);

  List<String> vatreg = [];
  void addToVatreg(String item) => vatreg.add(item);
  void removeFromVatreg(String item) => vatreg.remove(item);
  void removeAtIndexFromVatreg(int index) => vatreg.removeAt(index);
  void insertAtIndexInVatreg(int index, String item) =>
      vatreg.insert(index, item);
  void updateVatregAtIndex(int index, Function(String) updateFn) =>
      vatreg[index] = updateFn(vatreg[index]);

  List<String> proofins = [];
  void addToProofins(String item) => proofins.add(item);
  void removeFromProofins(String item) => proofins.remove(item);
  void removeAtIndexFromProofins(int index) => proofins.removeAt(index);
  void insertAtIndexInProofins(int index, String item) =>
      proofins.insert(index, item);
  void updateProofinsAtIndex(int index, Function(String) updateFn) =>
      proofins[index] = updateFn(proofins[index]);

  ///  State fields for stateful widgets in this page.

  // Stores action output result for [Backend Call - Query Rows] action in fm_dashboard widget.
  List<UsersRow>? finduser;
  InstantTimer? instantTimer;
  Completer<List<RequestsRow>>? requestCompleter6;
  Completer<List<RequestsRow>>? requestCompleter10;
  Completer<List<RequestsRow>>? requestCompleter5;
  // Stores action output result for [Backend Call - Query Rows] action in fm_dashboard widget.
  List<RequestsRow>? findincidents;
  // Stores action output result for [Backend Call - Query Rows] action in contentView_1 widget.
  List<TransporterStaffRow>? getdrivers;
  // Stores action output result for [Backend Call - Query Rows] action in contentView_1 widget.
  List<FleetRow>? getvehicles;
  // Stores action output result for [Backend Call - Query Rows] action in contentView_1 widget.
  List<TransporterStaffRow>? getdrivers2;
  // Stores action output result for [Backend Call - Query Rows] action in contentView_1 widget.
  List<FleetRow>? getvehicles2;
  // State field(s) for GoogleMap widget.
  LatLng? googleMapsCenter;
  final googleMapsController = Completer<GoogleMapController>();
  // State field(s) for searchvehicles widget.
  FocusNode? searchvehiclesFocusNode;
  TextEditingController? searchvehiclesTextController;
  String? Function(BuildContext, String?)?
      searchvehiclesTextControllerValidator;
  // Stores action output result for [Backend Call - Query Rows] action in searchvehicles widget.
  List<FleetRow>? findmyvehicles;
  // Stores action output result for [Custom Action - search] action in searchvehicles widget.
  List<FleetRow>? searchvehicles;
  Completer<List<FleetRow>>? requestCompleter9;
  // Models for vehiclestatus dynamic component.
  late FlutterFlowDynamicModels<VehiclestatusModel> vehiclestatusModels1;
  // Models for assigndriver dynamic component.
  late FlutterFlowDynamicModels<AssigndriverModel> assigndriverModels1;
  // Models for vehiclestatus dynamic component.
  late FlutterFlowDynamicModels<VehiclestatusModel> vehiclestatusModels2;
  // Models for assigndriver dynamic component.
  late FlutterFlowDynamicModels<AssigndriverModel> assigndriverModels2;
  // State field(s) for searchdrivers widget.
  FocusNode? searchdriversFocusNode;
  TextEditingController? searchdriversTextController;
  String? Function(BuildContext, String?)? searchdriversTextControllerValidator;
  // Stores action output result for [Backend Call - Query Rows] action in searchdrivers widget.
  List<TransporterStaffRow>? finddrivers;
  // Stores action output result for [Custom Action - driversearch] action in searchdrivers widget.
  List<TransporterStaffRow>? searchdrivers;
  Completer<List<TransporterStaffRow>>? requestCompleter11;
  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<DialingcodesRow>? getcodes;
  // Models for driverstatus dynamic component.
  late FlutterFlowDynamicModels<DriverstatusModel> driverstatusModels1;
  // Models for driverstatus dynamic component.
  late FlutterFlowDynamicModels<DriverstatusModel> driverstatusModels2;
  Completer<List<RequestsRow>>? requestCompleter8;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController3;
  String? Function(BuildContext, String?)? textController3Validator;
  // State field(s) for DropDown widget.
  String? dropDownValue1;
  FormFieldController<String>? dropDownValueController1;
  // State field(s) for ChoiceChips widget.
  FormFieldController<List<String>>? choiceChipsValueController1;
  String? get choiceChipsValue1 =>
      choiceChipsValueController1?.value?.firstOrNull;
  set choiceChipsValue1(String? val) =>
      choiceChipsValueController1?.value = val != null ? [val] : [];
  // State field(s) for DropDown widget.
  List<String>? dropDownValue2;
  FormFieldController<List<String>>? dropDownValueController2;
  // State field(s) for DropDown widget.
  List<String>? dropDownValue3;
  FormFieldController<List<String>>? dropDownValueController3;
  Completer<List<ReviewsServiceprovidersRow>>? requestCompleter3;
  Completer<List<ServiceprovidersRow>>? requestCompleter2;
  Completer<List<TransportersRow>>? requestCompleter1;
  Completer<List<ReviewsServiceprovidersRow>>? requestCompleter4;
  // State field(s) for ChoiceChips widget.
  FormFieldController<List<String>>? choiceChipsValueController2;
  String? get choiceChipsValue2 =>
      choiceChipsValueController2?.value?.firstOrNull;
  set choiceChipsValue2(String? val) =>
      choiceChipsValueController2?.value = val != null ? [val] : [];
  Completer<List<ReviewsFleetcompaniesRow>>? requestCompleter7;
  bool isDataUploading_uploadDataMzy = false;
  FFUploadedFile uploadedLocalFile_uploadDataMzy =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  String uploadedFileUrl_uploadDataMzy = '';

  // State field(s) for firstname widget.
  FocusNode? firstnameFocusNode;
  TextEditingController? firstnameTextController;
  String? Function(BuildContext, String?)? firstnameTextControllerValidator;
  // State field(s) for lastname widget.
  FocusNode? lastnameFocusNode;
  TextEditingController? lastnameTextController;
  String? Function(BuildContext, String?)? lastnameTextControllerValidator;
  // State field(s) for email widget.
  FocusNode? emailFocusNode;
  TextEditingController? emailTextController;
  String? Function(BuildContext, String?)? emailTextControllerValidator;
  // State field(s) for phone widget.
  FocusNode? phoneFocusNode;
  TextEditingController? phoneTextController;
  String? Function(BuildContext, String?)? phoneTextControllerValidator;
  // Stores action output result for [Backend Call - Update Row(s)] action in Button widget.
  List<UsersRow>? updateuser;
  Completer<List<UsersRow>>? requestCompleter12;
  bool isDataUploading_uploadDataNewlogo = false;
  FFUploadedFile uploadedLocalFile_uploadDataNewlogo =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  String uploadedFileUrl_uploadDataNewlogo = '';

  // State field(s) for busname widget.
  FocusNode? busnameFocusNode;
  TextEditingController? busnameTextController;
  String? Function(BuildContext, String?)? busnameTextControllerValidator;
  // State field(s) for busreg widget.
  FocusNode? busregFocusNode;
  TextEditingController? busregTextController;
  String? Function(BuildContext, String?)? busregTextControllerValidator;
  // State field(s) for emailaddy widget.
  FocusNode? emailaddyFocusNode;
  TextEditingController? emailaddyTextController;
  String? Function(BuildContext, String?)? emailaddyTextControllerValidator;
  // State field(s) for phonenum widget.
  FocusNode? phonenumFocusNode;
  TextEditingController? phonenumTextController;
  String? Function(BuildContext, String?)? phonenumTextControllerValidator;
  // State field(s) for physical widget.
  FocusNode? physicalFocusNode;
  TextEditingController? physicalTextController;
  String? Function(BuildContext, String?)? physicalTextControllerValidator;
  // State field(s) for website widget.
  FocusNode? websiteFocusNode;
  TextEditingController? websiteTextController;
  String? Function(BuildContext, String?)? websiteTextControllerValidator;
  bool isDataUploading_uploadcompanyregA = false;
  FFUploadedFile uploadedLocalFile_uploadcompanyregA =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  String uploadedFileUrl_uploadcompanyregA = '';

  bool isDataUploading_uploadvatregA = false;
  FFUploadedFile uploadedLocalFile_uploadvatregA =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  String uploadedFileUrl_uploadvatregA = '';

  bool isDataUploading_uploadinsA = false;
  FFUploadedFile uploadedLocalFile_uploadinsA =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  String uploadedFileUrl_uploadinsA = '';

  // Stores action output result for [Backend Call - Query Rows] action in Button widget.
  List<ServicesRow>? getallservices;

  @override
  void initState(BuildContext context) {
    vehiclestatusModels1 = FlutterFlowDynamicModels(() => VehiclestatusModel());
    assigndriverModels1 = FlutterFlowDynamicModels(() => AssigndriverModel());
    vehiclestatusModels2 = FlutterFlowDynamicModels(() => VehiclestatusModel());
    assigndriverModels2 = FlutterFlowDynamicModels(() => AssigndriverModel());
    driverstatusModels1 = FlutterFlowDynamicModels(() => DriverstatusModel());
    driverstatusModels2 = FlutterFlowDynamicModels(() => DriverstatusModel());
  }

  @override
  void dispose() {
    instantTimer?.cancel();
    searchvehiclesFocusNode?.dispose();
    searchvehiclesTextController?.dispose();

    vehiclestatusModels1.dispose();
    assigndriverModels1.dispose();
    vehiclestatusModels2.dispose();
    assigndriverModels2.dispose();
    searchdriversFocusNode?.dispose();
    searchdriversTextController?.dispose();

    driverstatusModels1.dispose();
    driverstatusModels2.dispose();
    textFieldFocusNode?.dispose();
    textController3?.dispose();

    firstnameFocusNode?.dispose();
    firstnameTextController?.dispose();

    lastnameFocusNode?.dispose();
    lastnameTextController?.dispose();

    emailFocusNode?.dispose();
    emailTextController?.dispose();

    phoneFocusNode?.dispose();
    phoneTextController?.dispose();

    busnameFocusNode?.dispose();
    busnameTextController?.dispose();

    busregFocusNode?.dispose();
    busregTextController?.dispose();

    emailaddyFocusNode?.dispose();
    emailaddyTextController?.dispose();

    phonenumFocusNode?.dispose();
    phonenumTextController?.dispose();

    physicalFocusNode?.dispose();
    physicalTextController?.dispose();

    websiteFocusNode?.dispose();
    websiteTextController?.dispose();
  }

  /// Additional helper methods.
  Future waitForRequestCompleted6({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter6?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }

  Future waitForRequestCompleted10({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter10?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }

  Future waitForRequestCompleted5({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter5?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }

  Future waitForRequestCompleted9({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter9?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }

  Future waitForRequestCompleted11({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter11?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }

  Future waitForRequestCompleted8({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter8?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }

  Future waitForRequestCompleted3({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter3?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }

  Future waitForRequestCompleted2({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter2?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }

  Future waitForRequestCompleted1({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter1?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }

  Future waitForRequestCompleted4({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter4?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }

  Future waitForRequestCompleted7({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter7?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }

  Future waitForRequestCompleted12({
    double minWait = 0,
    double maxWait = double.infinity,
  }) async {
    final stopwatch = Stopwatch()..start();
    while (true) {
      await Future.delayed(Duration(milliseconds: 50));
      final timeElapsed = stopwatch.elapsedMilliseconds;
      final requestComplete = requestCompleter12?.isCompleted ?? false;
      if (timeElapsed > maxWait || (requestComplete && timeElapsed > minWait)) {
        break;
      }
    }
  }
}
